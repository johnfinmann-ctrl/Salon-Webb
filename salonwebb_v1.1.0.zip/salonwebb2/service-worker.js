/* ================================================================
   SALON WEBB – service-worker.js v1.1.0
   Cache-first med network fallback · Automatisk cache-rydning
   ================================================================ */

const CACHE = 'salonwebb-v1.1.0';

const PRECACHE = [
  './',
  './index.html',
  './styles.css?v=1.1.0',
  './app.js?v=1.1.0',
  './data.js?v=1.1.0',
  './manifest.json',
  './offline.html',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './admin/',
  './admin/index.html',
  './admin/admin.css?v=1.1.0',
  './admin/admin.js?v=1.1.0'
];

/* ── INSTALL ── */
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(cache => {
      return Promise.allSettled(
        PRECACHE.map(url => cache.add(url).catch(err => console.warn('[SW] Precache miss:', url, err)))
      );
    })
  );
  self.skipWaiting();
});

/* ── ACTIVATE: ryd gamle caches ── */
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k.startsWith('salonwebb-') && k !== CACHE).map(k => {
        console.log('[SW] Sletning af gammel cache:', k);
        return caches.delete(k);
      }))
    )
  );
  self.clients.claim();
});

/* ── FETCH ── */
self.addEventListener('fetch', e => {
  const { request } = e;
  const url = new URL(request.url);

  // Kun GET
  if (request.method !== 'GET') return;

  // Admin panel: network-first (altid frisk)
  if (url.pathname.includes('/admin/')) {
    e.respondWith(networkFirst(request));
    return;
  }

  // Navigation (HTML sider)
  if (request.mode === 'navigate') {
    e.respondWith(
      fetch(request).then(res => {
        caches.open(CACHE).then(c => c.put(request, res.clone()));
        return res;
      }).catch(() =>
        caches.match('./index.html').then(c => c || caches.match('./offline.html'))
      )
    );
    return;
  }

  // Google Fonts & eksterne billeder: stale-while-revalidate
  if (url.hostname.includes('fonts.gstatic.com') ||
      url.hostname.includes('images.unsplash.com') ||
      url.hostname.includes('api.qrserver.com')) {
    e.respondWith(staleWhileRevalidate(request));
    return;
  }

  // Alt andet: cache-first
  e.respondWith(
    caches.match(request).then(cached => {
      if (cached) return cached;
      return fetch(request).then(res => {
        if (res.ok) caches.open(CACHE).then(c => c.put(request, res.clone()));
        return res;
      }).catch(() => offlineFallback(request));
    })
  );
});

/* ── STRATEGIER ── */
async function networkFirst(request) {
  try {
    const res = await fetch(request);
    if (res.ok) {
      const cache = await caches.open(CACHE);
      cache.put(request, res.clone());
    }
    return res;
  } catch {
    return (await caches.match(request)) || offlineFallback(request);
  }
}

async function staleWhileRevalidate(request) {
  const cache  = await caches.open(CACHE);
  const cached = await cache.match(request);
  const fetchPromise = fetch(request).then(res => {
    if (res.ok) cache.put(request, res.clone());
    return res;
  }).catch(() => null);
  return cached || (await fetchPromise) || offlineFallback(request);
}

function offlineFallback(request) {
  if (request.destination === 'image') {
    return new Response(
      `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200">
        <rect width="200" height="200" fill="#E8E2D9"/>
        <text x="50%" y="50%" text-anchor="middle" fill="#aaa" font-size="13" font-family="sans-serif" dy=".3em">Offline</text>
      </svg>`,
      { headers: { 'Content-Type': 'image/svg+xml' } }
    );
  }
  return caches.match('./offline.html').then(c => c || new Response('Offline', { status: 503 }));
}

/* ── PUSH (fremtidigt) ── */
self.addEventListener('push', e => {
  if (!e.data) return;
  const d = e.data.json();
  e.waitUntil(self.registration.showNotification(d.title || 'Salon Webb', {
    body: d.body || '',
    icon: './icons/icon-192.png',
    badge: './icons/icon-192.png'
  }));
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.openWindow('./'));
});
