# CHANGELOG – Salon Webb
**Nordic Operations · nordicoperations.dk**

---

## v1.1.0 – 2026-06-24

### Forbedringer

**Mobilmenu:**
- Menu-links viser nu ikoner (emoji) ved siden af tekst
- Smooth scroll ved klik → sektion → menu lukker automatisk
- Hamburger animeres til × når menu er åben
- Escape-tast lukker menu

**Åbningstider:**
- Helligdage og særlige lukkedage understøttet
- Feriemeddelelse vises som note under åbningstider
- Admin: tilføj/slet helligdage med dato og beskrivelse

**QR-koder:**
- Nyt admin-panel: QR-koder
- 6 typer: Hjemmeside · Booking · Instagram · Facebook · Maps · Telefon
- Download PNG direkte fra admin
- Branded farver (mørk/lys)

**Mediakontrol:**
- Nyt admin-panel med automatisk kontrol
- Finder: manglende billeder, ikke-HTTPS URLs, manglende kontaktinfo

**Admin forbedringer:**
- Salon-navn redigerbart (synkroniseres til logo og footer)
- Eyebrow i hero redigerbar
- Site URL felt til QR-koder
- GDPR/NIS2/CRA compliance-note i indstillinger
- Login: rate-limit (5 forsøg), 4h session-timeout
- Input-sanitering (HTML-strip) i hele admin
- HTTPS-validering på billed-URLs i galleri

**Sikkerhed:**
- Adgangskodekrav: minimum 8 tegn (var 6)
- Login rate-limit via sessionStorage
- Input sanitering via `sanitize()`
- XSS-beskyttelse via `esc()` i al rendering
- URL-validering (kun HTTPS) ved billedupload

**Ny fil:**
- `OVERDRAGELSE.md` – komplet guide til kunden

---

## v1.0.0 – 2026-06-24

### Første produktion

**Public site:**
- Hero med parallax-baggrund og 4 CTA-knapper
- Behandlinger, Priser (tabs), Produkter, Team, Galleri, Åbningstider, Kontakt
- Lightbox med swipe og keyboard-navigation
- Fast mobilbjælke (🏠 Book Ring SMS Kort)
- PWA: install-prompt, offline-side, service worker
- Tilbud-banner

**Admin (15 panels):**
Dashboard, Forside, Behandlinger, Priser, Produkter, Team, Galleri, Åbningstider, Kontakt, Tilbud, SEO, Dokumenter, Backup, Testcenter, Indstillinger

**Standard login:**
- admin@salonwebb.dk / webb2026

---

*Bygget af Nordic Operations · nordicoperations.dk*
