# CHANGELOG – Salon Webb
**Nordic Operations · nordicoperations.dk**

---

## v1.1.0 – 2026-06-24

### Forbedringer

**Mobilmenu:**
- Menu-links viser nu ikoner (emoji) ved siden af tekst
- Smooth scroll ved klik → sektion → menu lukker automatisk
- Hamburger animeres til × når menu er åben
- Escape-tast lukker menu

**Åbningstider:**
- Helligdage og særlige lukkedage understøttet
- Feriemeddelelse vises som note under åbningstider
- Admin: tilføj/slet helligdage med dato og beskrivelse

**QR-koder:**
- Nyt admin-panel: QR-koder
- 6 typer: Hjemmeside · Booking · Instagram · Facebook · Maps · Telefon
- Download PNG direkte fra admin
- Branded farver (mørk/lys)

**Mediakontrol:**
- Nyt admin-panel med automatisk kontrol
- Finder: manglende billeder, ikke-HTTPS URLs, manglende kontaktinfo

**Admin forbedringer:**
- Salon-navn redigerbart (synkroniseres til logo og footer)
- Eyebrow i hero redigerbar
- Site URL felt til QR-koder
- GDPR/NIS2/CRA compliance-note i indstillinger
- Login: rate-limit (5 forsøg), 4h session-timeout
- Input-sanitering (HTML-strip) i hele admin
- HTTPS-validering på billed-URLs i galleri

**Sikkerhed:**
- Adgangskodekrav: minimum 8 tegn (var 6)
- Login rate-limit via sessionStorage
- Input sanitering via `sanitize()`
- XSS-beskyttelse via `esc()` i al rendering
- URL-validering (kun HTTPS) ved billedupload

**Ny fil:**
- `OVERDRAGELSE.md` – komplet guide til kunden

---

## v1.0.0 – 2026-06-24

### Første produktion

**Public site:**
- Hero med parallax-baggrund og 4 CTA-knapper
- Behandlinger, Priser (tabs), Produkter, Team, Galleri, Åbningstider, Kontakt
- Lightbox med swipe og keyboard-navigation
- Fast mobilbjælke (🏠 Book Ring SMS Kort)
- PWA: install-prompt, offline-side, service worker
- Tilbud-banner

**Admin (15 panels):**
Dashboard, Forside, Behandlinger, Priser, Produkter, Team, Galleri, Åbningstider, Kontakt, Tilbud, SEO, Dokumenter, Backup, Testcenter, Indstillinger

**Standard login:**
- admin@salonwebb.dk / webb2026

---

*Bygget af Nordic Operations · nordicoperations.dk*

## v1.2.0 – 2026-06-24

### Tilføjet indhold og rettelser

**Forsiden:**
- 3 indholdskort: Frisører · Atmosfære · Produkter
- Billede, hover-effekt, redigerbar tekst

**Rigtige data:**
- Telefon: 76 13 14 13
- Adresse: Bytoften 30, 6710 Esbjerg V
- Team: Heidi (indehaver) · Djannie (4. år) · Caroline (1. år)

**Produktbrands:**
- Kemon Actyva – tekst og billeder
- Evo – tekst og billeder
- Admin: tilføj brand, tekst, op til 4 produktbilleder

**Tilbud:**
- Ny sektion med tilbudskort
- Elev tilbud & månedens tilbud
- Admin: opret, sæt datoer, upload billede, skjul/vis

**Admin:**
- admin.html ved roden (kræves af brief)
- admin.js og admin.css ved roden
- Nyt panel: Om os / Indholdskort
- Nyt panel: Produktbrands
- Nyt panel: Tilbudsliste
- Footer admin-link → admin.html

## v1.2.2 – 2026-06-24

### Fejlretning

**Header:**
- Topbjælken genskabt med korrekt HTML-struktur (`<header class="site-header">`)
- Fast position, logo venstre, nav højre, Book-knap desktop
- Hamburger → X animation ved åben mobil menu
- Smooth scroll på alle nav-links

**Booking:**
- Alle book-links hardkodet i HTML: `https://salonwebb.bestilling.nu/`
- `target="_blank" rel="noopener noreferrer"` på alle
- Hero, header, mobilmenu, team-kort, kontakt, footer, mobilbjælke
- Ingen `href="#"` på booking-knapper

**Mobilbjælke:**
- Alle 5 links hardkodet (hjem, booking, ring, sms, maps)
- Ingen JavaScript-afhængighed

**Kontakt:**
- Telefon, SMS, adresse, booking hardkodet i HTML som fallback
- Dynamiske data (mail, Instagram, Facebook) injiceres af JS

**app.js:**
- Hardkodede fallback-konstanter: `BOOKING_URL`, `SALON_TLF`, `SALON_MAPS`
- Sikrer at booking virker selv ved tom localStorage

**styles.css:**
- Komplet omskrivning af header-CSS
- `body { padding-top: 64px }` – forhindrer indhold under header

**Versioner:** data.js, app.js, styles.css, index.html, service-worker.js, admin.html, admin.js
