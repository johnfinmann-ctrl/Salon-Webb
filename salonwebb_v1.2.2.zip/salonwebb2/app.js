/* ================================================================
   SALON WEBB – app.js v1.2.2
   Mobil-first PWA · Nordic Operations
   ================================================================ */
'use strict';

/* ── KONSTANTER – hardkodet som backup ── */
const BOOKING_URL = 'https://salonwebb.bestilling.nu/';
const SALON_TLF   = '+4576131413';
const SALON_MAPS  = 'https://maps.google.com/?q=Bytoften+30+6710+Esbjerg';

let D = {};
let galleriIdx = 0;
let deferredInstall = null;
let touchStartX = 0;

/* ══════════════════════════════════════
   BOOT
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  applyMeta();
  buildIndholdskort();
  buildPriser();
  buildProduktbrands();
  buildTeam();
  buildTilbudsliste();
  buildGalleri();
  buildHours();
  applyDynamicKontakt();
  applyTilbudBanner();
  initHeader();
  initMobileNav();
  initMobileBarHighlight();
  initLightbox();
  initParallax();
  initFadeIn();
  initPWA();
  checkOnline();
  document.getElementById('footer-year')
    && (document.getElementById('footer-year').textContent = new Date().getFullYear());
});

/* ══════════════════════════════════════
   DATA – med fallback til defaults
══════════════════════════════════════ */
function loadData() {
  try {
    const s = localStorage.getItem('sw_data');
    if (s) {
      D = JSON.parse(s);
      mergeDefaults(D, SW_DEFAULT_DATA);
    } else {
      D = deepCopy(SW_DEFAULT_DATA);
    }
  } catch {
    D = deepCopy(SW_DEFAULT_DATA);
  }
}
function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }
function mergeDefaults(t, s) {
  for (const k of Object.keys(s)) {
    if (!(k in t)) t[k] = deepCopy(s[k]);
    else if (typeof s[k]==='object'&&!Array.isArray(s[k])&&s[k]!==null&&typeof t[k]==='object'&&!Array.isArray(t[k]))
      mergeDefaults(t[k], s[k]);
  }
}

/* ══════════════════════════════════════
   META
══════════════════════════════════════ */
function applyMeta() {
  const m = D.meta;
  if (!m) return;
  document.title = m.seoTitel || m.salonNavn || 'Salon Webb';
  setMeta('description', m.seoBeskrivelse);
  setMeta('og:title',    m.seoTitel);
  setText('footer-version', 'v' + (m.version || '1.2.2'));
  // Opdatér logo-tekst fra data
  const logoEl = document.getElementById('header-logo');
  if (logoEl && m.salonNavn) logoEl.textContent = m.salonNavn;
}
function setMeta(name, val) {
  if (!val) return;
  document.querySelector(`meta[name="${name}"],meta[property="${name}"]`)?.setAttribute('content', val);
}

/* ══════════════════════════════════════
   HEADER – scroll + active highlight
══════════════════════════════════════ */
function initHeader() {
  const header = document.getElementById('site-header');
  if (!header) return;
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });

  // Smooth scroll på desktop nav-links
  header.querySelectorAll('.header-nav a').forEach(a => {
    a.addEventListener('click', e => {
      const href = a.getAttribute('href');
      if (!href || !href.startsWith('#')) return;
      e.preventDefault();
      smoothScrollTo(href);
    });
  });
}

/* ══════════════════════════════════════
   MOBIL NAVIGATION
══════════════════════════════════════ */
function initMobileNav() {
  const hamburger = document.getElementById('header-hamburger');
  const nav       = document.getElementById('mobile-nav');
  const closeBtn  = document.getElementById('mobile-nav-close');
  if (!hamburger || !nav) return;

  hamburger.addEventListener('click', () => {
    nav.classList.contains('hidden') ? openMobileNav() : closeMobileNav();
  });
  closeBtn?.addEventListener('click', closeMobileNav);
  nav.addEventListener('click', e => { if (e.target === nav) closeMobileNav(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && !nav.classList.contains('hidden')) closeMobileNav();
  });

  // Smooth scroll + luk ved link-klik
  nav.querySelectorAll('.mnav-link').forEach(a => {
    a.addEventListener('click', e => {
      const href = a.getAttribute('href');
      if (!href || !href.startsWith('#')) return;
      e.preventDefault();
      closeMobileNav();
      setTimeout(() => smoothScrollTo(href), 80);
    });
  });
}
function openMobileNav() {
  document.getElementById('mobile-nav')?.classList.remove('hidden');
  document.getElementById('header-hamburger')?.classList.add('open');
  document.getElementById('header-hamburger')?.setAttribute('aria-expanded','true');
  document.body.style.overflow = 'hidden';
}
function closeMobileNav() {
  document.getElementById('mobile-nav')?.classList.add('hidden');
  document.getElementById('header-hamburger')?.classList.remove('open');
  document.getElementById('header-hamburger')?.setAttribute('aria-expanded','false');
  document.body.style.overflow = '';
}
function smoothScrollTo(selector) {
  const target = document.querySelector(selector);
  if (!target) return;
  const top = target.getBoundingClientRect().top + window.scrollY - 72;
  window.scrollTo({ top, behavior: 'smooth' });
}

/* ══════════════════════════════════════
   INDHOLDSKORT
══════════════════════════════════════ */
function buildIndholdskort() {
  const grid = document.getElementById('indholdskort-grid');
  if (!grid) return;
  const list = (D.indholdskort || [])
    .filter(k => k.synlig !== false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  if (!list.length) { grid.innerHTML = ''; return; }
  grid.innerHTML = list.map(k => `
    <div class="ikort fade-in">
      <div class="ikort-img">
        ${k.billede
          ? `<img src="${esc(k.billede)}" alt="${esc(k.titel)}" loading="lazy"
               onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
          : ''}
        <div class="ikort-placeholder" ${k.billede ? 'style="display:none"' : ''}>
          ${esc(k.ikon || '✂️')}
        </div>
      </div>
      <div class="ikort-body">
        <p class="ikort-ikon" aria-hidden="true">${esc(k.ikon || '')}</p>
        <h3 class="ikort-titel">${esc(k.titel)}</h3>
        <p class="ikort-tekst">${esc(k.tekst)}</p>
      </div>
    </div>`).join('');
}

/* ══════════════════════════════════════
   PRISER
══════════════════════════════════════ */
function buildPriser() {
  const tabsEl = document.getElementById('price-tabs');
  const gridEl = document.getElementById('price-grid');
  if (!tabsEl || !gridEl || !D.priser) return;
  const kats = D.priser.kategorier || [];
  tabsEl.innerHTML = kats.map((k, i) =>
    `<button class="ptab${i===0?' active':''}" data-i="${i}">${esc(k)}</button>`
  ).join('');
  tabsEl.querySelectorAll('.ptab').forEach(btn => {
    btn.addEventListener('click', () => {
      tabsEl.querySelectorAll('.ptab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderPriser(kats[+btn.dataset.i]);
    });
  });
  renderPriser(kats[0]);
}
function renderPriser(kat) {
  const grid = document.getElementById('price-grid');
  if (!grid) return;
  const items = (D.priser.liste || [])
    .filter(p => p.kategori===kat && p.synlig!==false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = items.map(p => `
    <div class="price-card fade-in">
      <p class="pc-navn">${esc(p.navn)}</p>
      ${p.beskrivelse ? `<p class="pc-besk">${esc(p.beskrivelse)}</p>` : ''}
      <p class="pc-pris">${p.pris ? esc(p.pris)+' '+esc(p.enhed||'kr.') : esc(p.enhed||'')}</p>
    </div>`).join('')
    || '<p style="color:var(--text-dim);padding:12px 0">Ingen ydelser i denne kategori.</p>';
  initFadeIn();
}

/* ══════════════════════════════════════
   PRODUKTBRANDS
══════════════════════════════════════ */
function buildProduktbrands() {
  const grid = document.getElementById('produktbrands-grid');
  if (!grid) return;
  const list = (D.produktbrands || [])
    .filter(p => p.synlig !== false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map(p => {
    const imgs = (p.billeder || []).filter(Boolean);
    return `
    <div class="pbrand-card fade-in">
      <p class="pbrand-logo">${esc(p.brand)}</p>
      <p class="pbrand-tekst">${esc(p.tekst)}</p>
      <div class="pbrand-imgs">
        ${imgs.length
          ? imgs.map(src => `<img class="pbrand-img" src="${esc(src)}" alt="${esc(p.brand)}" loading="lazy"
              onerror="this.outerHTML='<div class=\\'pbrand-placeholder-img\\'>🛍️</div>'">`).join('')
          : '<div class="pbrand-placeholder-img">🛍️</div>'}
      </div>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   TEAM
══════════════════════════════════════ */
function buildTeam() {
  const grid = document.getElementById('team-grid');
  if (!grid) return;
  const bookUrl = (D.kontakt?.bookingUrl || BOOKING_URL).trim() || BOOKING_URL;
  const list = (D.team || [])
    .filter(t => t.synlig !== false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map(person => {
    const bookHref = (person.bookingLink || bookUrl).trim() || BOOKING_URL;
    const tlfHref  = person.tlf ? `tel:+45${person.tlf.replace(/\D/g,'')}` : '';
    const hasPhoto = !!person.foto;
    return `
    <div class="team-card fade-in">
      <div class="team-photo">
        ${hasPhoto
          ? `<img src="${esc(person.foto)}" alt="${esc(person.navn)}" loading="lazy"
               onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
          : ''}
        <div class="team-photo-placeholder" ${hasPhoto ? 'style="display:none"' : ''}>👤</div>
      </div>
      <div class="team-info">
        <p class="team-navn">${esc(person.navn)}</p>
        <p class="team-titel">${esc(person.titel)}</p>
        <p class="team-bio">${esc(person.bio)}</p>
        <div class="team-btns">
          <a href="${esc(bookHref)}" target="_blank" rel="noopener noreferrer"
             class="team-btn team-btn-book">📅 Book</a>
          ${tlfHref ? `<a href="${esc(tlfHref)}" class="team-btn team-btn-tlf">📞 Ring</a>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   TILBUDSLISTE
══════════════════════════════════════ */
function buildTilbudsliste() {
  // Intro-tekst sættes statisk i HTML – opdatér kun fra data hvis admin har ændret det
  const introEl = document.getElementById('tilbud-intro');
  if (introEl && D.tilbudIntro) introEl.innerHTML = D.tilbudIntro;

  const grid  = document.getElementById('tilbudskort-grid');
  const empty = document.getElementById('tilbud-empty');
  if (!grid) return;

  const now = new Date();
  const aktive = (D.tilbudsliste || []).filter(t => {
    if (!t.synlig) return false;
    if (t.startDato && new Date(t.startDato) > now) return false;
    if (t.slutDato  && new Date(t.slutDato)  < now) return false;
    return true;
  }).sort((a,b) => (a.sortering||0)-(b.sortering||0));

  if (!aktive.length) {
    grid.innerHTML = '';
    empty?.classList.remove('hidden');
    return;
  }
  empty?.classList.add('hidden');

  grid.innerHTML = aktive.map(t => {
    const datoTekst = t.slutDato
      ? `Gælder til ${new Date(t.slutDato).toLocaleDateString('da-DK')}` : '';
    return `
    <div class="tilbudskort fade-in">
      <span class="tilbudskort-badge">Tilbud</span>
      ${t.billede
        ? `<div class="tilbudskort-img">
             <img src="${esc(t.billede)}" alt="${esc(t.titel)}" loading="lazy"
               onerror="this.parentElement.outerHTML='<div class=\\'tilbudskort-img-placeholder\\'>🏷️</div>'">
           </div>`
        : '<div class="tilbudskort-img-placeholder">🏷️</div>'}
      <div class="tilbudskort-body">
        <h3 class="tilbudskort-titel">${esc(t.titel)}</h3>
        <p class="tilbudskort-tekst">${esc(t.tekst)}</p>
        ${datoTekst ? `<p class="tilbudskort-dato">🗓 ${esc(datoTekst)}</p>` : ''}
      </div>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   GALLERI
══════════════════════════════════════ */
function buildGalleri() {
  const grid = document.getElementById('galleri-grid');
  if (!grid) return;
  const list = (D.galleri || []).sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map((img, i) => `
    <div class="galleri-item fade-in" data-idx="${i}" role="button" tabindex="0"
         aria-label="${esc(img.titel || 'Galleri billede')}">
      ${img.url
        ? `<img src="${esc(img.url)}" alt="${esc(img.titel||'')}" loading="lazy"
             onerror="this.parentElement.innerHTML='<div class=\\'galleri-placeholder\\'>🖼️</div>'">`
        : '<div class="galleri-placeholder">🖼️</div>'}
    </div>`).join('');
  grid.querySelectorAll('.galleri-item').forEach(item => {
    item.addEventListener('click', () => openLightbox(+item.dataset.idx));
    item.addEventListener('keydown', e => { if (e.key==='Enter') openLightbox(+item.dataset.idx); });
  });
}

function initLightbox() {
  const lb = document.getElementById('lightbox'); if (!lb) return;
  document.getElementById('lb-close')?.addEventListener('click', closeLightbox);
  lb.addEventListener('click', e => { if (e.target===lb) closeLightbox(); });
  document.getElementById('lb-prev')?.addEventListener('click', () => moveLightbox(-1));
  document.getElementById('lb-next')?.addEventListener('click', () => moveLightbox(1));
  document.addEventListener('keydown', e => {
    if (lb.classList.contains('hidden')) return;
    if (e.key==='Escape') closeLightbox();
    if (e.key==='ArrowLeft') moveLightbox(-1);
    if (e.key==='ArrowRight') moveLightbox(1);
  });
  lb.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) moveLightbox(diff > 0 ? 1 : -1);
  }, { passive: true });
}
function openLightbox(idx) {
  const list=(D.galleri||[]).sort((a,b)=>(a.sortering||0)-(b.sortering||0));
  galleriIdx=idx;
  document.getElementById('lightbox')?.classList.remove('hidden');
  document.body.style.overflow='hidden';
  renderLightbox(list);
}
function closeLightbox() {
  document.getElementById('lightbox')?.classList.add('hidden');
  document.body.style.overflow='';
}
function moveLightbox(dir) {
  const list=(D.galleri||[]).sort((a,b)=>(a.sortering||0)-(b.sortering||0));
  galleriIdx=(galleriIdx+dir+list.length)%list.length;
  renderLightbox(list);
}
function renderLightbox(list) {
  const item=list[galleriIdx]; if(!item)return;
  const img=document.getElementById('lb-img');
  if(img){img.src=item.url||'';img.alt=item.titel||'';}
  setText('lb-caption',item.titel||'');
  const dots=document.getElementById('lb-dots');
  if(dots){
    dots.innerHTML=list.map((_,i)=>
      `<button class="lb-dot${i===galleriIdx?' active':''}" aria-label="Billede ${i+1}"></button>`
    ).join('');
    dots.querySelectorAll('.lb-dot').forEach((d,i)=>
      d.addEventListener('click',()=>{galleriIdx=i;renderLightbox(list);}));
  }
}

/* ══════════════════════════════════════
   ÅBNINGSTIDER
══════════════════════════════════════ */
function buildHours() {
  const grid=document.getElementById('hours-grid');
  const noteEl=document.getElementById('hours-note');
  if(!grid||!D.aabningstider)return;
  const now=new Date();
  const dayIdx=(now.getDay()+6)%7;
  const nowMins=now.getHours()*60+now.getMinutes();
  const todayISO=now.toISOString().slice(0,10);
  const helligdag=(D.helligdage||[]).find(h=>h.dato===todayISO);
  grid.innerHTML=D.aabningstider.map((h,i)=>{
    const isToday=i===dayIdx;
    const open=!h.lukket&&!helligdag&&nowMins>=toMins(h.aaben)&&nowMins<toMins(h.luk);
    const openNow=isToday&&open;
    let cls='hours-card';
    if(h.lukket||(isToday&&helligdag))cls+=' closed';
    if(openNow)cls+=' open-now';
    return `<div class="${cls}">
      <p class="hours-dag">${esc(h.dag.slice(0,3))}</p>
      <p class="hours-time">${h.lukket?'Lukket':h.aaben+'–'+h.luk}</p>
      ${openNow?'<span class="hours-badge">Åben nu</span>':''}
    </div>`;
  }).join('');
  if(noteEl){
    const note=helligdag?.navn||D.meta?.ferieTekst;
    if(note){noteEl.textContent='🗓 '+note;noteEl.classList.remove('hidden');}
  }
}
function toMins(t){if(!t)return 0;const[h,m]=t.split(':').map(Number);return h*60+(m||0);}

/* ══════════════════════════════════════
   KONTAKT – dynamisk opdatering
   (HTML har hardkodede fallback-links)
══════════════════════════════════════ */
function applyDynamicKontakt() {
  const k = D.kontakt;
  if (!k) return;

  // Mail (skjult som standard, vises kun hvis sat)
  if (k.mail) {
    const wrap = document.getElementById('kontakt-mail-wrap');
    const link = document.getElementById('kontakt-mail-link');
    if (wrap) wrap.style.display = 'flex';
    if (link) { link.href = `mailto:${k.mail}`; link.textContent = k.mail; }
  }

  // Sociale medier
  const igEl = document.getElementById('kontakt-ig');
  if (igEl && k.instagram) {
    igEl.href = k.instagram;
    igEl.style.display = 'inline-flex';
  }
  const fbEl = document.getElementById('kontakt-fb');
  if (fbEl && k.facebook) {
    fbEl.href = k.facebook;
    fbEl.style.display = 'inline-flex';
  }

  // Footer sociale medier
  const fIg = document.getElementById('footer-ig');
  if (fIg && k.instagram) { fIg.href = k.instagram; fIg.style.display = 'inline'; }
  const fFb = document.getElementById('footer-fb');
  if (fFb && k.facebook)  { fFb.href = k.facebook;  fFb.style.display = 'inline'; }

  // Maps link fra data (override hardkodet hvis sat)
  if (k.mapsUrl) {
    const ml = document.getElementById('maps-link');
    if (ml) ml.href = k.mapsUrl;
  }
}

/* ══════════════════════════════════════
   TILBUD BANNER
══════════════════════════════════════ */
function applyTilbudBanner() {
  const t = D.tilbud;
  if (!t?.aktiv || !t.tekst) return;
  const now = new Date();
  if (t.slutDato && new Date(t.slutDato) < now) return;
  if (t.startDato && new Date(t.startDato) > now) return;
  const banner = document.getElementById('tilbud-banner');
  if (!banner) return;
  setText('tilbud-tekst', t.tekst);
  if (t.farve) banner.style.background = t.farve;
  banner.classList.remove('hidden');
  document.getElementById('tilbud-luk')?.addEventListener('click',
    () => banner.classList.add('hidden'));
}

/* ══════════════════════════════════════
   PARALLAX
══════════════════════════════════════ */
function initParallax() {
  const bg = document.getElementById('hero-bg');
  if (!bg || window.matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        if (window.scrollY < window.innerHeight * 1.5)
          bg.style.transform = `translateY(${window.scrollY * .28}px)`;
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });
}

/* ══════════════════════════════════════
   FADE-IN
══════════════════════════════════════ */
function initFadeIn() {
  const els = document.querySelectorAll('.fade-in:not(.visible)');
  if (!els.length) return;
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); }
    });
  }, { threshold: .1 });
  els.forEach(el => obs.observe(el));
}

/* ══════════════════════════════════════
   MOBILE BAR HIGHLIGHT
══════════════════════════════════════ */
function initMobileBarHighlight() {
  const sectionIds = ['hjem','om-os','priser','produkter','team','tilbud','galleri','aabningstider','kontakt'];
  const items = document.querySelectorAll('.mb-item[data-sec]');
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting)
        items.forEach(item => item.classList.toggle('active', item.dataset.sec===e.target.id));
    });
  }, { threshold: .4 });
  sectionIds.forEach(id => { const el=document.getElementById(id); if(el) obs.observe(el); });
}

/* ══════════════════════════════════════
   PWA
══════════════════════════════════════ */
function initPWA() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('service-worker.js?v=1.2.2')
        .catch(e => console.warn('[SW]', e));
    });
  }
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault(); deferredInstall = e;
    setTimeout(showInstallPrompt, 4000);
  });
  window.addEventListener('appinstalled', () => {
    document.getElementById('install-prompt')?.classList.add('hidden');
    deferredInstall = null;
  });
}
function showInstallPrompt() {
  const p = document.getElementById('install-prompt');
  if (!p || sessionStorage.getItem('install-dismissed')) return;
  p.classList.remove('hidden');
  document.getElementById('ip-install')?.addEventListener('click', async () => {
    if (deferredInstall) { deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall=null; }
    p.classList.add('hidden');
  });
  document.getElementById('ip-dismiss')?.addEventListener('click', () => {
    p.classList.add('hidden'); sessionStorage.setItem('install-dismissed','1');
  });
  setTimeout(() => p?.classList.add('hidden'), 10000);
}

/* ══════════════════════════════════════
   ONLINE/OFFLINE
══════════════════════════════════════ */
function checkOnline() {
  const b = document.getElementById('offline-banner'); if (!b) return;
  const show=()=>{b.classList.remove('hidden');b.classList.add('visible');};
  const hide=()=>{b.classList.add('hidden');b.classList.remove('visible');};
  if (!navigator.onLine) show();
  window.addEventListener('online',  hide);
  window.addEventListener('offline', show);
}

/* ══════════════════════════════════════
   HELPERS
══════════════════════════════════════ */
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val ?? '';
}
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}
