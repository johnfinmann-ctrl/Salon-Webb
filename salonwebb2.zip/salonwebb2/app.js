/* ================================================================
   SALON WEBB – app.js v1.0.0
   Mobil-first PWA · Nordic Operations
   ================================================================ */
'use strict';

/* ── STATE ── */
let D = {};           // active data
let galleriIdx = 0;   // lightbox index
let priceTab = 0;     // active price tab index
let deferredInstall = null;
let touchStartX = 0;

/* ══════════════════════════════════════
   BOOT
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  applyMeta();
  buildNav();
  buildHero();
  buildBehandlinger();
  buildPriser();
  buildProdukter();
  buildTeam();
  buildGalleri();
  buildHours();
  buildKontakt();
  applyLinks();
  applyTilbud();
  initNav();
  initParallax();
  initLightbox();
  initMobileMenu();
  initMobileBarHighlight();
  initFadeIn();
  initPWA();
  checkOnline();
  setText('footer-year', new Date().getFullYear());
});

/* ══════════════════════════════════════
   DATA
══════════════════════════════════════ */
function loadData() {
  try {
    const saved = localStorage.getItem('sw_data');
    D = saved ? JSON.parse(saved) : deepCopy(SW_DEFAULT_DATA);
    // Merge in new keys from defaults (for updates)
    mergeDefaults(D, SW_DEFAULT_DATA);
  } catch {
    D = deepCopy(SW_DEFAULT_DATA);
  }
}
function saveData() {
  try { localStorage.setItem('sw_data', JSON.stringify(D)); } catch {}
}
function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }
function mergeDefaults(target, src) {
  for (const key of Object.keys(src)) {
    if (!(key in target)) target[key] = deepCopy(src[key]);
    else if (typeof src[key] === 'object' && !Array.isArray(src[key]) && src[key] !== null && typeof target[key] === 'object' && !Array.isArray(target[key])) {
      mergeDefaults(target[key], src[key]);
    }
  }
}

/* ══════════════════════════════════════
   META / SEO
══════════════════════════════════════ */
function applyMeta() {
  const m = D.meta;
  setText('page-title', m.seoTitel || m.salonNavn);
  document.title = m.seoTitel || m.salonNavn;
  setMeta('description', m.seoBeskrivelse);
  setMeta('og:title', m.seoTitel);
  setMeta('og:description', m.seoBeskrivelse);
  setText('footer-version', 'v' + m.version);
  if (m.themeColor) document.querySelector('meta[name="theme-color"]')?.setAttribute('content', m.themeColor);
}
function setMeta(name, val) {
  if (!val) return;
  const el = document.querySelector(`meta[name="${name}"],meta[property="${name}"]`);
  if (el) el.setAttribute('content', val);
}

/* ══════════════════════════════════════
   NAV
══════════════════════════════════════ */
function buildNav() {
  const ul = document.getElementById('nav-links');
  const mob = document.getElementById('mobile-menu-links');
  if (!ul || !D.menu) return;

  ul.innerHTML = D.menu.map(item =>
    `<li><a href="${esc(item.href)}">${esc(item.label)}</a></li>`
  ).join('');

  if (mob) {
    mob.innerHTML = D.menu.map(item =>
      `<li><a href="${esc(item.href)}">${esc(item.label)}</a></li>`
    ).join('');
    mob.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMobileMenu));
  }

  setAttr('nav-logo', 'textContent', D.meta.salonNavn);
  setText('nav-logo', D.meta.salonNavn);
}

function initNav() {
  const nav = document.getElementById('top-nav');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });
}

/* ══════════════════════════════════════
   MOBILE MENU
══════════════════════════════════════ */
function initMobileMenu() {
  const hamburger = document.getElementById('nav-hamburger');
  const overlay   = document.getElementById('mobile-menu-overlay');
  const close     = document.getElementById('mobile-menu-close');
  if (!hamburger || !overlay) return;
  hamburger.addEventListener('click', () => {
    overlay.classList.remove('hidden');
    hamburger.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  });
  close?.addEventListener('click', closeMobileMenu);
  overlay.addEventListener('click', e => { if (e.target === overlay) closeMobileMenu(); });
}
function closeMobileMenu() {
  document.getElementById('mobile-menu-overlay')?.classList.add('hidden');
  document.getElementById('nav-hamburger')?.setAttribute('aria-expanded','false');
  document.body.style.overflow = '';
}

/* ══════════════════════════════════════
   HERO
══════════════════════════════════════ */
function buildHero() {
  const h = D.hero;
  const bg = document.getElementById('hero-bg');
  if (bg && h.baggrund) bg.style.backgroundImage = `url('${h.baggrund}')`;
  setText('hero-title', h.overskrift || D.meta.salonNavn);
  setText('hero-sub', h.undertitel || D.meta.tagline);

  const k = D.kontakt;
  const btns = document.getElementById('hero-btns');
  if (!btns) return;

  const actionMap = {
    booking: k.bookingUrl,
    tlf:     `tel:+45${clean(k.tlf)}`,
    sms:     `sms:+45${clean(k.sms || k.tlf)}`,
    maps:    k.mapsUrl
  };
  const targetMap = { booking: '_blank', maps: '_blank' };

  btns.innerHTML = h.knapper.map((btn, i) => {
    const href   = actionMap[btn.type] || '#';
    const target = targetMap[btn.type] ? `target="${targetMap[btn.type]}" rel="noopener"` : '';
    const cls    = i === 0 ? 'hbtn hbtn-primary' : 'hbtn hbtn-ghost';
    return `<a href="${esc(href)}" ${target} class="${cls}">${esc(btn.ikon)} ${esc(btn.label)}</a>`;
  }).join('');
}

/* ══════════════════════════════════════
   BEHANDLINGER
══════════════════════════════════════ */
function buildBehandlinger() {
  const grid = document.getElementById('behandlinger-grid');
  if (!grid) return;
  const list = (D.behandlinger || []).filter(b => b.synlig !== false);
  grid.innerHTML = list.map(b => `
    <div class="beh-card fade-in">
      <div class="beh-ikon">${esc(b.ikon)}</div>
      <div>
        <p class="beh-navn">${esc(b.navn)}</p>
        <p class="beh-tekst">${esc(b.beskrivelse)}</p>
      </div>
    </div>`).join('');
}

/* ══════════════════════════════════════
   PRISER
══════════════════════════════════════ */
function buildPriser() {
  const tabsEl = document.getElementById('price-tabs');
  const gridEl = document.getElementById('price-grid');
  if (!tabsEl || !gridEl || !D.priser) return;

  const kats = D.priser.kategorier || [];
  tabsEl.innerHTML = kats.map((k, i) =>
    `<button class="ptab${i===0?' active':''}" data-i="${i}">${esc(k)}</button>`
  ).join('');

  tabsEl.querySelectorAll('.ptab').forEach(btn => {
    btn.addEventListener('click', () => {
      tabsEl.querySelectorAll('.ptab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      priceTab = +btn.dataset.i;
      renderPriser(kats[priceTab]);
    });
  });

  renderPriser(kats[0]);
}
function renderPriser(kat) {
  const grid = document.getElementById('price-grid');
  if (!grid) return;
  const items = (D.priser.liste || [])
    .filter(p => p.kategori === kat && p.synlig !== false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = items.map(p => `
    <div class="price-card fade-in">
      <p class="pc-navn">${esc(p.navn)}</p>
      ${p.beskrivelse ? `<p class="pc-besk">${esc(p.beskrivelse)}</p>` : ''}
      <p class="pc-pris">${p.pris ? esc(p.pris) + ' ' + esc(p.enhed||'kr.') : esc(p.enhed||'')}</p>
    </div>`).join('') || '<p style="color:var(--text-dim);padding:12px 0">Ingen ydelser i denne kategori.</p>';
  initFadeIn();
}

/* ══════════════════════════════════════
   PRODUKTER
══════════════════════════════════════ */
function buildProdukter() {
  const grid = document.getElementById('produkter-grid');
  if (!grid) return;
  const list = (D.produkter || [])
    .filter(p => p.synlig !== false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map(p => {
    const imgStyle = p.img ? `style="background-image:url('${p.img}')"` : '';
    return `
    <div class="prod-card fade-in">
      <div class="prod-img" ${imgStyle}>
        ${!p.img ? `<span class="prod-placeholder">${esc(p.brand)}</span>` : ''}
      </div>
      <div class="prod-info">
        <p class="prod-brand">${esc(p.brand)}</p>
        <p class="prod-navn">${esc(p.navn)}</p>
        ${p.tekst ? `<p class="prod-tekst">${esc(p.tekst)}</p>` : ''}
        ${p.pris ? `<p class="prod-pris">${esc(p.pris)}</p>` : ''}
      </div>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   TEAM
══════════════════════════════════════ */
function buildTeam() {
  const grid = document.getElementById('team-grid');
  if (!grid) return;
  const list = (D.team || [])
    .filter(t => t.synlig !== false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));

  grid.innerHTML = list.map(person => {
    const k = D.kontakt;
    const bookHref = person.bookingLink || k.bookingUrl;
    const tlfHref  = person.tlf ? `tel:+45${clean(person.tlf)}` : '';
    return `
    <div class="team-card fade-in">
      <div class="team-photo" style="${person.foto ? `background-image:url('${person.foto}')` : ''}">
        ${!person.foto ? '<div class="team-photo-placeholder">👤</div>' : ''}
      </div>
      <div class="team-info">
        <p class="team-navn">${esc(person.navn)}</p>
        <p class="team-titel">${esc(person.titel)}</p>
        <p class="team-bio">${esc(person.bio)}</p>
        <div class="team-btns">
          <a href="${esc(bookHref)}" target="_blank" rel="noopener" class="team-btn team-btn-book">📅 Book</a>
          ${tlfHref ? `<a href="${esc(tlfHref)}" class="team-btn team-btn-tlf">📞 Ring</a>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   GALLERI
══════════════════════════════════════ */
function buildGalleri() {
  const grid = document.getElementById('galleri-grid');
  if (!grid) return;
  const list = (D.galleri || []).sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map((img, i) => {
    const style = img.url ? `style="background-image:url('${img.url}')"` : '';
    return `
    <div class="galleri-item fade-in" data-idx="${i}" ${style} role="button" tabindex="0" aria-label="${esc(img.titel||'Galleri billede')}">
      ${!img.url ? '<div class="galleri-placeholder">🖼️</div>' : ''}
    </div>`;
  }).join('');

  grid.querySelectorAll('.galleri-item').forEach(item => {
    item.addEventListener('click', () => openLightbox(+item.dataset.idx));
    item.addEventListener('keydown', e => { if (e.key === 'Enter') openLightbox(+item.dataset.idx); });
  });
}

/* ══════════════════════════════════════
   LIGHTBOX
══════════════════════════════════════ */
function initLightbox() {
  const lb      = document.getElementById('lightbox');
  const close   = document.getElementById('lb-close');
  const prev    = document.getElementById('lb-prev');
  const next    = document.getElementById('lb-next');
  if (!lb) return;

  close?.addEventListener('click', closeLightbox);
  lb.addEventListener('click', e => { if (e.target === lb) closeLightbox(); });
  prev?.addEventListener('click', () => moveLightbox(-1));
  next?.addEventListener('click', () => moveLightbox(1));

  document.addEventListener('keydown', e => {
    if (lb.classList.contains('hidden')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') moveLightbox(-1);
    if (e.key === 'ArrowRight') moveLightbox(1);
  });

  // Touch swipe
  lb.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) moveLightbox(diff > 0 ? 1 : -1);
  }, { passive: true });
}
function openLightbox(idx) {
  const list = (D.galleri||[]).sort((a,b) => (a.sortering||0)-(b.sortering||0));
  galleriIdx = idx;
  const lb = document.getElementById('lightbox');
  lb?.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  renderLightbox(list);
}
function closeLightbox() {
  document.getElementById('lightbox')?.classList.add('hidden');
  document.body.style.overflow = '';
}
function moveLightbox(dir) {
  const list = (D.galleri||[]).sort((a,b) => (a.sortering||0)-(b.sortering||0));
  galleriIdx = (galleriIdx + dir + list.length) % list.length;
  renderLightbox(list);
}
function renderLightbox(list) {
  const img     = document.getElementById('lb-img');
  const caption = document.getElementById('lb-caption');
  const dots    = document.getElementById('lb-dots');
  const item    = list[galleriIdx];
  if (!item || !img) return;
  img.src = item.url || '';
  img.alt = item.titel || '';
  if (caption) caption.textContent = item.titel || '';
  if (dots) {
    dots.innerHTML = list.map((_, i) =>
      `<button class="lb-dot${i===galleriIdx?' active':''}" aria-label="Billede ${i+1}"></button>`
    ).join('');
    dots.querySelectorAll('.lb-dot').forEach((dot, i) => {
      dot.addEventListener('click', () => { galleriIdx = i; renderLightbox(list); });
    });
  }
}

/* ══════════════════════════════════════
   ÅBNINGSTIDER
══════════════════════════════════════ */
function buildHours() {
  const grid = document.getElementById('hours-grid');
  if (!grid || !D.aabningstider) return;
  const now     = new Date();
  const dayIdx  = (now.getDay() + 6) % 7;
  const nowMins = now.getHours() * 60 + now.getMinutes();

  grid.innerHTML = D.aabningstider.map((h, i) => {
    const isToday   = i === dayIdx;
    const openMins  = toMins(h.aaben);
    const closeMins = toMins(h.luk);
    const openNow   = isToday && !h.lukket && nowMins >= openMins && nowMins < closeMins;
    let cls = 'hours-card';
    if (h.lukket) cls += ' closed';
    if (openNow)  cls += ' open-now';
    return `
    <div class="${cls}">
      <p class="hours-dag">${esc(h.dag.slice(0,3))}</p>
      <p class="hours-time">${h.lukket ? 'Lukket' : h.aaben + '–' + h.luk}</p>
      ${openNow ? '<span class="hours-badge">Åben</span>' : ''}
    </div>`;
  }).join('');
}
function toMins(t) {
  if (!t) return 0;
  const [h,m] = t.split(':').map(Number);
  return h * 60 + (m||0);
}

/* ══════════════════════════════════════
   KONTAKT
══════════════════════════════════════ */
function buildKontakt() {
  const k    = D.kontakt;
  const info = document.getElementById('kontakt-info');
  if (!info) return;

  const tlfFmt = formatTlf(k.tlf);
  const smsFmt = formatTlf(k.sms || k.tlf);

  info.innerHTML = `
    <div class="kontakt-item">
      <span class="kontakt-ico">📍</span>
      <div>
        <p class="kontakt-lbl">Adresse</p>
        <p class="kontakt-val">${esc(k.adresse)}<br>${esc(k.by)}</p>
      </div>
    </div>
    <div class="kontakt-item">
      <span class="kontakt-ico">📞</span>
      <div>
        <p class="kontakt-lbl">Telefon</p>
        <a href="tel:+45${clean(k.tlf)}" class="kontakt-link kontakt-val">${esc(tlfFmt)}</a>
      </div>
    </div>
    <div class="kontakt-item">
      <span class="kontakt-ico">💬</span>
      <div>
        <p class="kontakt-lbl">SMS</p>
        <a href="sms:+45${clean(k.sms||k.tlf)}" class="kontakt-link kontakt-val">${esc(smsFmt)}</a>
      </div>
    </div>
    <div class="kontakt-item">
      <span class="kontakt-ico">✉️</span>
      <div>
        <p class="kontakt-lbl">E-mail</p>
        <a href="mailto:${esc(k.mail)}" class="kontakt-link kontakt-val">${esc(k.mail)}</a>
      </div>
    </div>
    <div class="social-row">
      <a href="${esc(k.instagram)}" target="_blank" rel="noopener" class="social-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="5"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>
        Instagram
      </a>
      <a href="${esc(k.facebook)}" target="_blank" rel="noopener" class="social-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
        Facebook
      </a>
    </div>`;

  // Map link
  const ml = document.getElementById('maps-link');
  if (ml && k.mapsUrl) ml.href = k.mapsUrl;
}

/* ══════════════════════════════════════
   LINKS (mobile bar + nav book btn)
══════════════════════════════════════ */
function applyLinks() {
  const k = D.kontakt;
  const tlf = `tel:+45${clean(k.tlf)}`;
  const sms = `sms:+45${clean(k.sms||k.tlf)}`;

  setHref('mb-book',  k.bookingUrl, true);
  setHref('mb-ring',  tlf);
  setHref('mb-sms',   sms);
  setHref('mb-kort',  k.mapsUrl, true);
  setHref('nav-book-btn', k.bookingUrl, true);
  setHref('mm-book',  k.bookingUrl, true);
  setHref('mm-tlf',   tlf);
  setHref('mm-sms',   sms);
  setHref('footer-fb', k.facebook, true);
  setHref('footer-ig', k.instagram, true);
  setHref('maps-link', k.mapsUrl, true);
}

/* ══════════════════════════════════════
   TILBUD BANNER
══════════════════════════════════════ */
function applyTilbud() {
  const t = D.tilbud;
  if (!t?.aktiv || !t.tekst) return;
  const now = new Date();
  if (t.slutDato && new Date(t.slutDato) < now) return;
  if (t.startDato && new Date(t.startDato) > now) return;

  const banner = document.getElementById('tilbud-banner');
  if (!banner) return;
  setText('tilbud-tekst', t.tekst);
  if (t.farve) banner.style.background = t.farve;
  banner.classList.remove('hidden');
  document.getElementById('tilbud-luk')?.addEventListener('click', () => banner.classList.add('hidden'));
}

/* ══════════════════════════════════════
   PARALLAX
══════════════════════════════════════ */
function initParallax() {
  const bg = document.getElementById('hero-bg');
  if (!bg || window.matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        if (window.scrollY < window.innerHeight * 1.5) {
          bg.style.transform = `translateY(${window.scrollY * 0.28}px)`;
        }
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });
}

/* ══════════════════════════════════════
   FADE-IN ON SCROLL
══════════════════════════════════════ */
function initFadeIn() {
  const els = document.querySelectorAll('.fade-in:not(.visible)');
  if (!els.length) return;
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); }
    });
  }, { threshold: 0.1 });
  els.forEach(el => obs.observe(el));
}

/* ══════════════════════════════════════
   MOBILE BAR HIGHLIGHT
══════════════════════════════════════ */
function initMobileBarHighlight() {
  const sectionIds = ['hjem','behandlinger','priser','produkter','team','galleri','aabningstider','kontakt'];
  const items = document.querySelectorAll('.mb-item[data-sec]');
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        items.forEach(item => item.classList.toggle('active', item.dataset.sec === e.target.id));
      }
    });
  }, { threshold: 0.4 });
  sectionIds.forEach(id => { const el = document.getElementById(id); if (el) obs.observe(el); });
}

/* ══════════════════════════════════════
   PWA
══════════════════════════════════════ */
function initPWA() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('service-worker.js?v=1.0.0')
        .then(r => console.log('[SW] registered:', r.scope))
        .catch(e => console.warn('[SW] failed:', e));
    });
  }
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredInstall = e;
    setTimeout(showInstallPrompt, 3000);
  });
  window.addEventListener('appinstalled', () => {
    document.getElementById('install-prompt')?.classList.add('hidden');
    deferredInstall = null;
  });
}
function showInstallPrompt() {
  const p = document.getElementById('install-prompt');
  if (!p || sessionStorage.getItem('install-dismissed')) return;
  p.classList.remove('hidden');
  document.getElementById('ip-install')?.addEventListener('click', async () => {
    if (deferredInstall) { deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; }
    p.classList.add('hidden');
  });
  document.getElementById('ip-dismiss')?.addEventListener('click', () => {
    p.classList.add('hidden');
    sessionStorage.setItem('install-dismissed','1');
  });
  setTimeout(() => p.classList.add('hidden'), 10000);
}

/* ══════════════════════════════════════
   ONLINE/OFFLINE
══════════════════════════════════════ */
function checkOnline() {
  const b = document.getElementById('offline-banner');
  if (!b) return;
  const show = () => { b.classList.remove('hidden'); b.classList.add('visible'); };
  const hide = () => { b.classList.add('hidden'); b.classList.remove('visible'); };
  if (!navigator.onLine) show();
  window.addEventListener('online', hide);
  window.addEventListener('offline', show);
}

/* ══════════════════════════════════════
   HELPERS
══════════════════════════════════════ */
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val ?? '';
}
function setAttr(id, attr, val) {
  const el = document.getElementById(id);
  if (el && val !== undefined) el[attr] = val;
}
function setHref(id, href, newTab) {
  const el = document.getElementById(id);
  if (!el || !href) return;
  el.href = href;
  if (newTab) { el.target = '_blank'; el.rel = 'noopener'; }
}
function clean(s) { return (s||'').replace(/\D/g,''); }
function formatTlf(s) {
  const c = clean(s);
  return c.replace(/(\d{2})(?=\d)/g,'$1 ').trim();
}
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
