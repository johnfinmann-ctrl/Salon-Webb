# CHANGELOG – Salon Webb
**Nordic Operations · nordicoperations.dk**

---

## v1.0.0 – 2026-06-24

### Første produktion

**Public site:**
- Komplet mobil-first PWA (HTML/CSS/JS – ingen frameworks)
- Hero med parallax-baggrund og 4 CTA-knapper (Book / Ring / SMS / Find vej)
- Hamburger-menu mobil + top-nav desktop med Book-knap
- Behandlinger-sektion med 6 ikon-kort
- Priser med kategori-tabs (Damer / Herrer / Børn / Behandlinger)
- Produkter-grid med brand-placeholder
- Team-kort med photo-placeholder ved manglende billede
- Galleri med lightbox, swipe og keyboard-navigation
- Åbningstider med live "Åben nu"-badge
- Kontakt med adresse, tlf, sms, mail, sociale medier og Maps-link
- QR-koder genereret via api.qrserver.com
- Tilbud-banner med dato-kontrol og farvestyring
- Fast mobilbjælke (🏠 Book Ring SMS Kort)
- PWA-installationsprompt (beforeinstallprompt)
- Offline-banner og offline.html fallback-side
- IntersectionObserver fade-in animationer
- Parallax-effekt på hero (RequestAnimationFrame)
- Versionering via `?v=` query strings

**Admin panel:**
- Nordic Operations standard admin med login/logout
- Session-timeout 4 timer
- 15 admin-panels:
  1. Dashboard – stats, status, hurtige links
  2. Forside – hero, knapper, baggrund
  3. Behandlinger – CRUD
  4. Priser – kategorier + CRUD
  5. Produkter – CRUD med billede-URL
  6. Team – CRUD med foto, booking-link, tlf
  7. Galleri – URL-tilføjelse, slet, grid-visning
  8. Åbningstider – time-pickers, lukket-toggle
  9. Kontakt – alle felter, QR-koder, test-links
  10. Tilbud – banner med toggle, datoer, farve, live preview
  11. SEO – titel, beskrivelse, OG, Google-preview
  12. Dokumenter – PDF/Word/Excel links
  13. Backup – JSON eksport/import, nulstil, data-oversigt
  14. Testcenter – 15 automatiske tests
  15. Indstillinger – brugerstyring, skift adgangskode, versionsnummer

**Teknisk:**
- Al kundedata i `data.js` som `SW_DEFAULT_DATA`
- localStorage persistens under nøgle `sw_data`
- Service Worker med cache-first + network-fallback
- Admin: network-first (altid frisk)
- Automatisk rydning af gamle caches ved aktivering
- Stale-while-revalidate for Unsplash og Google Fonts
- Offline billede-placeholder (SVG)
- Push notification-foundation (klar til v2)
- PWA manifest med shortcuts
- Relative stier (GitHub Pages kompatibel)
- XSS-safe via `esc()` funktion
- Ingen absolut sti, ingen hardcoded data

**Standard login:**
- E-mail: `admin@salonwebb.dk`
- Adgangskode: `webb2026`

---

## Planlagte opdateringer (v1.x)

- [ ] Rigtige salonbilleder fra kunden
- [ ] Korrekt telefonnummer og adresse
- [ ] Google Maps embed
- [ ] Egne PWA-ikoner med salon-logo
- [ ] Skift admin-adgangskode

---

*Bygget af Nordic Operations · nordicoperations.dk*
