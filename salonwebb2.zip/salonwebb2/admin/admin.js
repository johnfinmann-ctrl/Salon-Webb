/* ================================================================
   SALON WEBB ADMIN – admin.js v1.0.0
   Nordic Operations
   ================================================================ */
'use strict';

/* ══════════════════════════════════════
   STATE
══════════════════════════════════════ */
let D = {};
let currentPanel = 'dashboard';
let currentUser  = null;
const SESSION_KEY = 'sw_admin_session';
const DATA_KEY    = 'sw_data';
const BACKUP_KEY  = 'sw_last_backup';
let autoSaveTimer = null;

/* ══════════════════════════════════════
   BOOT
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  checkSession();
  initSidebar();
  initTopbar();
  initGlobalSave();
});

/* ══════════════════════════════════════
   DATA
══════════════════════════════════════ */
function loadData() {
  try {
    const s = localStorage.getItem(DATA_KEY);
    D = s ? JSON.parse(s) : deepCopy(SW_DEFAULT_DATA);
    mergeDefaults(D, SW_DEFAULT_DATA);
  } catch { D = deepCopy(SW_DEFAULT_DATA); }
}
function saveData() {
  localStorage.setItem(DATA_KEY, JSON.stringify(D));
  localStorage.setItem(BACKUP_KEY, new Date().toISOString());
  showToast('✓ Gemt');
  scheduleLogEntry('Data gemt');
}
function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }
function mergeDefaults(target, src) {
  for (const k of Object.keys(src)) {
    if (!(k in target)) target[k] = deepCopy(src[k]);
    else if (typeof src[k]==='object' && !Array.isArray(src[k]) && src[k]!==null && typeof target[k]==='object' && !Array.isArray(target[k])) {
      mergeDefaults(target[k], src[k]);
    }
  }
}

/* ══════════════════════════════════════
   SESSION / AUTH
══════════════════════════════════════ */
function checkSession() {
  const sess = sessionStorage.getItem(SESSION_KEY);
  if (sess) {
    try {
      currentUser = JSON.parse(sess);
      showApp();
      return;
    } catch {}
  }
  showLogin();
}
function showLogin() {
  document.getElementById('login-screen').classList.remove('hidden');
  document.getElementById('admin-app').classList.add('hidden');
  document.getElementById('login-form')?.addEventListener('submit', handleLogin);
}
function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  const pwd   = document.getElementById('login-pwd').value;
  const errEl = document.getElementById('login-error');
  const users = D.adminBrugere || SW_DEFAULT_DATA.adminBrugere;
  const user  = users.find(u => u.email === email && u.password === pwd);
  if (!user) {
    errEl.textContent = 'Forkert e-mail eller adgangskode.';
    errEl.classList.remove('hidden');
    return;
  }
  currentUser = { id: user.id, navn: user.navn, email: user.email, rolle: user.rolle };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  // Session timeout 4 hours
  setTimeout(logout, 4 * 60 * 60 * 1000);
  showApp();
}
function showApp() {
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('admin-app').classList.remove('hidden');
  if (currentUser) setText('sidebar-user', currentUser.navn || currentUser.email);
  document.getElementById('logout-btn')?.addEventListener('click', logout);
  navigateTo('dashboard');
}
function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  currentUser = null;
  location.reload();
}

/* ══════════════════════════════════════
   SIDEBAR & NAVIGATION
══════════════════════════════════════ */
function initSidebar() {
  document.querySelectorAll('.snav').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(link.dataset.panel);
      // Close on mobile
      document.getElementById('admin-sidebar')?.classList.remove('open');
    });
  });
  document.getElementById('sidebar-close')?.addEventListener('click', () => {
    document.getElementById('admin-sidebar')?.classList.remove('open');
  });
}
function initTopbar() {
  document.getElementById('topbar-hamburger')?.addEventListener('click', () => {
    document.getElementById('admin-sidebar')?.classList.toggle('open');
  });
}
function navigateTo(panelId) {
  currentPanel = panelId;
  // Update nav
  document.querySelectorAll('.snav').forEach(l => l.classList.toggle('active', l.dataset.panel === panelId));
  // Show panel
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === `panel-${panelId}`));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('hidden', p.id !== `panel-${panelId}`));
  // Update title
  const titles = {
    dashboard:'Dashboard', forside:'Forside', behandlinger:'Behandlinger',
    priser:'Priser', produkter:'Produkter', team:'Team',
    galleri:'Galleri', aabningstider:'Åbningstider', kontakt:'Kontakt',
    tilbud:'Tilbud', seo:'SEO', dokumenter:'Dokumenter',
    backup:'Backup', test:'Testcenter', indstillinger:'Indstillinger'
  };
  setText('topbar-title', titles[panelId] || panelId);
  // Render panel
  renderPanel(panelId);
}
function renderPanel(id) {
  switch(id) {
    case 'dashboard':     renderDashboard();      break;
    case 'forside':       renderForside();        break;
    case 'behandlinger':  renderBehandlinger();   break;
    case 'priser':        renderPriser();         break;
    case 'produkter':     renderProdukter();      break;
    case 'team':          renderTeam();           break;
    case 'galleri':       renderGalleri();        break;
    case 'aabningstider': renderAabningstider();  break;
    case 'kontakt':       renderKontakt();        break;
    case 'tilbud':        renderTilbud();         break;
    case 'seo':           renderSEO();            break;
    case 'dokumenter':    renderDokumenter();     break;
    case 'backup':        renderBackup();         break;
    case 'test':          renderTest();           break;
    case 'indstillinger': renderIndstillinger();  break;
  }
}

/* ══════════════════════════════════════
   GLOBAL SAVE
══════════════════════════════════════ */
function initGlobalSave() {
  document.getElementById('global-save')?.addEventListener('click', () => {
    collectCurrentPanel();
    saveData();
  });
}
function collectCurrentPanel() {
  switch(currentPanel) {
    case 'forside':       collectForside();       break;
    case 'kontakt':       collectKontakt();       break;
    case 'tilbud':        collectTilbud();        break;
    case 'seo':           collectSEO();           break;
    case 'aabningstider': collectAabningstider(); break;
    case 'indstillinger': collectIndstillinger(); break;
  }
}

/* ══════════════════════════════════════
   DASHBOARD
══════════════════════════════════════ */
function renderDashboard() {
  const stats = document.getElementById('dash-stats');
  if (stats) stats.innerHTML = `
    <div class="stat-card"><div class="stat-num">${(D.team||[]).filter(t=>t.synlig!==false).length}</div><div class="stat-lbl">Frisører</div></div>
    <div class="stat-card"><div class="stat-num">${(D.priser?.liste||[]).filter(p=>p.synlig!==false).length}</div><div class="stat-lbl">Priser</div></div>
    <div class="stat-card"><div class="stat-num">${(D.produkter||[]).filter(p=>p.synlig!==false).length}</div><div class="stat-lbl">Produkter</div></div>
    <div class="stat-card"><div class="stat-num">${(D.galleri||[]).length}</div><div class="stat-lbl">Galleri</div></div>`;

  const v = document.getElementById('dash-version');
  if (v) v.innerHTML = `
    <div class="status-item"><span class="status-dot status-ok"></span>Version ${esc(D.meta?.version||'1.0.0')}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Build ${esc(D.meta?.buildDate||'')}</div>
    <div class="status-item"><span class="status-dot ${D.tilbud?.aktiv?'status-ok':'status-warn'}"></span>Tilbud ${D.tilbud?.aktiv?'aktivt':'ikke aktivt'}</div>`;

  const backup = document.getElementById('dash-backup');
  const lastB = localStorage.getItem(BACKUP_KEY);
  if (backup) backup.innerHTML = lastB
    ? `<div class="status-item"><span class="status-dot status-ok"></span>${new Date(lastB).toLocaleString('da-DK')}</div>`
    : `<div class="status-item"><span class="status-dot status-warn"></span>Ingen backup endnu</div>`;

  const links = document.getElementById('dash-quick-links');
  if (links) links.innerHTML = `
    <a href="../" target="_blank" class="quick-link">👁 Se sitet</a>
    <a href="${esc(D.kontakt?.bookingUrl||'#')}" target="_blank" class="quick-link">📅 Test booking</a>
    <a href="${esc(D.kontakt?.instagram||'#')}" target="_blank" class="quick-link">📸 Instagram</a>
    <a href="${esc(D.kontakt?.facebook||'#')}" target="_blank" class="quick-link">👍 Facebook</a>`;

  const status = document.getElementById('dash-status');
  if (status) {
    const hasPhone = !!(D.kontakt?.tlf);
    const hasMail  = !!(D.kontakt?.mail);
    const hasBook  = !!(D.kontakt?.bookingUrl);
    const hasMaps  = !!(D.kontakt?.mapsUrl);
    status.innerHTML = `
      <div class="status-item"><span class="status-dot ${hasPhone?'status-ok':'status-err'}"></span>Telefon ${hasPhone?'OK':'mangler'}</div>
      <div class="status-item"><span class="status-dot ${hasMail?'status-ok':'status-err'}"></span>E-mail ${hasMail?'OK':'mangler'}</div>
      <div class="status-item"><span class="status-dot ${hasBook?'status-ok':'status-warn'}"></span>Booking ${hasBook?'OK':'ikke sat'}</div>
      <div class="status-item"><span class="status-dot ${hasMaps?'status-ok':'status-warn'}"></span>Maps ${hasMaps?'OK':'ikke sat'}</div>`;
  }
}

/* ══════════════════════════════════════
   FORSIDE
══════════════════════════════════════ */
function renderForside() {
  const h = D.hero || {};
  setVal('f-hero-overskrift', h.overskrift);
  setVal('f-hero-undertitel', h.undertitel);
  setVal('f-hero-baggrund',   h.baggrund);

  const knapList = document.getElementById('hero-knapper-list');
  if (knapList) {
    knapList.innerHTML = (h.knapper||[]).map((k,i) => `
      <div class="knap-row">
        <input type="text" placeholder="Ikon" value="${esc(k.ikon)}" data-ki="${i}" data-field="ikon" style="width:60px">
        <input type="text" placeholder="Label" value="${esc(k.label)}" data-ki="${i}" data-field="label">
        <select data-ki="${i}" data-field="type">
          ${['booking','tlf','sms','maps'].map(t=>`<option ${k.type===t?'selected':''}>${t}</option>`).join('')}
        </select>
      </div>`).join('');
  }
}
function collectForside() {
  D.hero = D.hero || {};
  D.hero.overskrift = getVal('f-hero-overskrift');
  D.hero.undertitel = getVal('f-hero-undertitel');
  D.hero.baggrund   = getVal('f-hero-baggrund');
  document.querySelectorAll('.knap-row [data-ki]').forEach(el => {
    const i = +el.dataset.ki;
    const f = el.dataset.field;
    if (D.hero.knapper[i]) D.hero.knapper[i][f] = el.tagName === 'SELECT' ? el.value : el.value;
  });
}

/* ══════════════════════════════════════
   BEHANDLINGER
══════════════════════════════════════ */
function renderBehandlinger() {
  const list = document.getElementById('behandlinger-list');
  if (!list) return;
  list.innerHTML = '';
  (D.behandlinger||[]).forEach((b,i) => {
    list.appendChild(makeItemCard({
      id: b.id, title: b.navn, badge: b.synlig!==false ? 'Synlig' : 'Skjult',
      fields: [
        { label: 'Ikon', key: 'ikon', val: b.ikon, type:'text', hint:'Emoji' },
        { label: 'Navn', key: 'navn', val: b.navn, type:'text' },
        { label: 'Beskrivelse', key: 'beskrivelse', val: b.beskrivelse, type:'textarea' },
        { label: 'Synlig', key: 'synlig', val: b.synlig!==false, type:'checkbox' }
      ],
      onSave: vals => { Object.assign(D.behandlinger[i], vals); saveData(); renderBehandlinger(); },
      onDelete: () => { D.behandlinger.splice(i,1); saveData(); renderBehandlinger(); }
    }));
  });
  document.getElementById('add-behandling')?.addEventListener('click', () => {
    D.behandlinger.push({ id:'beh'+Date.now(), navn:'Ny behandling', beskrivelse:'', ikon:'✂️', synlig:true });
    saveData(); renderBehandlinger();
  });
}

/* ══════════════════════════════════════
   PRISER
══════════════════════════════════════ */
function renderPriser() {
  // Categories
  const katList = document.getElementById('price-kats-list');
  if (katList) {
    katList.innerHTML = (D.priser.kategorier||[]).map((k,i) => `
      <span class="kat-tag">${esc(k)} <button data-ki="${i}" class="kat-del-btn">✕</button></span>`).join('');
    katList.querySelectorAll('.kat-del-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        D.priser.kategorier.splice(+btn.dataset.ki,1);
        saveData(); renderPriser();
      });
    });
  }
  document.getElementById('add-price-kat')?.addEventListener('click', () => {
    const n = prompt('Ny kategori:');
    if (n) { D.priser.kategorier.push(n.trim()); saveData(); renderPriser(); }
  });

  // Prices
  const list = document.getElementById('priser-list');
  if (!list) return;
  list.innerHTML = '';
  (D.priser.liste||[]).forEach((p,i) => {
    list.appendChild(makeItemCard({
      id: p.id, title: `${p.kategori} – ${p.navn}`,
      badge: p.synlig!==false ? 'Synlig' : 'Skjult',
      fields: [
        { label:'Kategori', key:'kategori', val:p.kategori, type:'select', options: D.priser.kategorier },
        { label:'Navn', key:'navn', val:p.navn, type:'text' },
        { label:'Beskrivelse', key:'beskrivelse', val:p.beskrivelse, type:'text' },
        { label:'Pris (tal)', key:'pris', val:p.pris, type:'text', hint:'Fx: 395' },
        { label:'Enhed', key:'enhed', val:p.enhed, type:'text', hint:'Fx: kr. eller efter aftale' },
        { label:'Synlig', key:'synlig', val:p.synlig!==false, type:'checkbox' }
      ],
      onSave: vals => { Object.assign(D.priser.liste[i], vals); saveData(); renderPriser(); },
      onDelete: () => { D.priser.liste.splice(i,1); saveData(); renderPriser(); }
    }));
  });
  document.getElementById('add-price')?.addEventListener('click', () => {
    const kat = D.priser.kategorier[0] || 'Damer';
    D.priser.liste.push({ id:'p'+Date.now(), kategori:kat, navn:'Ny ydelse', beskrivelse:'', pris:'', enhed:'kr.', synlig:true, sortering:99 });
    saveData(); renderPriser();
  });
}

/* ══════════════════════════════════════
   PRODUKTER
══════════════════════════════════════ */
function renderProdukter() {
  const list = document.getElementById('produkter-list');
  if (!list) return;
  list.innerHTML = '';
  (D.produkter||[]).forEach((p,i) => {
    list.appendChild(makeItemCard({
      id: p.id, title: `${p.brand} – ${p.navn}`,
      badge: p.synlig!==false ? 'Synlig' : 'Skjult',
      fields: [
        { label:'Brand', key:'brand', val:p.brand, type:'text' },
        { label:'Navn', key:'navn', val:p.navn, type:'text' },
        { label:'Tekst', key:'tekst', val:p.tekst, type:'text' },
        { label:'Pris', key:'pris', val:p.pris, type:'text', hint:'Fx: 189 kr.' },
        { label:'Billede URL', key:'img', val:p.img, type:'url', hint:'Unsplash eller ekstern URL' },
        { label:'Sortering', key:'sortering', val:p.sortering, type:'number' },
        { label:'Synlig', key:'synlig', val:p.synlig!==false, type:'checkbox' }
      ],
      onSave: vals => { Object.assign(D.produkter[i], vals); saveData(); renderProdukter(); },
      onDelete: () => { D.produkter.splice(i,1); saveData(); renderProdukter(); }
    }));
  });
  document.getElementById('add-produkt')?.addEventListener('click', () => {
    D.produkter.push({ id:'prod'+Date.now(), brand:'', navn:'Nyt produkt', tekst:'', pris:'', img:'', synlig:true, sortering:99 });
    saveData(); renderProdukter();
  });
}

/* ══════════════════════════════════════
   TEAM
══════════════════════════════════════ */
function renderTeam() {
  const list = document.getElementById('team-list');
  if (!list) return;
  list.innerHTML = '';
  (D.team||[]).forEach((t,i) => {
    list.appendChild(makeItemCard({
      id: t.id, title: `${t.navn} – ${t.titel}`,
      badge: t.synlig!==false ? 'Synlig' : 'Skjult',
      fields: [
        { label:'Navn', key:'navn', val:t.navn, type:'text' },
        { label:'Titel/rolle', key:'titel', val:t.titel, type:'text' },
        { label:'Bio', key:'bio', val:t.bio, type:'textarea' },
        { label:'Foto URL', key:'foto', val:t.foto, type:'url', hint:'Unsplash, GitHub eller ekstern URL' },
        { label:'Booking-link (tom = salonens standard)', key:'bookingLink', val:t.bookingLink, type:'url' },
        { label:'Direkte telefon (valgfri)', key:'tlf', val:t.tlf, type:'tel' },
        { label:'Sortering', key:'sortering', val:t.sortering, type:'number' },
        { label:'Synlig', key:'synlig', val:t.synlig!==false, type:'checkbox' }
      ],
      onSave: vals => { Object.assign(D.team[i], vals); saveData(); renderTeam(); },
      onDelete: () => { D.team.splice(i,1); saveData(); renderTeam(); }
    }));
  });
  document.getElementById('add-team')?.addEventListener('click', () => {
    D.team.push({ id:'t'+Date.now(), navn:'Ny frisør', titel:'Frisør', bio:'', foto:'', bookingLink:'', tlf:'', synlig:true, sortering:99 });
    saveData(); renderTeam();
  });
}

/* ══════════════════════════════════════
   GALLERI
══════════════════════════════════════ */
function renderGalleri() {
  const grid = document.getElementById('galleri-list');
  if (!grid) return;
  grid.innerHTML = (D.galleri||[]).map((img,i) => `
    <div class="galleri-admin-item">
      <img class="galleri-admin-img" src="${esc(img.url)}" alt="${esc(img.titel)}" loading="lazy"
        onerror="this.src='';this.style.background='#f0f0f0'">
      <div class="galleri-admin-overlay">
        <button class="galleri-admin-del" data-i="${i}">Slet</button>
      </div>
      <p class="galleri-admin-caption">${esc(img.titel||'')}</p>
    </div>`).join('');
  grid.querySelectorAll('.galleri-admin-del').forEach(btn => {
    btn.addEventListener('click', () => {
      if (confirm('Slet dette billede?')) {
        D.galleri.splice(+btn.dataset.i, 1);
        saveData(); renderGalleri();
      }
    });
  });
  document.getElementById('add-galleri-url')?.addEventListener('click', () => {
    const url   = document.getElementById('galleri-url-input')?.value?.trim();
    const titel = document.getElementById('galleri-titel-input')?.value?.trim();
    if (!url) return;
    D.galleri.push({ id:'g'+Date.now(), url, titel: titel||'', sortering: D.galleri.length+1 });
    saveData(); renderGalleri();
    if (document.getElementById('galleri-url-input')) document.getElementById('galleri-url-input').value = '';
    if (document.getElementById('galleri-titel-input')) document.getElementById('galleri-titel-input').value = '';
  });
}

/* ══════════════════════════════════════
   ÅBNINGSTIDER
══════════════════════════════════════ */
function renderAabningstider() {
  const list = document.getElementById('hours-admin-list');
  if (!list || !D.aabningstider) return;
  list.innerHTML = D.aabningstider.map((h,i) => `
    <div class="hours-admin-row${h.lukket?' lukket':''}">
      <span class="hours-admin-dag">${esc(h.dag)}</span>
      <input type="time" class="ah-aaben" data-i="${i}" value="${h.aaben}" ${h.lukket?'disabled':''}>
      <span style="font-size:.8rem;color:#999">–</span>
      <input type="time" class="ah-luk" data-i="${i}" value="${h.luk}" ${h.lukket?'disabled':''}>
      <label style="display:flex;align-items:center;gap:6px;font-size:.8rem;white-space:nowrap;cursor:pointer">
        <input type="checkbox" class="ah-lukket" data-i="${i}" ${h.lukket?'checked':''}>
        Lukket
      </label>
    </div>`).join('');

  list.querySelectorAll('.ah-lukket').forEach(cb => {
    cb.addEventListener('change', e => {
      const i = +e.target.dataset.i;
      D.aabningstider[i].lukket = e.target.checked;
      renderAabningstider();
    });
  });
  setVal('ferie-tekst', D.meta?.ferieTekst || '');
}
function collectAabningstider() {
  document.querySelectorAll('.ah-aaben').forEach(el => {
    D.aabningstider[+el.dataset.i].aaben = el.value;
  });
  document.querySelectorAll('.ah-luk').forEach(el => {
    D.aabningstider[+el.dataset.i].luk = el.value;
  });
  D.meta = D.meta || {};
  D.meta.ferieTekst = getVal('ferie-tekst');
}

/* ══════════════════════════════════════
   KONTAKT
══════════════════════════════════════ */
function renderKontakt() {
  const k = D.kontakt;
  setVal('k-tlf',       k.tlf);
  setVal('k-sms',       k.sms);
  setVal('k-mail',      k.mail);
  setVal('k-adresse',   k.adresse);
  setVal('k-by',        k.by);
  setVal('k-maps',      k.mapsUrl);
  setVal('k-booking',   k.bookingUrl);
  setVal('k-instagram', k.instagram);
  setVal('k-facebook',  k.facebook);

  // Test links
  setTestLink('test-maps',      k.mapsUrl);
  setTestLink('test-booking',   k.bookingUrl);
  setTestLink('test-instagram', k.instagram);
  setTestLink('test-facebook',  k.facebook);

  // QR codes
  const qrGrid = document.getElementById('qr-grid');
  if (qrGrid) {
    const qrItems = [
      { label: 'Booking',   url: k.bookingUrl },
      { label: 'Instagram', url: k.instagram  },
      { label: 'Facebook',  url: k.facebook   },
      { label: 'Maps',      url: k.mapsUrl    }
    ];
    qrGrid.innerHTML = qrItems.filter(q=>q.url).map(q => {
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(q.url)}`;
      return `
        <div class="qr-item">
          <img src="${esc(qrUrl)}" alt="QR ${esc(q.label)}" width="120" height="120" loading="lazy">
          <p class="qr-label">${esc(q.label)}</p>
          <a href="${esc(qrUrl)}" download="qr-${q.label.toLowerCase()}.png" style="font-size:.7rem;color:var(--gold-d);display:block;margin-top:3px">Download</a>
        </div>`;
    }).join('');
  }
}
function collectKontakt() {
  D.kontakt.tlf       = getVal('k-tlf');
  D.kontakt.sms       = getVal('k-sms') || getVal('k-tlf');
  D.kontakt.mail      = getVal('k-mail');
  D.kontakt.adresse   = getVal('k-adresse');
  D.kontakt.by        = getVal('k-by');
  D.kontakt.mapsUrl   = getVal('k-maps');
  D.kontakt.bookingUrl= getVal('k-booking');
  D.kontakt.instagram = getVal('k-instagram');
  D.kontakt.facebook  = getVal('k-facebook');
}
function setTestLink(id, url) {
  const el = document.getElementById(id);
  if (el) { el.href = url || '#'; el.style.display = url ? 'inline' : 'none'; }
}

/* ══════════════════════════════════════
   TILBUD
══════════════════════════════════════ */
function renderTilbud() {
  const t = D.tilbud || {};
  setChecked('tilbud-aktiv', t.aktiv);
  setVal('tilbud-tekst',  t.tekst);
  setVal('tilbud-start',  t.startDato);
  setVal('tilbud-slut',   t.slutDato);
  setVal('tilbud-farve',  t.farve || '#C9A96E');

  // Live preview
  const prev = document.getElementById('tilbud-prev-tekst');
  const banner = document.getElementById('tilbud-preview');
  if (prev && banner) {
    const updatePrev = () => {
      const txt = document.getElementById('tilbud-tekst')?.value;
      const farve = document.getElementById('tilbud-farve')?.value;
      prev.textContent = txt || 'Ingen aktiv kampagne';
      if (farve) banner.style.background = farve;
    };
    document.getElementById('tilbud-tekst')?.addEventListener('input', updatePrev);
    document.getElementById('tilbud-farve')?.addEventListener('input', updatePrev);
    updatePrev();
  }
}
function collectTilbud() {
  D.tilbud = D.tilbud || {};
  D.tilbud.aktiv     = document.getElementById('tilbud-aktiv')?.checked || false;
  D.tilbud.tekst     = getVal('tilbud-tekst');
  D.tilbud.startDato = getVal('tilbud-start');
  D.tilbud.slutDato  = getVal('tilbud-slut');
  D.tilbud.farve     = getVal('tilbud-farve');
}

/* ══════════════════════════════════════
   SEO
══════════════════════════════════════ */
function renderSEO() {
  const m = D.meta || {};
  setVal('seo-titel',      m.seoTitel);
  setVal('seo-beskrivelse',m.seoBeskrivelse);
  setVal('seo-og-billede', m.ogBillede);
  setVal('seo-salon-navn', m.salonNavn);
  setVal('seo-tagline',    m.tagline);
  setVal('seo-accent',     m.accentColor || '#C9A96E');
  setVal('seo-theme',      m.themeColor  || '#0E0E0E');

  // Live preview
  const updatePrev = () => {
    setText('gp-title', document.getElementById('seo-titel')?.value || '');
    setText('gp-desc',  document.getElementById('seo-beskrivelse')?.value?.slice(0,120) || '');
  };
  ['seo-titel','seo-beskrivelse'].forEach(id => document.getElementById(id)?.addEventListener('input', updatePrev));
  updatePrev();
}
function collectSEO() {
  D.meta = D.meta || {};
  D.meta.seoTitel      = getVal('seo-titel');
  D.meta.seoBeskrivelse= getVal('seo-beskrivelse');
  D.meta.ogBillede     = getVal('seo-og-billede');
  D.meta.salonNavn     = getVal('seo-salon-navn');
  D.meta.tagline       = getVal('seo-tagline');
  D.meta.accentColor   = getVal('seo-accent');
  D.meta.themeColor    = getVal('seo-theme');
}

/* ══════════════════════════════════════
   DOKUMENTER
══════════════════════════════════════ */
function renderDokumenter() {
  const list = document.getElementById('dokumenter-list');
  if (!list) return;
  list.innerHTML = '';
  (D.dokumenter||[]).forEach((dok,i) => {
    list.appendChild(makeItemCard({
      id: dok.id, title: dok.navn || 'Dokument',
      fields: [
        { label:'Navn', key:'navn', val:dok.navn, type:'text' },
        { label:'URL (download-link)', key:'url', val:dok.url, type:'url' },
        { label:'Type', key:'type', val:dok.type, type:'select', options:['PDF','Word','Excel','Andet'] }
      ],
      onSave: vals => { Object.assign(D.dokumenter[i], vals); saveData(); renderDokumenter(); },
      onDelete: () => { D.dokumenter.splice(i,1); saveData(); renderDokumenter(); }
    }));
  });
  document.getElementById('add-dokument')?.addEventListener('click', () => {
    D.dokumenter.push({ id:'dok'+Date.now(), navn:'', url:'', type:'PDF' });
    saveData(); renderDokumenter();
  });
}

/* ══════════════════════════════════════
   BACKUP
══════════════════════════════════════ */
function renderBackup() {
  // Data overview
  const ov = document.getElementById('data-overview');
  if (ov) ov.innerHTML = `
    <div class="status-item"><span class="status-dot status-ok"></span>Team: ${(D.team||[]).length} poster</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Priser: ${(D.priser?.liste||[]).length} ydelser</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Produkter: ${(D.produkter||[]).length} stk.</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Galleri: ${(D.galleri||[]).length} billeder</div>`;

  // Changelog
  const cl = document.getElementById('changelog-display');
  if (cl) cl.textContent = `Salon Webb – CHANGELOG
=====================================
v${D.meta?.version||'1.0.0'} – ${D.meta?.buildDate||'2026-06-24'}
  – Første produktion
  – Komplet PWA med Nordic Operations Admin
  – Team, priser, produkter, galleri, kontakt
  – Backup & restore
  – Testcenter
  – SEO & meta management
=====================================
Bygget af Nordic Operations · nordicoperations.dk`;

  // Buttons
  document.getElementById('btn-export')?.addEventListener('click', exportData);
  document.getElementById('btn-import')?.addEventListener('click', () => document.getElementById('import-file')?.click());
  document.getElementById('import-file')?.addEventListener('change', importData);
  document.getElementById('btn-reset')?.addEventListener('click', resetData);
}
function exportData() {
  const json = JSON.stringify(D, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `salonwebb-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  localStorage.setItem(BACKUP_KEY, new Date().toISOString());
  showToast('✓ JSON downloadet');
}
function importData(e) {
  const file = e.target.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = evt => {
    try {
      const imported = JSON.parse(evt.target.result);
      if (!imported.meta) throw new Error('Ugyldigt format');
      if (!confirm('Erstat al data med den importerede fil?')) return;
      D = imported;
      saveData();
      showToast('✓ Data importeret');
      navigateTo('dashboard');
    } catch { alert('Fejl: Kunne ikke importere filen. Kontroller at det er en gyldig backup-fil.'); }
  };
  reader.readAsText(file);
  e.target.value = '';
}
function resetData() {
  if (!confirm('Nulstil AL data til standardindhold? Denne handling kan ikke fortrydes.')) return;
  D = deepCopy(SW_DEFAULT_DATA);
  saveData();
  navigateTo('dashboard');
}

/* ══════════════════════════════════════
   TESTCENTER
══════════════════════════════════════ */
function renderTest() {
  const k = D.kontakt;
  const tests = [
    { navn: 'Telefon-link (tel:)',    status: k.tlf   ? 'ok'   : 'fail', note: k.tlf || 'Ikke sat',    href: k.tlf ? `tel:+45${k.tlf}` : null },
    { navn: 'SMS-link (sms:)',        status: k.sms||k.tlf ? 'ok' : 'fail', note: k.sms||k.tlf||'Ikke sat', href: null },
    { navn: 'E-mail (mailto:)',       status: k.mail  ? 'ok'   : 'fail', note: k.mail || 'Ikke sat',   href: k.mail ? `mailto:${k.mail}` : null },
    { navn: 'Booking URL',            status: k.bookingUrl ? 'ok' : 'warn', note: k.bookingUrl||'Ikke sat', href: k.bookingUrl },
    { navn: 'Google Maps URL',        status: k.mapsUrl    ? 'ok' : 'warn', note: k.mapsUrl||'Ikke sat',    href: k.mapsUrl },
    { navn: 'Instagram URL',          status: k.instagram  ? 'ok' : 'warn', note: k.instagram||'Ikke sat',  href: k.instagram },
    { navn: 'Facebook URL',           status: k.facebook   ? 'ok' : 'warn', note: k.facebook||'Ikke sat',   href: k.facebook },
    { navn: 'Team-billeder',          status: checkTeamPhotos() },
    { navn: 'Galleri-billeder',       status: (D.galleri||[]).length > 0 ? 'ok' : 'warn', note: `${(D.galleri||[]).length} billeder` },
    { navn: 'Priser opsat',           status: (D.priser?.liste||[]).length > 0 ? 'ok' : 'warn', note: `${(D.priser?.liste||[]).length} ydelser` },
    { navn: 'manifest.json',          status: 'ok', note: 'Fil til stede' },
    { navn: 'service-worker.js',      status: 'ok', note: 'Fil til stede' },
    { navn: 'Tilbud-banner',          status: D.tilbud?.aktiv ? 'ok' : 'skip', note: D.tilbud?.aktiv ? 'Aktivt' : 'Ikke aktivt' },
    { navn: 'SEO-titel sat',          status: D.meta?.seoTitel ? 'ok' : 'warn', note: D.meta?.seoTitel || 'Mangler' },
    { navn: 'Backup',                 status: localStorage.getItem(BACKUP_KEY) ? 'ok' : 'warn', note: localStorage.getItem(BACKUP_KEY) ? 'Eksisterer' : 'Ingen backup' }
  ];

  const results = document.getElementById('test-results');
  if (!results) return;
  results.innerHTML = tests.map(t => {
    const cls = { ok:'test-ok', warn:'test-warn', fail:'test-fail', skip:'test-skip' }[t.status] || 'test-skip';
    const ico = { ok:'✓', warn:'⚠', fail:'✕', skip:'–' }[t.status] || '–';
    return `
    <div class="test-item">
      <div class="test-status ${cls}">${ico}</div>
      <span class="test-name">${esc(t.navn)}</span>
      <span class="test-note">${esc(t.note||'')}</span>
      ${t.href ? `<a href="${esc(t.href)}" target="_blank" rel="noopener" class="test-link">Test ↗</a>` : ''}
    </div>`;
  }).join('');

  document.getElementById('run-all-tests')?.addEventListener('click', () => {
    renderTest();
    showToast(`${tests.filter(t=>t.status==='ok').length}/${tests.length} tests OK`);
  });
}
function checkTeamPhotos() {
  const team = D.team || [];
  const missing = team.filter(t => !t.foto && t.synlig !== false).length;
  return missing === 0 ? 'ok' : 'warn';
}

/* ══════════════════════════════════════
   INDSTILLINGER
══════════════════════════════════════ */
function renderIndstillinger() {
  setText('current-version', D.meta?.version || '1.0.0');
  setVal('new-version', D.meta?.version);

  // Users
  const list = document.getElementById('brugere-list');
  if (list) {
    list.innerHTML = (D.adminBrugere||[]).map((u,i) => `
      <div class="bruger-row">
        <span class="bruger-navn">${esc(u.navn)} · ${esc(u.email)}</span>
        <span class="bruger-rolle">${esc(u.rolle)}</span>
        ${D.adminBrugere.length > 1 ? `<button class="btn-danger del-bruger" data-i="${i}">Slet</button>` : ''}
      </div>`).join('');
    list.querySelectorAll('.del-bruger').forEach(btn => {
      btn.addEventListener('click', () => {
        if (confirm('Slet denne bruger?')) {
          D.adminBrugere.splice(+btn.dataset.i, 1);
          saveData(); renderIndstillinger();
        }
      });
    });
  }

  document.getElementById('add-bruger')?.addEventListener('click', () => {
    const email = prompt('E-mail:');
    if (!email) return;
    const navn = prompt('Navn:');
    const pwd  = prompt('Adgangskode (min. 6 tegn):');
    if (!pwd || pwd.length < 6) { alert('Adgangskoden er for kort.'); return; }
    D.adminBrugere.push({ id:'u'+Date.now(), navn:navn||email, email, password:pwd, rolle:'admin' });
    saveData(); renderIndstillinger();
  });

  document.getElementById('change-pwd-btn')?.addEventListener('click', () => {
    const p1 = document.getElementById('new-pwd')?.value;
    const p2 = document.getElementById('new-pwd2')?.value;
    if (!p1 || p1.length < 6) { alert('Min. 6 tegn.'); return; }
    if (p1 !== p2) { alert('Adgangskoderne matcher ikke.'); return; }
    const idx = D.adminBrugere.findIndex(u => u.id === currentUser?.id);
    if (idx >= 0) { D.adminBrugere[idx].password = p1; saveData(); showToast('✓ Adgangskode opdateret'); }
  });

  document.getElementById('bump-version-btn')?.addEventListener('click', () => {
    const v = document.getElementById('new-version')?.value?.trim();
    if (!v) return;
    D.meta.version = v;
    D.meta.buildDate = new Date().toISOString().slice(0,10);
    saveData(); renderIndstillinger();
    showToast(`✓ Version opdateret til ${v}`);
  });
}
function collectIndstillinger() {}

/* ══════════════════════════════════════
   ITEM CARD BUILDER
══════════════════════════════════════ */
function makeItemCard({ id, title, badge, fields, onSave, onDelete }) {
  const card = document.createElement('div');
  card.className = 'item-card';
  const isVisible = badge === 'Synlig';
  card.innerHTML = `
    <div class="item-card-header">
      <span class="item-card-drag" title="Træk for at sortere">⠿</span>
      <span class="item-card-title">${esc(title)}</span>
      <span class="item-card-badge ${isVisible?'synlig':'skjult'}">${esc(badge)}</span>
      <span class="item-card-toggle">▼</span>
    </div>
    <div class="item-card-body">
      ${fields.map(f => buildField(f)).join('')}
      <div class="item-actions">
        <button class="btn-secondary save-card-btn">Gem ændringer</button>
        <button class="btn-danger del-card-btn">Slet</button>
      </div>
    </div>`;

  // Toggle expand
  card.querySelector('.item-card-header').addEventListener('click', e => {
    if (e.target.closest('button')) return;
    const body = card.querySelector('.item-card-body');
    const toggle = card.querySelector('.item-card-toggle');
    body.classList.toggle('open');
    toggle?.classList.toggle('open');
  });

  card.querySelector('.save-card-btn')?.addEventListener('click', () => {
    const vals = {};
    fields.forEach(f => {
      const el = card.querySelector(`[data-key="${f.key}"]`);
      if (!el) return;
      if (f.type === 'checkbox') vals[f.key] = el.checked;
      else if (f.type === 'number') vals[f.key] = +el.value;
      else vals[f.key] = el.value.trim();
    });
    onSave(vals);
  });
  card.querySelector('.del-card-btn')?.addEventListener('click', () => {
    if (confirm('Slet denne post?')) onDelete();
  });
  return card;
}
function buildField(f) {
  if (f.type === 'textarea') return `
    <div class="field-group">
      <label>${esc(f.label)}</label>
      <textarea data-key="${esc(f.key)}" rows="3">${esc(f.val||'')}</textarea>
      ${f.hint ? `<span class="field-hint">${esc(f.hint)}</span>` : ''}
    </div>`;
  if (f.type === 'checkbox') return `
    <div class="field-group toggle-group">
      <label>${esc(f.label)}</label>
      <label class="toggle"><input type="checkbox" data-key="${esc(f.key)}" ${f.val?'checked':''}><span class="toggle-slider"></span></label>
    </div>`;
  if (f.type === 'select') return `
    <div class="field-group">
      <label>${esc(f.label)}</label>
      <select data-key="${esc(f.key)}">
        ${(f.options||[]).map(o=>`<option ${o===f.val?'selected':''}>${esc(o)}</option>`).join('')}
      </select>
    </div>`;
  return `
    <div class="field-group">
      <label>${esc(f.label)}</label>
      <input type="${f.type||'text'}" data-key="${esc(f.key)}" value="${esc(f.val||'')}">
      ${f.hint ? `<span class="field-hint">${esc(f.hint)}</span>` : ''}
    </div>`;
}

/* ══════════════════════════════════════
   LOG
══════════════════════════════════════ */
function scheduleLogEntry(msg) {
  // Lightweight in-memory log (no persistent storage needed for v1)
  console.info(`[Admin] ${new Date().toISOString()} – ${msg}`);
}

/* ══════════════════════════════════════
   HELPERS
══════════════════════════════════════ */
function showToast(msg) {
  const t = document.getElementById('save-toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(autoSaveTimer);
  autoSaveTimer = setTimeout(() => t.classList.add('hidden'), 2500);
}
function getVal(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, val) { const el = document.getElementById(id); if (el) el.value = val ?? ''; }
function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val ?? ''; }
function setChecked(id, val) { const el = document.getElementById(id); if (el) el.checked = !!val; }
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
