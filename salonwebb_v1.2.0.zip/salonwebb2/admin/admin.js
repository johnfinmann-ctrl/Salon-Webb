/* ================================================================
   SALON WEBB ADMIN – admin.js v1.1.0
   Nordic Operations · nordicoperations.dk
   ================================================================ */
'use strict';

let D = {};
let currentPanel = 'dashboard';
let currentUser  = null;
const SESSION_KEY = 'sw_admin_session';
const DATA_KEY    = 'sw_data';
const BACKUP_KEY  = 'sw_last_backup';
let toastTimer    = null;

/* ══════════════════════════════════════
   BOOT
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  checkSession();
  initSidebar();
  initTopbar();
  initGlobalSave();
});

/* ══════════════════════════════════════
   DATA
══════════════════════════════════════ */
function loadData() {
  try {
    const s = localStorage.getItem(DATA_KEY);
    D = s ? JSON.parse(s) : deepCopy(SW_DEFAULT_DATA);
    mergeDefaults(D, SW_DEFAULT_DATA);
  } catch { D = deepCopy(SW_DEFAULT_DATA); }
}
function saveData() {
  // Input validation before save
  if (D.kontakt?.tlf && !/^\d{8}$/.test(D.kontakt.tlf.replace(/\D/g,''))) {
    // Allow non-8-digit but warn
  }
  localStorage.setItem(DATA_KEY, JSON.stringify(D));
  localStorage.setItem(BACKUP_KEY, new Date().toISOString());
  showToast('✓ Gemt');
}
function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }
function mergeDefaults(t, s) {
  for (const k of Object.keys(s)) {
    if (!(k in t)) t[k] = deepCopy(s[k]);
    else if (typeof s[k]==='object'&&!Array.isArray(s[k])&&s[k]!==null&&typeof t[k]==='object'&&!Array.isArray(t[k]))
      mergeDefaults(t[k], s[k]);
  }
}

/* ══════════════════════════════════════
   SESSION
══════════════════════════════════════ */
function checkSession() {
  const s = sessionStorage.getItem(SESSION_KEY);
  if (s) { try { currentUser=JSON.parse(s); showApp(); return; } catch {} }
  showLogin();
}
function showLogin() {
  document.getElementById('login-screen').classList.remove('hidden');
  document.getElementById('admin-app').classList.add('hidden');
  document.getElementById('login-form')?.addEventListener('submit', handleLogin);
}
function handleLogin(e) {
  e.preventDefault();
  const email = sanitize(document.getElementById('login-email')?.value);
  const pwd   = document.getElementById('login-pwd')?.value;
  const errEl = document.getElementById('login-error');
  // Simple rate-limit via sessionStorage
  const attempts = +(sessionStorage.getItem('login_attempts')||0);
  if (attempts >= 5) {
    errEl.textContent = 'For mange forsøg. Genindlæs siden.';
    errEl.classList.remove('hidden'); return;
  }
  const users = D.adminBrugere || SW_DEFAULT_DATA.adminBrugere;
  const user  = users.find(u => u.email===email && u.password===pwd);
  if (!user) {
    sessionStorage.setItem('login_attempts', attempts+1);
    errEl.textContent = 'Forkert e-mail eller adgangskode.';
    errEl.classList.remove('hidden'); return;
  }
  sessionStorage.removeItem('login_attempts');
  currentUser = { id:user.id, navn:user.navn, email:user.email, rolle:user.rolle };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  setTimeout(logout, 4*60*60*1000); // 4h timeout
  showApp();
}
function showApp() {
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('admin-app').classList.remove('hidden');
  setText('sidebar-user', currentUser?.navn || currentUser?.email);
  document.getElementById('logout-btn')?.addEventListener('click', logout);
  navigateTo('dashboard');
}
function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  currentUser = null;
  location.reload();
}

/* ══════════════════════════════════════
   NAV
══════════════════════════════════════ */
function initSidebar() {
  document.querySelectorAll('.snav').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(link.dataset.panel);
      document.getElementById('admin-sidebar')?.classList.remove('open');
    });
  });
  document.getElementById('sidebar-close')?.addEventListener('click', () =>
    document.getElementById('admin-sidebar')?.classList.remove('open')
  );
}
function initTopbar() {
  document.getElementById('topbar-hamburger')?.addEventListener('click', () =>
    document.getElementById('admin-sidebar')?.classList.toggle('open')
  );
}
function navigateTo(id) {
  currentPanel = id;
  document.querySelectorAll('.snav').forEach(l => l.classList.toggle('active', l.dataset.panel===id));
  document.querySelectorAll('.panel').forEach(p => {
    const match = p.id===`panel-${id}`;
    p.classList.toggle('active', match);
    p.classList.toggle('hidden', !match);
  });
  const titles = {
    dashboard:'Dashboard', forside:'Forside', behandlinger:'Behandlinger',
    priser:'Priser', produkter:'Produkter', team:'Team', galleri:'Galleri',
    aabningstider:'Åbningstider', kontakt:'Kontakt', tilbud:'Tilbud',
    seo:'SEO', qr:'QR-koder', dokumenter:'Dokumenter',
    mediakontrol:'Mediakontrol', backup:'Backup', test:'Testcenter',
    indstillinger:'Indstillinger'
  };
  setText('topbar-title', titles[id]||id);
  renderPanel(id);
}
function renderPanel(id) {
  const map = {
    dashboard:renderDashboard, forside:renderForside,
    behandlinger:renderBehandlinger, priser:renderPriser,
    produkter:renderProdukter, team:renderTeam, galleri:renderGalleri,
    aabningstider:renderAabningstider, kontakt:renderKontakt,
    tilbud:renderTilbud, seo:renderSEO, qr:renderQR,
    dokumenter:renderDokumenter, mediakontrol:renderMediakontrol,
    backup:renderBackup, test:renderTest, indstillinger:renderIndstillinger
  };
  map[id]?.();
}

/* GLOBAL SAVE */
function initGlobalSave() {
  document.getElementById('global-save')?.addEventListener('click', () => {
    collectCurrentPanel();
    saveData();
  });
}
function collectCurrentPanel() {
  const map = {
    forside:collectForside, kontakt:collectKontakt,
    tilbud:collectTilbud, seo:collectSEO,
    aabningstider:collectAabningstider, indstillinger:collectIndstillinger
  };
  map[currentPanel]?.();
}

/* ══════════════════════════════════════
   DASHBOARD
══════════════════════════════════════ */
function renderDashboard() {
  const stats = document.getElementById('dash-stats');
  if (stats) stats.innerHTML = `
    <div class="stat-card"><div class="stat-num">${(D.team||[]).filter(t=>t.synlig!==false).length}</div><div class="stat-lbl">Frisører</div></div>
    <div class="stat-card"><div class="stat-num">${(D.priser?.liste||[]).filter(p=>p.synlig!==false).length}</div><div class="stat-lbl">Priser</div></div>
    <div class="stat-card"><div class="stat-num">${(D.produkter||[]).filter(p=>p.synlig!==false).length}</div><div class="stat-lbl">Produkter</div></div>
    <div class="stat-card"><div class="stat-num">${(D.galleri||[]).length}</div><div class="stat-lbl">Billeder</div></div>`;

  const ver = document.getElementById('dash-version');
  if (ver) ver.innerHTML = `
    <div class="status-item"><span class="status-dot status-ok"></span>v${esc(D.meta?.version||'1.1.0')}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Build: ${esc(D.meta?.buildDate||'2026-06-24')}</div>
    <div class="status-item"><span class="status-dot ${D.tilbud?.aktiv?'status-ok':'status-warn'}"></span>Tilbud: ${D.tilbud?.aktiv?'Aktivt':'Ikke aktivt'}</div>`;

  const lastB = localStorage.getItem(BACKUP_KEY);
  const bup = document.getElementById('dash-backup');
  if (bup) bup.innerHTML = lastB
    ? `<div class="status-item"><span class="status-dot status-ok"></span>${new Date(lastB).toLocaleString('da-DK')}</div>`
    : `<div class="status-item"><span class="status-dot status-warn"></span>Ingen backup endnu</div>`;

  const links = document.getElementById('dash-quick-links');
  if (links) links.innerHTML = `
    <a href="../" target="_blank" class="quick-link">👁 Se sitet</a>
    <a href="${esc(D.kontakt?.bookingUrl||'#')}" target="_blank" class="quick-link">📅 Test booking</a>
    <a href="${esc(D.kontakt?.instagram||'#')}" target="_blank" class="quick-link">📸 Instagram</a>
    <a href="${esc(D.kontakt?.facebook||'#')}" target="_blank" class="quick-link">👍 Facebook</a>`;

  const s = document.getElementById('dash-status');
  if (s) {
    const k = D.kontakt;
    s.innerHTML = `
      <div class="status-item"><span class="status-dot ${k?.tlf?'status-ok':'status-err'}"></span>Telefon</div>
      <div class="status-item"><span class="status-dot ${k?.mail?'status-ok':'status-err'}"></span>E-mail</div>
      <div class="status-item"><span class="status-dot ${k?.bookingUrl?'status-ok':'status-warn'}"></span>Booking</div>
      <div class="status-item"><span class="status-dot ${k?.mapsUrl?'status-ok':'status-warn'}"></span>Maps</div>
      <div class="status-item"><span class="status-dot ${k?.siteUrl||D.meta?.siteUrl?'status-ok':'status-warn'}"></span>Site URL til QR</div>`;
  }
}

/* ══════════════════════════════════════
   FORSIDE
══════════════════════════════════════ */
function renderForside() {
  setVal('f-salon-navn',       D.meta?.salonNavn);
  setVal('f-hero-overskrift',  D.hero?.overskrift);
  setVal('f-hero-undertitel',  D.hero?.undertitel);
  setVal('f-hero-eyebrow',     D.hero?.eyebrow);
  setVal('f-hero-baggrund',    D.hero?.baggrund);

  const kl = document.getElementById('hero-knapper-list');
  if (kl) kl.innerHTML = (D.hero?.knapper||[]).map((k,i) => `
    <div class="knap-row">
      <input type="text" placeholder="Ikon" value="${esc(k.ikon)}" data-ki="${i}" data-field="ikon" style="width:60px">
      <input type="text" placeholder="Label" value="${esc(k.label)}" data-ki="${i}" data-field="label">
      <select data-ki="${i}" data-field="type">
        ${['booking','tlf','sms','maps'].map(t=>`<option ${k.type===t?'selected':''}>${t}</option>`).join('')}
      </select>
    </div>`).join('');
}
function collectForside() {
  D.meta = D.meta||{};
  D.meta.salonNavn      = sanitize(getVal('f-salon-navn'));
  D.hero = D.hero||{};
  D.hero.overskrift     = sanitize(getVal('f-hero-overskrift'));
  D.hero.undertitel     = sanitize(getVal('f-hero-undertitel'));
  D.hero.eyebrow        = sanitize(getVal('f-hero-eyebrow'));
  D.hero.baggrund       = getVal('f-hero-baggrund'); // URL – no sanitize (breaks it)
  document.querySelectorAll('.knap-row [data-ki]').forEach(el => {
    const i=+el.dataset.ki; const f=el.dataset.field;
    if (D.hero.knapper[i]) D.hero.knapper[i][f] = el.tagName==='SELECT'?el.value:sanitize(el.value);
  });
}

/* ══════════════════════════════════════
   BEHANDLINGER
══════════════════════════════════════ */
function renderBehandlinger() {
  const list = document.getElementById('behandlinger-list');
  if (!list) return;
  list.innerHTML = '';
  (D.behandlinger||[]).forEach((b,i) => {
    list.appendChild(makeItemCard({
      title: b.navn, badge: b.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Ikon',key:'ikon',val:b.ikon,type:'text',hint:'Emoji fx ✂️'},
        {label:'Navn',key:'navn',val:b.navn,type:'text'},
        {label:'Beskrivelse',key:'beskrivelse',val:b.beskrivelse,type:'textarea'},
        {label:'Synlig',key:'synlig',val:b.synlig!==false,type:'checkbox'}
      ],
      onSave: v => { Object.assign(D.behandlinger[i],v); saveData(); renderBehandlinger(); },
      onDelete: () => { D.behandlinger.splice(i,1); saveData(); renderBehandlinger(); }
    }));
  });
  const btn = document.getElementById('add-behandling');
  btn?.replaceWith(btn.cloneNode(true));
  document.getElementById('add-behandling')?.addEventListener('click', () => {
    D.behandlinger.push({id:'beh'+Date.now(),navn:'Ny behandling',beskrivelse:'',ikon:'✂️',synlig:true});
    saveData(); renderBehandlinger();
  });
}

/* ══════════════════════════════════════
   PRISER
══════════════════════════════════════ */
function renderPriser() {
  // Kategorier
  const kl = document.getElementById('price-kats-list');
  if (kl) {
    kl.innerHTML = (D.priser.kategorier||[]).map((k,i)=>
      `<span class="kat-tag">${esc(k)} <button class="kat-del-btn" data-ki="${i}">✕</button></span>`
    ).join('');
    kl.querySelectorAll('.kat-del-btn').forEach(b =>
      b.addEventListener('click',()=>{D.priser.kategorier.splice(+b.dataset.ki,1);saveData();renderPriser();})
    );
  }
  const addKat = document.getElementById('add-price-kat');
  addKat?.replaceWith(addKat.cloneNode(true));
  document.getElementById('add-price-kat')?.addEventListener('click',()=>{
    const n=prompt('Ny kategori:'); if(n){D.priser.kategorier.push(sanitize(n.trim()));saveData();renderPriser();}
  });
  // Priser
  const list = document.getElementById('priser-list');
  if (!list) return;
  list.innerHTML='';
  (D.priser.liste||[]).forEach((p,i)=>{
    list.appendChild(makeItemCard({
      title:`${p.kategori} – ${p.navn}`, badge:p.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Kategori',key:'kategori',val:p.kategori,type:'select',options:D.priser.kategorier},
        {label:'Navn',key:'navn',val:p.navn,type:'text'},
        {label:'Beskrivelse',key:'beskrivelse',val:p.beskrivelse,type:'text'},
        {label:'Pris (tal)',key:'pris',val:p.pris,type:'text',hint:'Fx 395'},
        {label:'Enhed',key:'enhed',val:p.enhed,type:'text',hint:'Fx kr. eller efter aftale'},
        {label:'Synlig',key:'synlig',val:p.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{Object.assign(D.priser.liste[i],v);saveData();renderPriser();},
      onDelete:()=>{D.priser.liste.splice(i,1);saveData();renderPriser();}
    }));
  });
  const addP = document.getElementById('add-price');
  addP?.replaceWith(addP.cloneNode(true));
  document.getElementById('add-price')?.addEventListener('click',()=>{
    D.priser.liste.push({id:'p'+Date.now(),kategori:D.priser.kategorier[0]||'Damer',navn:'Ny ydelse',beskrivelse:'',pris:'',enhed:'kr.',synlig:true,sortering:99});
    saveData();renderPriser();
  });
}

/* ══════════════════════════════════════
   PRODUKTER
══════════════════════════════════════ */
function renderProdukter() {
  const list = document.getElementById('produkter-list');
  if (!list) return;
  list.innerHTML='';
  (D.produkter||[]).forEach((p,i)=>{
    list.appendChild(makeItemCard({
      title:`${p.brand} – ${p.navn}`, badge:p.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Brand',key:'brand',val:p.brand,type:'text'},
        {label:'Navn',key:'navn',val:p.navn,type:'text'},
        {label:'Beskrivelse',key:'tekst',val:p.tekst,type:'text'},
        {label:'Pris',key:'pris',val:p.pris,type:'text',hint:'Fx 189 kr.'},
        {label:'Billede URL (HTTPS)',key:'img',val:p.img,type:'url'},
        {label:'Sortering',key:'sortering',val:p.sortering,type:'number'},
        {label:'Synlig',key:'synlig',val:p.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{Object.assign(D.produkter[i],v);saveData();renderProdukter();},
      onDelete:()=>{D.produkter.splice(i,1);saveData();renderProdukter();}
    }));
  });
  const add=document.getElementById('add-produkt');
  add?.replaceWith(add.cloneNode(true));
  document.getElementById('add-produkt')?.addEventListener('click',()=>{
    D.produkter.push({id:'prod'+Date.now(),brand:'',navn:'Nyt produkt',tekst:'',pris:'',img:'',synlig:true,sortering:99});
    saveData();renderProdukter();
  });
}

/* ══════════════════════════════════════
   TEAM
══════════════════════════════════════ */
function renderTeam() {
  const list=document.getElementById('team-list');
  if(!list)return;
  list.innerHTML='';
  (D.team||[]).forEach((t,i)=>{
    list.appendChild(makeItemCard({
      title:`${t.navn} – ${t.titel}`, badge:t.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Navn',key:'navn',val:t.navn,type:'text'},
        {label:'Titel/rolle',key:'titel',val:t.titel,type:'text'},
        {label:'Bio',key:'bio',val:t.bio,type:'textarea'},
        {label:'Foto URL (HTTPS)',key:'foto',val:t.foto,type:'url',hint:'Placeholder vises automatisk ved broken image'},
        {label:'Booking-link (tom = salonens)',key:'bookingLink',val:t.bookingLink,type:'url'},
        {label:'Direkte telefon (valgfri)',key:'tlf',val:t.tlf,type:'tel'},
        {label:'Sortering',key:'sortering',val:t.sortering,type:'number'},
        {label:'Synlig / Aktiv',key:'synlig',val:t.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{Object.assign(D.team[i],v);saveData();renderTeam();},
      onDelete:()=>{D.team.splice(i,1);saveData();renderTeam();}
    }));
  });
  const add=document.getElementById('add-team');
  add?.replaceWith(add.cloneNode(true));
  document.getElementById('add-team')?.addEventListener('click',()=>{
    D.team.push({id:'t'+Date.now(),navn:'Ny frisør',titel:'Frisør',bio:'',foto:'',bookingLink:'',tlf:'',synlig:true,sortering:99});
    saveData();renderTeam();
  });
}

/* ══════════════════════════════════════
   GALLERI
══════════════════════════════════════ */
function renderGalleri() {
  const grid=document.getElementById('galleri-list');
  if(!grid)return;
  grid.innerHTML=(D.galleri||[]).map((img,i)=>`
    <div class="galleri-admin-item">
      <img class="galleri-admin-img" src="${esc(img.url)}" alt="${esc(img.titel)}" loading="lazy"
        onerror="this.style.background='#e0e0e0';this.removeAttribute('src')">
      <div class="galleri-admin-overlay">
        <button class="galleri-admin-del" data-i="${i}">Slet</button>
      </div>
      <p class="galleri-admin-caption">${esc(img.titel||'')}</p>
    </div>`).join('');
  grid.querySelectorAll('.galleri-admin-del').forEach(btn=>
    btn.addEventListener('click',()=>{
      if(confirm('Slet dette billede?')){D.galleri.splice(+btn.dataset.i,1);saveData();renderGalleri();}
    })
  );
  const addBtn=document.getElementById('add-galleri-url');
  addBtn?.replaceWith(addBtn.cloneNode(true));
  document.getElementById('add-galleri-url')?.addEventListener('click',()=>{
    const url=(document.getElementById('galleri-url-input')?.value||'').trim();
    const titel=(document.getElementById('galleri-titel-input')?.value||'').trim();
    // Validate HTTPS
    if(!url) return;
    if(!url.startsWith('https://')) { alert('Brug kun HTTPS-billeder'); return; }
    D.galleri.push({id:'g'+Date.now(),url,titel:sanitize(titel),sortering:D.galleri.length+1});
    saveData();renderGalleri();
    const ui=document.getElementById('galleri-url-input'); if(ui) ui.value='';
    const ti=document.getElementById('galleri-titel-input'); if(ti) ti.value='';
  });
}

/* ══════════════════════════════════════
   ÅBNINGSTIDER + HELLIGDAGE
══════════════════════════════════════ */
function renderAabningstider() {
  const list=document.getElementById('hours-admin-list');
  if(list&&D.aabningstider) {
    list.innerHTML=D.aabningstider.map((h,i)=>`
      <div class="hours-admin-row${h.lukket?' lukket':''}">
        <span class="hours-admin-dag">${esc(h.dag)}</span>
        <input type="time" class="ah-aaben" data-i="${i}" value="${h.aaben}" ${h.lukket?'disabled':''}>
        <span style="font-size:.8rem;color:#999">–</span>
        <input type="time" class="ah-luk" data-i="${i}" value="${h.luk}" ${h.lukket?'disabled':''}>
        <label style="display:flex;align-items:center;gap:5px;font-size:.8rem;cursor:pointer;white-space:nowrap">
          <input type="checkbox" class="ah-lukket" data-i="${i}" ${h.lukket?'checked':''}> Lukket
        </label>
      </div>`).join('');
    list.querySelectorAll('.ah-lukket').forEach(cb=>cb.addEventListener('change',e=>{
      D.aabningstider[+e.target.dataset.i].lukket=e.target.checked;
      renderAabningstider();
    }));
  }
  setVal('ferie-tekst', D.meta?.ferieTekst||'');

  // Helligdage
  renderHelligdage();
  const addH=document.getElementById('add-helligdag');
  addH?.replaceWith(addH.cloneNode(true));
  document.getElementById('add-helligdag')?.addEventListener('click',()=>{
    const dato=prompt('Dato (YYYY-MM-DD):');
    if(!dato||!/^\d{4}-\d{2}-\d{2}$/.test(dato)){alert('Ugyldig dato');return;}
    const navn=prompt('Beskrivelse:');
    if(!navn)return;
    D.helligdage=D.helligdage||[];
    D.helligdage.push({dato,navn:sanitize(navn)});
    D.helligdage.sort((a,b)=>a.dato.localeCompare(b.dato));
    saveData();renderAabningstider();
  });
}
function renderHelligdage() {
  const el=document.getElementById('helligdage-list');
  if(!el)return;
  el.innerHTML=(D.helligdage||[]).map((h,i)=>`
    <div class="helligdag-row">
      <span class="helligdag-dato">${esc(h.dato)}</span>
      <span class="helligdag-navn">${esc(h.navn)}</span>
      <button class="helligdag-del" data-i="${i}" title="Slet">✕</button>
    </div>`).join('') || '<p style="color:#999;font-size:.8rem">Ingen helligdage tilføjet</p>';
  el.querySelectorAll('.helligdag-del').forEach(btn=>btn.addEventListener('click',()=>{
    D.helligdage.splice(+btn.dataset.i,1); saveData(); renderHelligdage();
  }));
}
function collectAabningstider() {
  document.querySelectorAll('.ah-aaben').forEach(el=>{ D.aabningstider[+el.dataset.i].aaben=el.value; });
  document.querySelectorAll('.ah-luk').forEach(el=>{  D.aabningstider[+el.dataset.i].luk=el.value;  });
  D.meta=D.meta||{};
  D.meta.ferieTekst=sanitize(getVal('ferie-tekst'));
}

/* ══════════════════════════════════════
   KONTAKT
══════════════════════════════════════ */
function renderKontakt() {
  const k=D.kontakt;
  setVal('k-tlf',       k.tlf);
  setVal('k-sms',       k.sms);
  setVal('k-mail',      k.mail);
  setVal('k-adresse',   k.adresse);
  setVal('k-by',        k.by);
  setVal('k-maps',      k.mapsUrl);
  setVal('k-booking',   k.bookingUrl);
  setVal('k-instagram', k.instagram);
  setVal('k-facebook',  k.facebook);
  setVal('k-siteurl',   D.meta?.siteUrl||'');
  setTestLink('test-tlf',      `tel:+45${(k.tlf||'').replace(/\D/g,'')}`);
  setTestLink('test-mail',     `mailto:${k.mail||''}`);
  setTestLink('test-maps',     k.mapsUrl);
  setTestLink('test-booking',  k.bookingUrl);
  setTestLink('test-instagram',k.instagram);
  setTestLink('test-facebook', k.facebook);
}
function collectKontakt() {
  const k=D.kontakt;
  k.tlf       = getVal('k-tlf').replace(/\D/g,'');
  k.sms       = getVal('k-sms').replace(/\D/g,'') || k.tlf;
  k.mail      = getVal('k-mail');
  k.adresse   = sanitize(getVal('k-adresse'));
  k.by        = sanitize(getVal('k-by'));
  k.mapsUrl   = getVal('k-maps');
  k.bookingUrl= getVal('k-booking');
  k.instagram = getVal('k-instagram');
  k.facebook  = getVal('k-facebook');
  D.meta=D.meta||{};
  D.meta.siteUrl = getVal('k-siteurl');
}

/* ══════════════════════════════════════
   TILBUD
══════════════════════════════════════ */
function renderTilbud() {
  const t=D.tilbud||{};
  setChecked('tilbud-aktiv',  t.aktiv);
  setVal('tilbud-tekst',  t.tekst);
  setVal('tilbud-start',  t.startDato);
  setVal('tilbud-slut',   t.slutDato);
  setVal('tilbud-farve',  t.farve||'#C9A96E');
  const update=()=>{
    const txt=document.getElementById('tilbud-tekst')?.value;
    const farve=document.getElementById('tilbud-farve')?.value;
    setText('tilbud-prev-tekst', txt||'Ingen aktiv kampagne');
    const b=document.getElementById('tilbud-preview'); if(b&&farve) b.style.background=farve;
  };
  document.getElementById('tilbud-tekst')?.addEventListener('input',update);
  document.getElementById('tilbud-farve')?.addEventListener('input',update);
  update();
}
function collectTilbud() {
  D.tilbud=D.tilbud||{};
  D.tilbud.aktiv    =document.getElementById('tilbud-aktiv')?.checked||false;
  D.tilbud.tekst    =sanitize(getVal('tilbud-tekst'));
  D.tilbud.startDato=getVal('tilbud-start');
  D.tilbud.slutDato =getVal('tilbud-slut');
  D.tilbud.farve    =getVal('tilbud-farve');
}

/* ══════════════════════════════════════
   SEO
══════════════════════════════════════ */
function renderSEO() {
  const m=D.meta||{};
  setVal('seo-titel',      m.seoTitel);
  setVal('seo-beskrivelse',m.seoBeskrivelse);
  setVal('seo-og-billede', m.ogBillede);
  setVal('seo-tagline',    m.tagline);
  setVal('seo-accent',     m.accentColor||'#C9A96E');
  const up=()=>{
    setText('gp-title',document.getElementById('seo-titel')?.value||'');
    setText('gp-desc',(document.getElementById('seo-beskrivelse')?.value||'').slice(0,120));
  };
  ['seo-titel','seo-beskrivelse'].forEach(id=>document.getElementById(id)?.addEventListener('input',up));
  up();
}
function collectSEO() {
  D.meta=D.meta||{};
  D.meta.seoTitel      =sanitize(getVal('seo-titel'));
  D.meta.seoBeskrivelse=sanitize(getVal('seo-beskrivelse'));
  D.meta.ogBillede     =getVal('seo-og-billede');
  D.meta.tagline       =sanitize(getVal('seo-tagline'));
  D.meta.accentColor   =getVal('seo-accent');
}

/* ══════════════════════════════════════
   QR-KODER
══════════════════════════════════════ */
function renderQR() {
  const k=D.kontakt;
  const siteUrl = D.meta?.siteUrl || k?.bookingUrl || 'https://salonwebb.dk';
  const grid = document.getElementById('qr-main-grid');
  if (!grid) return;

  const qrItems = [
    { label:'Hjemmeside',   desc:'QR til forsiden af sitet',              url: siteUrl },
    { label:'Book tid',     desc:'QR direkte til bookingsystemet',         url: k?.bookingUrl||'' },
    { label:'Instagram',    desc:'QR til salonens Instagram profil',       url: k?.instagram||'' },
    { label:'Facebook',     desc:'QR til salonens Facebook side',          url: k?.facebook||'' },
    { label:'Google Maps',  desc:'QR til rutevejledning',                  url: k?.mapsUrl||'' },
    { label:'Ring til os',  desc:'QR der starter et opkald',               url: k?.tlf ? `tel:+45${(k.tlf).replace(/\D/g,'')}` : '' }
  ];

  grid.innerHTML = qrItems.map(q => {
    if (!q.url) return `
      <div class="qr-big-card">
        <h3>${esc(q.label)}</h3>
        <p>${esc(q.desc)}</p>
        <div style="width:120px;height:120px;background:#f0f0f0;margin:0 auto 12px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:.7rem;color:#999">Intet link</div>
        <p style="font-size:.72rem;color:#999">Sæt URL i Kontakt-panelet</p>
      </div>`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(q.url)}&color=0E0E0E&bgcolor=F7F4EF`;
    return `
      <div class="qr-big-card">
        <h3>${esc(q.label)}</h3>
        <p>${esc(q.desc)}</p>
        <img src="${esc(qrUrl)}" alt="QR ${esc(q.label)}" width="150" height="150" loading="lazy">
        <a href="${esc(qrUrl)}" download="qr-${q.label.toLowerCase().replace(/\s/g,'-')}.png" class="qr-download-btn">⬇ Download PNG</a>
      </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   DOKUMENTER
══════════════════════════════════════ */
function renderDokumenter() {
  const list=document.getElementById('dokumenter-list');
  if(!list)return;
  list.innerHTML='';
  (D.dokumenter||[]).forEach((d,i)=>{
    list.appendChild(makeItemCard({
      title:d.navn||'Dokument',
      fields:[
        {label:'Navn',key:'navn',val:d.navn,type:'text'},
        {label:'Download-link (HTTPS)',key:'url',val:d.url,type:'url'},
        {label:'Filtype',key:'type',val:d.type,type:'select',options:['PDF','Word','Excel','Andet']}
      ],
      onSave:v=>{Object.assign(D.dokumenter[i],v);saveData();renderDokumenter();},
      onDelete:()=>{D.dokumenter.splice(i,1);saveData();renderDokumenter();}
    }));
  });
  const add=document.getElementById('add-dokument');
  add?.replaceWith(add.cloneNode(true));
  document.getElementById('add-dokument')?.addEventListener('click',()=>{
    D.dokumenter.push({id:'dok'+Date.now(),navn:'',url:'',type:'PDF'});
    saveData();renderDokumenter();
  });
}

/* ══════════════════════════════════════
   MEDIAKONTROL
══════════════════════════════════════ */
function renderMediakontrol() {
  const btn=document.getElementById('run-media-check');
  btn?.replaceWith(btn.cloneNode(true));
  document.getElementById('run-media-check')?.addEventListener('click', runMediakontrol);
}
function runMediakontrol() {
  const results = document.getElementById('media-results');
  if (!results) return;
  results.innerHTML = '<p style="color:#999;font-size:.8rem;padding:12px 0">Kontrollerer...</p>';

  const issues = [];
  const ok = [];

  // Team photos
  const teamNoPhoto = (D.team||[]).filter(t=>!t.foto && t.synlig!==false);
  if (teamNoPhoto.length) issues.push({ico:'👤',title:`${teamNoPhoto.length} teammedlem(mer) mangler foto`,note:teamNoPhoto.map(t=>t.navn).join(', ')});
  else ok.push('Alle synlige teammedlemmer har foto');

  // Gallery
  const galleriNoUrl = (D.galleri||[]).filter(g=>!g.url);
  if (galleriNoUrl.length) issues.push({ico:'🖼️',title:`${galleriNoUrl.length} galleri-billeder mangler URL`,note:'Gå til Galleri-panelet og tilføj URL'});

  // Hero background
  if (!D.hero?.baggrund) issues.push({ico:'🏞️',title:'Hero-billede ikke sat',note:'Sæt baggrundsbillede i Forside-panelet'});
  else ok.push('Hero-billede er sat');

  // Non-HTTPS images
  const unsafeImgs = [];
  (D.galleri||[]).forEach(g=>{ if(g.url&&!g.url.startsWith('https://')) unsafeImgs.push(g.url); });
  (D.team||[]).forEach(t=>{ if(t.foto&&!t.foto.startsWith('https://')) unsafeImgs.push(t.navn); });
  (D.produkter||[]).forEach(p=>{ if(p.img&&!p.img.startsWith('https://')) unsafeImgs.push(p.navn); });
  if (unsafeImgs.length) issues.push({ico:'⚠️',title:'Billeder uden HTTPS',note:unsafeImgs.join(', ')});
  else ok.push('Alle billede-URLs bruger HTTPS');

  // Products without image
  const prodNoImg = (D.produkter||[]).filter(p=>!p.img&&p.synlig!==false);
  if (prodNoImg.length) issues.push({ico:'🛍️',title:`${prodNoImg.length} produkter mangler billede`,note:'Placeholder brand-navn vises i stedet – det er OK'});

  // Kontakt completeness
  const k=D.kontakt;
  if (!k?.tlf)       issues.push({ico:'📞',title:'Telefonnummer mangler',note:'Gå til Kontakt-panelet'});
  if (!k?.mail)      issues.push({ico:'✉️',title:'E-mail mangler',note:'Gå til Kontakt-panelet'});
  if (!k?.bookingUrl)issues.push({ico:'📅',title:'Booking-URL mangler',note:'Gå til Kontakt-panelet'});
  if (!k?.mapsUrl)   issues.push({ico:'🗺️',title:'Google Maps URL mangler',note:'Gå til Kontakt-panelet'});
  if (!D.meta?.siteUrl)issues.push({ico:'📱',title:'Site URL til QR mangler',note:'Sæt det i Kontakt-panelet under Site URL'});

  results.innerHTML = '';
  issues.forEach(item => {
    const div=document.createElement('div');
    div.className='media-issue';
    div.innerHTML=`<span class="media-ico">${esc(item.ico)}</span><div><p class="media-title">${esc(item.title)}</p><p class="media-note">${esc(item.note)}</p></div>`;
    results.appendChild(div);
  });
  ok.forEach(msg => {
    const div=document.createElement('div');
    div.className='media-issue media-ok';
    div.innerHTML=`<span class="media-ico">✅</span><div><p class="media-title">${esc(msg)}</p></div>`;
    results.appendChild(div);
  });
  if (!issues.length && ok.length) {
    const sum=document.createElement('p');
    sum.style.cssText='text-align:center;padding:20px;font-size:.9rem;color:#2e7d32;font-weight:600';
    sum.textContent='✓ Alt ser godt ud!';
    results.prepend(sum);
  } else if (issues.length) {
    const sum=document.createElement('p');
    sum.style.cssText='margin-bottom:12px;font-size:.82rem;color:#666';
    sum.textContent=`${issues.length} punkt(er) kræver opmærksomhed · ${ok.length} OK`;
    results.prepend(sum);
  }
}

/* ══════════════════════════════════════
   BACKUP
══════════════════════════════════════ */
function renderBackup() {
  const ov=document.getElementById('data-overview');
  if (ov) ov.innerHTML=`
    <div class="status-item"><span class="status-dot status-ok"></span>Team: ${(D.team||[]).length}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Priser: ${(D.priser?.liste||[]).length}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Produkter: ${(D.produkter||[]).length}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Galleri: ${(D.galleri||[]).length}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Helligdage: ${(D.helligdage||[]).length}</div>`;

  const cl=document.getElementById('changelog-display');
  if (cl) cl.textContent=`Salon Webb – CHANGELOG
v1.1.0 – 2026-06-24
  – Mobilmenu med ikoner og smooth scroll
  – Auto-luk menu ved valg
  – Hamburger animeres til X
  – Helligdage og ferie i åbningstider
  – QR-panel (6 typer) med download
  – Mediakontrol-panel
  – Site URL til QR-koder
  – Eyebrow redigérbar i admin
  – Salon-navn redigérbart i admin
  – HTTPS-validering af billed-URLs
  – GDPR/NIS2/CRA compliance-note
  – Login: rate-limit, 4h timeout
  – Input-sanitering i hele admin

v1.0.0 – 2026-06-24
  – Første produktion
  – Komplet PWA med Nordic Operations Admin
  – 15 admin-panels
  – Backup & restore, testcenter, SEO

Bygget af Nordic Operations · nordicoperations.dk`;

  const expBtn=document.getElementById('btn-export');
  expBtn?.replaceWith(expBtn.cloneNode(true));
  document.getElementById('btn-export')?.addEventListener('click',exportData);

  const impBtn=document.getElementById('btn-import');
  impBtn?.replaceWith(impBtn.cloneNode(true));
  document.getElementById('btn-import')?.addEventListener('click',()=>document.getElementById('import-file')?.click());
  document.getElementById('import-file')?.addEventListener('change',importData);

  const resBtn=document.getElementById('btn-reset');
  resBtn?.replaceWith(resBtn.cloneNode(true));
  document.getElementById('btn-reset')?.addEventListener('click',resetData);
}
function exportData() {
  const json=JSON.stringify(D,null,2);
  const blob=new Blob([json],{type:'application/json'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url; a.download=`salonwebb-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  localStorage.setItem(BACKUP_KEY, new Date().toISOString());
  showToast('✓ JSON downloadet');
}
function importData(e) {
  const file=e.target.files?.[0]; if(!file)return;
  const reader=new FileReader();
  reader.onload=evt=>{
    try {
      const imported=JSON.parse(evt.target.result);
      if(!imported.meta) throw new Error('Ugyldigt format');
      if(!confirm('Erstat AL data med importeret fil?')) return;
      D=imported; saveData();
      showToast('✓ Data importeret'); navigateTo('dashboard');
    } catch { alert('Fejl: Ugyldig backup-fil.'); }
  };
  reader.readAsText(file); e.target.value='';
}
function resetData() {
  if(!confirm('Nulstil AL data? Kan ikke fortrydes.')) return;
  D=deepCopy(SW_DEFAULT_DATA); saveData(); navigateTo('dashboard');
}

/* ══════════════════════════════════════
   TESTCENTER
══════════════════════════════════════ */
function renderTest() {
  const k=D.kontakt;
  const tests=[
    {navn:'Telefon-link (tel:)',     s:k?.tlf?'ok':'fail',  note:k?.tlf||'Ikke sat',       href:k?.tlf?`tel:+45${(k.tlf).replace(/\D/g,'')}`:null},
    {navn:'SMS-link (sms:)',         s:k?.sms||k?.tlf?'ok':'fail', note:k?.sms||k?.tlf||'Ikke sat'},
    {navn:'E-mail (mailto:)',        s:k?.mail?'ok':'fail', note:k?.mail||'Ikke sat',       href:k?.mail?`mailto:${k.mail}`:null},
    {navn:'Booking URL',             s:k?.bookingUrl?'ok':'warn',  note:k?.bookingUrl||'Ikke sat', href:k?.bookingUrl},
    {navn:'Google Maps URL',         s:k?.mapsUrl?'ok':'warn',     note:k?.mapsUrl||'Ikke sat',    href:k?.mapsUrl},
    {navn:'Instagram URL',           s:k?.instagram?'ok':'warn',   note:k?.instagram||'Ikke sat',  href:k?.instagram},
    {navn:'Facebook URL',            s:k?.facebook?'ok':'warn',    note:k?.facebook||'Ikke sat',   href:k?.facebook},
    {navn:'Site URL (til QR)',        s:D.meta?.siteUrl?'ok':'warn',note:D.meta?.siteUrl||'Ikke sat'},
    {navn:'Team-billeder',            s:checkTeamPhotos(),note:'Broken image placeholder er aktiv'},
    {navn:'Galleri (antal billeder)', s:(D.galleri||[]).length>0?'ok':'warn',note:`${(D.galleri||[]).length} billeder`},
    {navn:'Priser opsat',             s:(D.priser?.liste||[]).length>0?'ok':'warn',note:`${(D.priser?.liste||[]).length} ydelser`},
    {navn:'Hero-billede',             s:D.hero?.baggrund?'ok':'warn',note:D.hero?.baggrund?'OK':'Ikke sat'},
    {navn:'manifest.json',            s:'ok',note:'Fil til stede'},
    {navn:'service-worker.js',        s:'ok',note:'Fil til stede'},
    {navn:'Tilbud-banner',            s:D.tilbud?.aktiv?'ok':'skip',note:D.tilbud?.aktiv?'Aktivt':'Ikke aktivt'},
    {navn:'SEO-titel',                s:D.meta?.seoTitel?'ok':'warn',note:D.meta?.seoTitel||'Mangler'},
    {navn:'Backup',                   s:localStorage.getItem(BACKUP_KEY)?'ok':'warn',note:localStorage.getItem(BACKUP_KEY)?'Eksisterer':'Ingen backup endnu'},
    {navn:'Helligdage konfigureret', s:(D.helligdage||[]).length>0?'ok':'skip',note:`${(D.helligdage||[]).length} helligdage`}
  ];
  const results=document.getElementById('test-results');
  if(!results)return;
  results.innerHTML=tests.map(t=>{
    const cls={ok:'test-ok',warn:'test-warn',fail:'test-fail',skip:'test-skip'}[t.s]||'test-skip';
    const ico={ok:'✓',warn:'⚠',fail:'✕',skip:'–'}[t.s]||'–';
    return `<div class="test-item">
      <div class="test-status ${cls}">${ico}</div>
      <span class="test-name">${esc(t.navn)}</span>
      <span class="test-note">${esc(t.note||'')}</span>
      ${t.href?`<a href="${esc(t.href)}" target="_blank" rel="noopener" class="test-link">Test ↗</a>`:''}
    </div>`;
  }).join('');
  const runBtn=document.getElementById('run-all-tests');
  runBtn?.replaceWith(runBtn.cloneNode(true));
  document.getElementById('run-all-tests')?.addEventListener('click',()=>{
    renderTest();
    const ok=tests.filter(t=>t.s==='ok').length;
    showToast(`${ok}/${tests.length} tests OK`);
  });
}
function checkTeamPhotos() {
  return (D.team||[]).filter(t=>!t.foto&&t.synlig!==false).length===0?'ok':'warn';
}

/* ══════════════════════════════════════
   INDSTILLINGER
══════════════════════════════════════ */
function renderIndstillinger() {
  setText('current-version',D.meta?.version||'1.1.0');
  setVal('new-version',D.meta?.version);

  const list=document.getElementById('brugere-list');
  if(list) {
    list.innerHTML=(D.adminBrugere||[]).map((u,i)=>`
      <div class="bruger-row">
        <span class="bruger-navn">${esc(u.navn)} · ${esc(u.email)}</span>
        <span class="bruger-rolle">${esc(u.rolle)}</span>
        ${D.adminBrugere.length>1?`<button class="btn-danger del-bruger" data-i="${i}">Slet</button>`:''}
      </div>`).join('');
    list.querySelectorAll('.del-bruger').forEach(btn=>btn.addEventListener('click',()=>{
      if(confirm('Slet denne bruger?')){D.adminBrugere.splice(+btn.dataset.i,1);saveData();renderIndstillinger();}
    }));
  }

  const addB=document.getElementById('add-bruger');
  addB?.replaceWith(addB.cloneNode(true));
  document.getElementById('add-bruger')?.addEventListener('click',()=>{
    const email=prompt('E-mail:'); if(!email)return;
    const navn=prompt('Navn:');
    const pwd=prompt('Adgangskode (min. 8 tegn):');
    if(!pwd||pwd.length<8){alert('Adgangskoden er for kort (min. 8 tegn).');return;}
    D.adminBrugere.push({id:'u'+Date.now(),navn:sanitize(navn||email),email,password:pwd,rolle:'admin'});
    saveData();renderIndstillinger();
  });

  const chPwd=document.getElementById('change-pwd-btn');
  chPwd?.replaceWith(chPwd.cloneNode(true));
  document.getElementById('change-pwd-btn')?.addEventListener('click',()=>{
    const p1=document.getElementById('new-pwd')?.value;
    const p2=document.getElementById('new-pwd2')?.value;
    if(!p1||p1.length<8){alert('Min. 8 tegn.');return;}
    if(p1!==p2){alert('Adgangskoderne matcher ikke.');return;}
    const idx=D.adminBrugere.findIndex(u=>u.id===currentUser?.id);
    if(idx>=0){D.adminBrugere[idx].password=p1;saveData();showToast('✓ Adgangskode opdateret');}
  });

  const bumpBtn=document.getElementById('bump-version-btn');
  bumpBtn?.replaceWith(bumpBtn.cloneNode(true));
  document.getElementById('bump-version-btn')?.addEventListener('click',()=>{
    const v=getVal('new-version').trim();
    if(!v||!/^\d+\.\d+\.\d+$/.test(v)){alert('Ugyldig version. Brug format: 1.2.0');return;}
    D.meta.version=v; D.meta.buildDate=new Date().toISOString().slice(0,10);
    saveData();renderIndstillinger();
    showToast(`✓ Version ${v}`);
  });
}
function collectIndstillinger() {}

/* ══════════════════════════════════════
   ITEM CARD BUILDER
══════════════════════════════════════ */
function makeItemCard({title,badge,fields,onSave,onDelete}) {
  const card=document.createElement('div');
  card.className='item-card';
  const isOk=badge==='Synlig';
  card.innerHTML=`
    <div class="item-card-header">
      <span class="item-card-drag" title="Sortering">⠿</span>
      <span class="item-card-title">${esc(title)}</span>
      <span class="item-card-badge ${isOk?'synlig':'skjult'}">${esc(badge)}</span>
      <span class="item-card-toggle">▼</span>
    </div>
    <div class="item-card-body">
      ${fields.map(f=>buildField(f)).join('')}
      <div class="item-actions">
        <button class="btn-secondary save-card-btn">Gem</button>
        <button class="btn-danger del-card-btn">Slet</button>
      </div>
    </div>`;
  card.querySelector('.item-card-header').addEventListener('click',e=>{
    if(e.target.closest('button'))return;
    card.querySelector('.item-card-body')?.classList.toggle('open');
    card.querySelector('.item-card-toggle')?.classList.toggle('open');
  });
  card.querySelector('.save-card-btn')?.addEventListener('click',()=>{
    const vals={};
    fields.forEach(f=>{
      const el=card.querySelector(`[data-key="${f.key}"]`);
      if(!el)return;
      if(f.type==='checkbox') vals[f.key]=el.checked;
      else if(f.type==='number') vals[f.key]=+el.value;
      else vals[f.key]=f.type==='url'||f.type==='tel'?el.value.trim():sanitize(el.value.trim());
    });
    onSave(vals);
  });
  card.querySelector('.del-card-btn')?.addEventListener('click',()=>{
    if(confirm('Slet denne post?'))onDelete();
  });
  return card;
}
function buildField(f) {
  if(f.type==='textarea')return`<div class="field-group"><label>${esc(f.label)}</label><textarea data-key="${esc(f.key)}" rows="3">${esc(f.val||'')}</textarea>${f.hint?`<span class="field-hint">${esc(f.hint)}</span>`:''}</div>`;
  if(f.type==='checkbox')return`<div class="field-group toggle-group"><label>${esc(f.label)}</label><label class="toggle"><input type="checkbox" data-key="${esc(f.key)}" ${f.val?'checked':''}><span class="toggle-slider"></span></label></div>`;
  if(f.type==='select')return`<div class="field-group"><label>${esc(f.label)}</label><select data-key="${esc(f.key)}">${(f.options||[]).map(o=>`<option ${o===f.val?'selected':''}>${esc(o)}</option>`).join('')}</select></div>`;
  return`<div class="field-group"><label>${esc(f.label)}</label><input type="${f.type||'text'}" data-key="${esc(f.key)}" value="${esc(f.val||'')}"> ${f.hint?`<span class="field-hint">${esc(f.hint)}</span>`:''}</div>`;
}

/* ══════════════════════════════════════
   HELPERS
══════════════════════════════════════ */
function showToast(msg) {
  const t=document.getElementById('save-toast'); if(!t)return;
  t.textContent=msg; t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>t.classList.add('hidden'),2500);
}
function getVal(id) { return (document.getElementById(id)?.value||'').trim(); }
function setVal(id,val) { const el=document.getElementById(id); if(el) el.value=val??''; }
function setText(id,val) { const el=document.getElementById(id); if(el) el.textContent=val??''; }
function setChecked(id,val) { const el=document.getElementById(id); if(el) el.checked=!!val; }
function setTestLink(id,url) {
  const el=document.getElementById(id);
  if(!el)return;
  el.href=url||'#';
  el.style.display=url?'inline':'none';
  // href'er med tel:/mailto: skal ikke have target=_blank
  if(url&&(url.startsWith('tel:')||url.startsWith('mailto:'))) { el.removeAttribute('target'); }
  else if(url) { el.target='_blank'; el.rel='noopener'; }
}
/* Escape HTML output */
function esc(s) {
  if(s===null||s===undefined)return'';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
/* Sanitize user input – strip HTML tags */
function sanitize(s) {
  if(!s)return'';
  return String(s).replace(/<[^>]*>/g,'').replace(/[<>]/g,'').trim();
}
