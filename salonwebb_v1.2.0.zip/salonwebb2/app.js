/* ================================================================
   SALON WEBB – app.js v1.2.0
   Mobil-first PWA · Nordic Operations
   ================================================================ */
'use strict';

let D = {};
let galleriIdx  = 0;
let priceTab    = 0;
let deferredInstall = null;
let touchStartX = 0;

/* ══════════════════════════════════════
   BOOT
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  applyMeta();
  buildNav();
  buildHero();
  buildIndholdskort();
  buildBehandlinger();
  buildPriser();
  buildProduktbrands();
  buildTeam();
  buildTilbudsliste();
  buildGalleri();
  buildHours();
  buildKontakt();
  applyLinks();
  applyTilbudBanner();
  initNav();
  initParallax();
  initLightbox();
  initMobileMenu();
  initMobileBarHighlight();
  initFadeIn();
  initPWA();
  checkOnline();
  setText('footer-year', new Date().getFullYear());
});

/* ══════════════════════════════════════
   DATA
══════════════════════════════════════ */
function loadData() {
  try {
    const s = localStorage.getItem('sw_data');
    D = s ? JSON.parse(s) : deepCopy(SW_DEFAULT_DATA);
    mergeDefaults(D, SW_DEFAULT_DATA);
  } catch { D = deepCopy(SW_DEFAULT_DATA); }
}
function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }
function mergeDefaults(t, s) {
  for (const k of Object.keys(s)) {
    if (!(k in t)) t[k] = deepCopy(s[k]);
    else if (typeof s[k]==='object'&&!Array.isArray(s[k])&&s[k]!==null&&typeof t[k]==='object'&&!Array.isArray(t[k]))
      mergeDefaults(t[k], s[k]);
  }
}

/* ══════════════════════════════════════
   META
══════════════════════════════════════ */
function applyMeta() {
  const m = D.meta;
  document.title = m.seoTitel || m.salonNavn;
  setText('page-title', m.seoTitel || m.salonNavn);
  setMeta('description', m.seoBeskrivelse);
  setMeta('og:title', m.seoTitel);
  setMeta('og:description', m.seoBeskrivelse);
  setText('footer-version', 'v' + m.version);
  if (m.themeColor) document.querySelector('meta[name="theme-color"]')?.setAttribute('content', m.themeColor);
}
function setMeta(n, v) {
  if (!v) return;
  document.querySelector(`meta[name="${n}"],meta[property="${n}"]`)?.setAttribute('content', v);
}

/* ══════════════════════════════════════
   NAV
══════════════════════════════════════ */
function buildNav() {
  const ul  = document.getElementById('nav-links');
  const mob = document.getElementById('mobile-menu-links');
  if (!D.menu) return;

  if (ul) ul.innerHTML = D.menu.map(item =>
    `<li><a href="${esc(item.href)}">${esc(item.label)}</a></li>`
  ).join('');

  if (mob) {
    mob.innerHTML = D.menu.map(item =>
      `<li><a href="${esc(item.href)}">
        <span class="mm-nav-icon" aria-hidden="true">${esc(item.ikon||'')}</span>
        ${esc(item.label)}
      </a></li>`
    ).join('');
    mob.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', e => {
        e.preventDefault();
        closeMobileMenu();
        const target = document.querySelector(a.getAttribute('href'));
        if (target) {
          const top = target.getBoundingClientRect().top + window.scrollY - 80;
          window.scrollTo({ top, behavior: 'smooth' });
        }
      });
    });
  }

  setText('nav-logo', D.meta.salonNavn);
  setText('footer-logo', D.meta.salonNavn);
  setText('footer-sub', D.meta.tagline);
}

function initNav() {
  window.addEventListener('scroll', () => {
    document.getElementById('top-nav')?.classList.toggle('scrolled', window.scrollY > 60);
  }, { passive: true });
}

/* ══════════════════════════════════════
   MOBILE MENU
══════════════════════════════════════ */
function initMobileMenu() {
  const hamburger = document.getElementById('nav-hamburger');
  const overlay   = document.getElementById('mobile-menu-overlay');
  const close     = document.getElementById('mobile-menu-close');
  if (!hamburger || !overlay) return;
  hamburger.addEventListener('click', () => {
    overlay.classList.contains('hidden') ? openMobileMenu() : closeMobileMenu();
  });
  close?.addEventListener('click', closeMobileMenu);
  overlay.addEventListener('click', e => { if (e.target===overlay) closeMobileMenu(); });
  document.addEventListener('keydown', e => {
    if (e.key==='Escape' && !overlay.classList.contains('hidden')) closeMobileMenu();
  });
}
function openMobileMenu() {
  document.getElementById('mobile-menu-overlay')?.classList.remove('hidden');
  document.getElementById('nav-hamburger')?.classList.add('open');
  document.getElementById('nav-hamburger')?.setAttribute('aria-expanded','true');
  document.body.style.overflow = 'hidden';
}
function closeMobileMenu() {
  document.getElementById('mobile-menu-overlay')?.classList.add('hidden');
  document.getElementById('nav-hamburger')?.classList.remove('open');
  document.getElementById('nav-hamburger')?.setAttribute('aria-expanded','false');
  document.body.style.overflow = '';
}

/* ══════════════════════════════════════
   HERO
══════════════════════════════════════ */
function buildHero() {
  const h = D.hero; const k = D.kontakt;
  const bg = document.getElementById('hero-bg');
  if (bg && h.baggrund) bg.style.backgroundImage = `url('${h.baggrund}')`;
  setText('hero-title',   h.overskrift || D.meta.salonNavn);
  setText('hero-sub',     h.undertitel || D.meta.tagline);
  setText('hero-eyebrow', h.eyebrow || '');

  const actionMap = {
    booking: k.bookingUrl,
    tlf:  `tel:+45${clean(k.tlf)}`,
    sms:  `sms:+45${clean(k.sms||k.tlf)}`,
    maps: k.mapsUrl
  };
  const newTab = { booking: true, maps: true };
  const btns = document.getElementById('hero-btns');
  if (!btns) return;
  btns.innerHTML = h.knapper.map((btn, i) => {
    const href   = actionMap[btn.type] || '#';
    const tgt    = newTab[btn.type] ? 'target="_blank" rel="noopener"' : '';
    const cls    = i===0 ? 'hbtn hbtn-primary' : 'hbtn hbtn-ghost';
    return `<a href="${esc(href)}" ${tgt} class="${cls}">${esc(btn.ikon)} ${esc(btn.label)}</a>`;
  }).join('');
}

/* ══════════════════════════════════════
   INDHOLDSKORT (3 kort om os)
══════════════════════════════════════ */
function buildIndholdskort() {
  const grid = document.getElementById('indholdskort-grid');
  if (!grid) return;
  const list = (D.indholdskort||[])
    .filter(k => k.synlig !== false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map(k => `
    <div class="ikort fade-in">
      <div class="ikort-img">
        ${k.billede
          ? `<img src="${esc(k.billede)}" alt="${esc(k.titel)}" loading="lazy"
               onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
          : ''}
        <div class="ikort-img-placeholder" ${k.billede?'style="display:none"':''}>
          ${esc(k.ikon||'✂️')}
        </div>
      </div>
      <div class="ikort-body">
        <p class="ikort-ikon">${esc(k.ikon||'')}</p>
        <h3 class="ikort-titel">${esc(k.titel)}</h3>
        <p class="ikort-tekst">${esc(k.tekst)}</p>
      </div>
    </div>`).join('');
}

/* ══════════════════════════════════════
   BEHANDLINGER
══════════════════════════════════════ */
function buildBehandlinger() {
  const grid = document.getElementById('behandlinger-grid');
  if (!grid) return;
  const list = (D.behandlinger||[]).filter(b => b.synlig !== false);
  grid.innerHTML = list.map(b => `
    <div class="beh-card fade-in">
      <div class="beh-ikon">${esc(b.ikon)}</div>
      <div>
        <p class="beh-navn">${esc(b.navn)}</p>
        <p class="beh-tekst">${esc(b.beskrivelse)}</p>
      </div>
    </div>`).join('');
}

/* ══════════════════════════════════════
   PRISER
══════════════════════════════════════ */
function buildPriser() {
  const tabsEl = document.getElementById('price-tabs');
  const gridEl = document.getElementById('price-grid');
  if (!tabsEl || !gridEl || !D.priser) return;
  const kats = D.priser.kategorier || [];
  tabsEl.innerHTML = kats.map((k, i) =>
    `<button class="ptab${i===0?' active':''}" data-i="${i}">${esc(k)}</button>`
  ).join('');
  tabsEl.querySelectorAll('.ptab').forEach(btn => {
    btn.addEventListener('click', () => {
      tabsEl.querySelectorAll('.ptab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      priceTab = +btn.dataset.i;
      renderPriser(kats[priceTab]);
    });
  });
  renderPriser(kats[0]);
}
function renderPriser(kat) {
  const grid = document.getElementById('price-grid');
  if (!grid) return;
  const items = (D.priser.liste||[])
    .filter(p => p.kategori===kat && p.synlig!==false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = items.map(p => `
    <div class="price-card fade-in">
      <p class="pc-navn">${esc(p.navn)}</p>
      ${p.beskrivelse?`<p class="pc-besk">${esc(p.beskrivelse)}</p>`:''}
      <p class="pc-pris">${p.pris ? esc(p.pris)+' '+esc(p.enhed||'kr.') : esc(p.enhed||'')}</p>
    </div>`).join('')
    || '<p style="color:var(--text-dim);padding:12px 0">Ingen ydelser i denne kategori.</p>';
  initFadeIn();
}

/* ══════════════════════════════════════
   PRODUKTBRANDS
══════════════════════════════════════ */
function buildProduktbrands() {
  const grid = document.getElementById('produktbrands-grid');
  if (!grid) return;
  const list = (D.produktbrands||[])
    .filter(p => p.synlig !== false)
    .sort((a,b) => (a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map(p => {
    const imgs = (p.billeder||[]).filter(Boolean);
    return `
    <div class="pbrand-card fade-in">
      <p class="pbrand-logo">${esc(p.brand)}</p>
      <p class="pbrand-tekst">${esc(p.tekst)}</p>
      ${imgs.length ? `<div class="pbrand-imgs">${imgs.map(src =>
        `<img class="pbrand-img" src="${esc(src)}" alt="${esc(p.brand)}" loading="lazy"
          onerror="this.outerHTML='<div class=\\'pbrand-placeholder-img\\'>🛍️</div>'">`
      ).join('')}</div>` : `<div class="pbrand-imgs"><div class="pbrand-placeholder-img">🛍️</div></div>`}
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   TEAM
══════════════════════════════════════ */
function buildTeam() {
  const grid = document.getElementById('team-grid');
  if (!grid) return;
  const k = D.kontakt;
  const list = (D.team||[]).filter(t=>t.synlig!==false).sort((a,b)=>(a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map(person => {
    const bookHref = person.bookingLink || k.bookingUrl;
    const tlfHref  = person.tlf ? `tel:+45${clean(person.tlf)}` : '';
    const hasPhoto = !!person.foto;
    return `
    <div class="team-card fade-in">
      <div class="team-photo">
        ${hasPhoto
          ? `<img src="${esc(person.foto)}" alt="${esc(person.navn)}" loading="lazy"
               onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
          : ''}
        <div class="team-photo-placeholder" ${hasPhoto?'style="display:none"':''}>👤</div>
      </div>
      <div class="team-info">
        <p class="team-navn">${esc(person.navn)}</p>
        <p class="team-titel">${esc(person.titel)}</p>
        <p class="team-bio">${esc(person.bio)}</p>
        <div class="team-btns">
          <a href="${esc(bookHref)}" target="_blank" rel="noopener" class="team-btn team-btn-book">📅 Book</a>
          ${tlfHref?`<a href="${esc(tlfHref)}" class="team-btn team-btn-tlf">📞 Ring</a>`:''}
        </div>
      </div>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   TILBUDSLISTE
══════════════════════════════════════ */
function buildTilbudsliste() {
  setText('tilbud-intro', D.tilbudIntro || '');

  const grid  = document.getElementById('tilbudskort-grid');
  const empty = document.getElementById('tilbud-empty');
  if (!grid) return;

  const now = new Date();
  const aktive = (D.tilbudsliste||[]).filter(t => {
    if (!t.synlig) return false;
    if (t.startDato && new Date(t.startDato) > now) return false;
    if (t.slutDato  && new Date(t.slutDato)  < now) return false;
    return true;
  }).sort((a,b) => (a.sortering||0)-(b.sortering||0));

  if (!aktive.length) {
    grid.innerHTML = '';
    empty?.classList.remove('hidden');
    return;
  }
  empty?.classList.add('hidden');

  grid.innerHTML = aktive.map(t => {
    const datoTekst = t.slutDato ? `Gælder til ${new Date(t.slutDato).toLocaleDateString('da-DK')}` : '';
    return `
    <div class="tilbudskort fade-in">
      <span class="tilbudskort-badge">Tilbud</span>
      ${t.billede
        ? `<div class="tilbudskort-img">
             <img src="${esc(t.billede)}" alt="${esc(t.titel)}" loading="lazy"
               onerror="this.parentElement.outerHTML='<div class=\\'tilbudskort-img-placeholder\\'>🏷️</div>'">
           </div>`
        : '<div class="tilbudskort-img-placeholder">🏷️</div>'}
      <div class="tilbudskort-body">
        <h3 class="tilbudskort-titel">${esc(t.titel)}</h3>
        <p class="tilbudskort-tekst">${esc(t.tekst)}</p>
        ${datoTekst ? `<p class="tilbudskort-dato">🗓 ${esc(datoTekst)}</p>` : ''}
      </div>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   GALLERI + LIGHTBOX
══════════════════════════════════════ */
function buildGalleri() {
  const grid = document.getElementById('galleri-grid');
  if (!grid) return;
  const list = (D.galleri||[]).sort((a,b)=>(a.sortering||0)-(b.sortering||0));
  grid.innerHTML = list.map((img, i) => `
    <div class="galleri-item fade-in" data-idx="${i}" role="button" tabindex="0"
         aria-label="${esc(img.titel||'Galleri billede')}">
      ${img.url
        ? `<img src="${esc(img.url)}" alt="${esc(img.titel||'')}" loading="lazy"
             onerror="this.parentElement.innerHTML='<div class=\\'galleri-placeholder\\'>🖼️</div>'">`
        : '<div class="galleri-placeholder">🖼️</div>'}
    </div>`).join('');
  grid.querySelectorAll('.galleri-item').forEach(item => {
    item.addEventListener('click', () => openLightbox(+item.dataset.idx));
    item.addEventListener('keydown', e => { if(e.key==='Enter') openLightbox(+item.dataset.idx); });
  });
}
function initLightbox() {
  const lb = document.getElementById('lightbox'); if (!lb) return;
  document.getElementById('lb-close')?.addEventListener('click', closeLightbox);
  lb.addEventListener('click', e => { if(e.target===lb) closeLightbox(); });
  document.getElementById('lb-prev')?.addEventListener('click', () => moveLightbox(-1));
  document.getElementById('lb-next')?.addEventListener('click', () => moveLightbox(1));
  document.addEventListener('keydown', e => {
    if (lb.classList.contains('hidden')) return;
    if (e.key==='Escape') closeLightbox();
    if (e.key==='ArrowLeft') moveLightbox(-1);
    if (e.key==='ArrowRight') moveLightbox(1);
  });
  lb.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) moveLightbox(diff > 0 ? 1 : -1);
  }, { passive: true });
}
function openLightbox(idx) {
  const list=(D.galleri||[]).sort((a,b)=>(a.sortering||0)-(b.sortering||0));
  galleriIdx=idx;
  document.getElementById('lightbox')?.classList.remove('hidden');
  document.body.style.overflow='hidden';
  renderLightbox(list);
}
function closeLightbox() { document.getElementById('lightbox')?.classList.add('hidden'); document.body.style.overflow=''; }
function moveLightbox(dir) {
  const list=(D.galleri||[]).sort((a,b)=>(a.sortering||0)-(b.sortering||0));
  galleriIdx=(galleriIdx+dir+list.length)%list.length; renderLightbox(list);
}
function renderLightbox(list) {
  const item=list[galleriIdx]; if(!item)return;
  const img=document.getElementById('lb-img');
  if(img){img.src=item.url||'';img.alt=item.titel||'';}
  setText('lb-caption',item.titel||'');
  const dots=document.getElementById('lb-dots');
  if(dots){
    dots.innerHTML=list.map((_,i)=>
      `<button class="lb-dot${i===galleriIdx?' active':''}" aria-label="Billede ${i+1}"></button>`
    ).join('');
    dots.querySelectorAll('.lb-dot').forEach((d,i)=>d.addEventListener('click',()=>{galleriIdx=i;renderLightbox(list);}));
  }
}

/* ══════════════════════════════════════
   ÅBNINGSTIDER
══════════════════════════════════════ */
function buildHours() {
  const grid=document.getElementById('hours-grid');
  const noteEl=document.getElementById('hours-note');
  if(!grid||!D.aabningstider)return;
  const now=new Date();
  const dayIdx=(now.getDay()+6)%7;
  const nowMins=now.getHours()*60+now.getMinutes();
  const todayISO=now.toISOString().slice(0,10);
  const helligdag=(D.helligdage||[]).find(h=>h.dato===todayISO);
  grid.innerHTML=D.aabningstider.map((h,i)=>{
    const isToday=i===dayIdx;
    const openMins=toMins(h.aaben);
    const closeMins=toMins(h.luk);
    const openNow=isToday&&!h.lukket&&!helligdag&&nowMins>=openMins&&nowMins<closeMins;
    let cls='hours-card';
    if(h.lukket||(isToday&&helligdag)) cls+=' closed';
    if(openNow) cls+=' open-now';
    return `<div class="${cls}">
      <p class="hours-dag">${esc(h.dag.slice(0,3))}</p>
      <p class="hours-time">${h.lukket?'Lukket':h.aaben+'–'+h.luk}</p>
      ${openNow?'<span class="hours-badge">Åben nu</span>':''}
    </div>`;
  }).join('');
  if(noteEl){
    const note=helligdag?.navn||D.meta?.ferieTekst;
    if(note){noteEl.textContent='🗓 '+note;noteEl.classList.remove('hidden');}
  }
}
function toMins(t){if(!t)return 0;const[h,m]=t.split(':').map(Number);return h*60+(m||0);}

/* ══════════════════════════════════════
   KONTAKT
══════════════════════════════════════ */
function buildKontakt() {
  const k=D.kontakt;
  const info=document.getElementById('kontakt-info');
  if(!info)return;
  info.innerHTML=`
    <div class="kontakt-item">
      <span class="kontakt-ico">📍</span>
      <div>
        <p class="kontakt-lbl">Adresse</p>
        <a href="${esc(k.mapsUrl||'#')}" target="_blank" rel="noopener" class="kontakt-link kontakt-val">${esc(k.adresse)}<br>${esc(k.by)}</a>
      </div>
    </div>
    <div class="kontakt-item">
      <span class="kontakt-ico">📞</span>
      <div>
        <p class="kontakt-lbl">Telefon</p>
        <a href="tel:+45${clean(k.tlf)}" class="kontakt-link kontakt-val">${formatTlf(k.tlf)}</a>
      </div>
    </div>
    <div class="kontakt-item">
      <span class="kontakt-ico">💬</span>
      <div>
        <p class="kontakt-lbl">SMS</p>
        <a href="sms:+45${clean(k.sms||k.tlf)}" class="kontakt-link kontakt-val">${formatTlf(k.sms||k.tlf)}</a>
      </div>
    </div>
    <div class="kontakt-item">
      <span class="kontakt-ico">📅</span>
      <div>
        <p class="kontakt-lbl">Book tid</p>
        <a href="${esc(k.bookingUrl)}" target="_blank" rel="noopener" class="kontakt-link kontakt-val">Book online →</a>
      </div>
    </div>
    ${k.mail?`<div class="kontakt-item">
      <span class="kontakt-ico">✉️</span>
      <div><p class="kontakt-lbl">E-mail</p>
      <a href="mailto:${esc(k.mail)}" class="kontakt-link kontakt-val">${esc(k.mail)}</a></div>
    </div>`:''}
    <div class="social-row">
      ${k.instagram?`<a href="${esc(k.instagram)}" target="_blank" rel="noopener" class="social-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="5"/>
          <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
        </svg> Instagram</a>`:''}
      ${k.facebook?`<a href="${esc(k.facebook)}" target="_blank" rel="noopener" class="social-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
        </svg> Facebook</a>`:''}
    </div>`;
  const ml=document.getElementById('maps-link');
  if(ml&&k.mapsUrl) ml.href=k.mapsUrl;
}

/* ══════════════════════════════════════
   LINKS
══════════════════════════════════════ */
function applyLinks() {
  const k=D.kontakt;
  const tlf=`tel:+45${clean(k.tlf)}`;
  const sms=`sms:+45${clean(k.sms||k.tlf)}`;
  setHref('mb-book',      k.bookingUrl,true);
  setHref('mb-ring',      tlf);
  setHref('mb-sms',       sms);
  setHref('mb-kort',      k.mapsUrl,true);
  setHref('nav-book-btn', k.bookingUrl,true);
  setHref('mm-book',      k.bookingUrl,true);
  setHref('mm-tlf',       tlf);
  setHref('mm-sms',       sms);
  setHref('footer-fb',    k.facebook,true);
  setHref('footer-ig',    k.instagram,true);
  setHref('maps-link',    k.mapsUrl,true);
}

/* ══════════════════════════════════════
   TILBUD BANNER
══════════════════════════════════════ */
function applyTilbudBanner() {
  const t=D.tilbud;
  if(!t?.aktiv||!t.tekst)return;
  const now=new Date();
  if(t.slutDato&&new Date(t.slutDato)<now)return;
  if(t.startDato&&new Date(t.startDato)>now)return;
  const banner=document.getElementById('tilbud-banner');
  if(!banner)return;
  setText('tilbud-tekst',t.tekst);
  if(t.farve) banner.style.background=t.farve;
  banner.classList.remove('hidden');
  document.getElementById('tilbud-luk')?.addEventListener('click',()=>banner.classList.add('hidden'));
}

/* ══════════════════════════════════════
   PARALLAX
══════════════════════════════════════ */
function initParallax() {
  const bg=document.getElementById('hero-bg');
  if(!bg||window.matchMedia('(prefers-reduced-motion:reduce)').matches)return;
  let ticking=false;
  window.addEventListener('scroll',()=>{
    if(!ticking){
      requestAnimationFrame(()=>{
        if(window.scrollY<window.innerHeight*1.5)
          bg.style.transform=`translateY(${window.scrollY*.28}px)`;
        ticking=false;
      });
      ticking=true;
    }
  },{passive:true});
}

/* ══════════════════════════════════════
   FADE-IN
══════════════════════════════════════ */
function initFadeIn() {
  const els=document.querySelectorAll('.fade-in:not(.visible)');
  if(!els.length)return;
  const obs=new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');obs.unobserve(e.target);}});
  },{threshold:.1});
  els.forEach(el=>obs.observe(el));
}

/* ══════════════════════════════════════
   MOBILE BAR HIGHLIGHT
══════════════════════════════════════ */
function initMobileBarHighlight() {
  const ids=['hjem','om-os','behandlinger','priser','produkter','team','tilbud','galleri','kontakt'];
  const items=document.querySelectorAll('.mb-item[data-sec]');
  const obs=new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting)
        items.forEach(item=>item.classList.toggle('active',item.dataset.sec===e.target.id));
    });
  },{threshold:.4});
  ids.forEach(id=>{const el=document.getElementById(id);if(el)obs.observe(el);});
}

/* ══════════════════════════════════════
   PWA
══════════════════════════════════════ */
function initPWA() {
  if('serviceWorker' in navigator){
    window.addEventListener('load',()=>{
      navigator.serviceWorker.register('service-worker.js?v=1.2.0')
        .catch(e=>console.warn('[SW]',e));
    });
  }
  window.addEventListener('beforeinstallprompt',e=>{
    e.preventDefault(); deferredInstall=e; setTimeout(showInstallPrompt,3000);
  });
  window.addEventListener('appinstalled',()=>{
    document.getElementById('install-prompt')?.classList.add('hidden'); deferredInstall=null;
  });
}
function showInstallPrompt() {
  const p=document.getElementById('install-prompt');
  if(!p||sessionStorage.getItem('install-dismissed'))return;
  p.classList.remove('hidden');
  document.getElementById('ip-install')?.addEventListener('click',async()=>{
    if(deferredInstall){deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;}
    p.classList.add('hidden');
  });
  document.getElementById('ip-dismiss')?.addEventListener('click',()=>{
    p.classList.add('hidden'); sessionStorage.setItem('install-dismissed','1');
  });
  setTimeout(()=>p?.classList.add('hidden'),10000);
}

/* ══════════════════════════════════════
   ONLINE/OFFLINE
══════════════════════════════════════ */
function checkOnline() {
  const b=document.getElementById('offline-banner'); if(!b)return;
  const show=()=>{b.classList.remove('hidden');b.classList.add('visible');};
  const hide=()=>{b.classList.add('hidden');b.classList.remove('visible');};
  if(!navigator.onLine)show();
  window.addEventListener('online',hide);
  window.addEventListener('offline',show);
}

/* ══════════════════════════════════════
   HELPERS
══════════════════════════════════════ */
function setText(id,val){const el=document.getElementById(id);if(el)el.textContent=val??'';}
function setHref(id,href,newTab){
  const el=document.getElementById(id);
  if(!el||!href)return;
  el.href=href;
  if(newTab){el.target='_blank';el.rel='noopener';}
}
function clean(s){return(s||'').replace(/\D/g,'');}
function formatTlf(s){const c=clean(s);return c.replace(/(\d{2})(?=\d)/g,'$1 ').trim();}
function esc(s){
  if(s===null||s===undefined)return'';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
