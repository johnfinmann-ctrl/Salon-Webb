/* ================================================================
   SALON WEBB ADMIN – admin.js v1.2.0
   Nordic Operations · nordicoperations.dk
   ================================================================ */
'use strict';

let D = {};
let currentPanel = 'dashboard';
let currentUser  = null;
const SESSION_KEY = 'sw_admin_session';
const DATA_KEY    = 'sw_data';
const BACKUP_KEY  = 'sw_last_backup';
let toastTimer    = null;

document.addEventListener('DOMContentLoaded', () => {
  loadData();
  checkSession();
  initSidebar();
  initTopbar();
  initGlobalSave();
});

/* ── DATA ── */
function loadData() {
  try {
    const s = localStorage.getItem(DATA_KEY);
    D = s ? JSON.parse(s) : deepCopy(SW_DEFAULT_DATA);
    mergeDefaults(D, SW_DEFAULT_DATA);
  } catch { D = deepCopy(SW_DEFAULT_DATA); }
}
function saveData() {
  localStorage.setItem(DATA_KEY, JSON.stringify(D));
  localStorage.setItem(BACKUP_KEY, new Date().toISOString());
  showToast('✓ Gemt');
}
function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }
function mergeDefaults(t, s) {
  for (const k of Object.keys(s)) {
    if (!(k in t)) t[k] = deepCopy(s[k]);
    else if (typeof s[k]==='object'&&!Array.isArray(s[k])&&s[k]!==null&&typeof t[k]==='object'&&!Array.isArray(t[k]))
      mergeDefaults(t[k], s[k]);
  }
}

/* ── SESSION ── */
function checkSession() {
  const s = sessionStorage.getItem(SESSION_KEY);
  if (s) { try { currentUser=JSON.parse(s); showApp(); return; } catch {} }
  showLogin();
}
function showLogin() {
  document.getElementById('login-screen').classList.remove('hidden');
  document.getElementById('admin-app').classList.add('hidden');
  document.getElementById('login-form')?.addEventListener('submit', handleLogin);
}
function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email')?.value.trim();
  const pwd   = document.getElementById('login-pwd')?.value;
  const errEl = document.getElementById('login-error');
  const attempts = +(sessionStorage.getItem('login_attempts')||0);
  if (attempts >= 5) { errEl.textContent='For mange forsøg.'; errEl.classList.remove('hidden'); return; }
  const user = (D.adminBrugere||SW_DEFAULT_DATA.adminBrugere).find(u=>u.email===email&&u.password===pwd);
  if (!user) {
    sessionStorage.setItem('login_attempts', attempts+1);
    errEl.textContent='Forkert e-mail eller adgangskode.';
    errEl.classList.remove('hidden'); return;
  }
  sessionStorage.removeItem('login_attempts');
  currentUser={id:user.id,navn:user.navn,email:user.email,rolle:user.rolle};
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  setTimeout(logout, 4*60*60*1000);
  showApp();
}
function showApp() {
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('admin-app').classList.remove('hidden');
  setText('sidebar-user', currentUser?.navn||currentUser?.email);
  document.getElementById('logout-btn')?.addEventListener('click', logout);
  navigateTo('dashboard');
}
function logout() { sessionStorage.removeItem(SESSION_KEY); location.reload(); }

/* ── NAV ── */
function initSidebar() {
  document.querySelectorAll('.snav').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(link.dataset.panel);
      document.getElementById('admin-sidebar')?.classList.remove('open');
    });
  });
  document.getElementById('sidebar-close')?.addEventListener('click', () =>
    document.getElementById('admin-sidebar')?.classList.remove('open'));
}
function initTopbar() {
  document.getElementById('topbar-hamburger')?.addEventListener('click', () =>
    document.getElementById('admin-sidebar')?.classList.toggle('open'));
}
function navigateTo(id) {
  currentPanel = id;
  document.querySelectorAll('.snav').forEach(l => l.classList.toggle('active', l.dataset.panel===id));
  document.querySelectorAll('.panel').forEach(p => {
    const m = p.id===`panel-${id}`;
    p.classList.toggle('active', m);
    p.classList.toggle('hidden', !m);
  });
  const titles = {
    dashboard:'Dashboard',forside:'Forside',indholdskort:'Om os – Indholdskort',
    behandlinger:'Behandlinger',priser:'Priser',produktbrands:'Produkter',
    team:'Team',tilbudsliste:'Tilbud',galleri:'Galleri',aabningstider:'Åbningstider',
    kontakt:'Kontakt',seo:'SEO',qr:'QR-koder',backup:'Backup',test:'Testcenter',indstillinger:'Indstillinger'
  };
  setText('topbar-title', titles[id]||id);
  renderPanel(id);
}
function renderPanel(id) {
  const m = {
    dashboard:renderDashboard, forside:renderForside,
    indholdskort:renderIndholdskort, behandlinger:renderBehandlinger,
    priser:renderPriser, produktbrands:renderProduktbrands,
    team:renderTeam, tilbudsliste:renderTilbudsliste,
    galleri:renderGalleri, aabningstider:renderAabningstider,
    kontakt:renderKontakt, seo:renderSEO, qr:renderQR,
    backup:renderBackup, test:renderTest, indstillinger:renderIndstillinger
  };
  m[id]?.();
}
function initGlobalSave() {
  document.getElementById('global-save')?.addEventListener('click', () => {
    collectCurrentPanel(); saveData();
  });
}
function collectCurrentPanel() {
  const m = {
    forside:collectForside, kontakt:collectKontakt,
    tilbudsliste:collectTilbudsliste, seo:collectSEO,
    aabningstider:collectAabningstider, indstillinger:()=>{}
  };
  m[currentPanel]?.();
}

/* ══════════════════════════════════════
   DASHBOARD
══════════════════════════════════════ */
function renderDashboard() {
  const s = document.getElementById('dash-stats');
  if (s) s.innerHTML=`
    <div class="stat-card"><div class="stat-num">${(D.team||[]).filter(t=>t.synlig!==false).length}</div><div class="stat-lbl">Teammedlemmer</div></div>
    <div class="stat-card"><div class="stat-num">${(D.priser?.liste||[]).filter(p=>p.synlig!==false).length}</div><div class="stat-lbl">Priser</div></div>
    <div class="stat-card"><div class="stat-num">${(D.produktbrands||[]).filter(p=>p.synlig!==false).length}</div><div class="stat-lbl">Produktbrands</div></div>
    <div class="stat-card"><div class="stat-num">${(D.tilbudsliste||[]).filter(t=>t.synlig!==false).length}</div><div class="stat-lbl">Tilbud</div></div>`;
  const v=document.getElementById('dash-version');
  if(v)v.innerHTML=`
    <div class="status-item"><span class="status-dot status-ok"></span>v${esc(D.meta?.version)}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>${esc(D.meta?.buildDate)}</div>`;
  const lastB=localStorage.getItem(BACKUP_KEY);
  const b=document.getElementById('dash-backup');
  if(b)b.innerHTML=lastB?`<div class="status-item"><span class="status-dot status-ok"></span>${new Date(lastB).toLocaleString('da-DK')}</div>`
    :`<div class="status-item"><span class="status-dot status-warn"></span>Ingen backup endnu</div>`;
  const l=document.getElementById('dash-quick-links');
  if(l)l.innerHTML=`
    <a href="index.html" target="_blank" class="quick-link">👁 Se sitet</a>
    <a href="${esc(D.kontakt?.bookingUrl||'#')}" target="_blank" class="quick-link">📅 Test booking</a>
    <a href="${esc(D.kontakt?.instagram||'#')}" target="_blank" class="quick-link">📸 Instagram</a>`;
  const st=document.getElementById('dash-status');
  const k=D.kontakt;
  if(st)st.innerHTML=`
    <div class="status-item"><span class="status-dot ${k?.tlf?'status-ok':'status-err'}"></span>Telefon: ${k?.tlf?'76 13 14 13':'mangler'}</div>
    <div class="status-item"><span class="status-dot ${k?.bookingUrl?'status-ok':'status-warn'}"></span>Booking: ${k?.bookingUrl?'OK':'mangler'}</div>
    <div class="status-item"><span class="status-dot ${k?.mapsUrl?'status-ok':'status-warn'}"></span>Maps: ${k?.mapsUrl?'OK':'mangler'}</div>`;
}

/* ══════════════════════════════════════
   FORSIDE
══════════════════════════════════════ */
function renderForside() {
  setVal('f-salon-navn',     D.meta?.salonNavn);
  setVal('f-tagline',        D.meta?.tagline);
  setVal('f-hero-overskrift',D.hero?.overskrift);
  setVal('f-hero-undertitel',D.hero?.undertitel);
  setVal('f-hero-eyebrow',   D.hero?.eyebrow);
  setVal('f-hero-baggrund',  D.hero?.baggrund);
  const kl=document.getElementById('hero-knapper-list');
  if(kl) kl.innerHTML=(D.hero?.knapper||[]).map((k,i)=>`
    <div class="knap-row">
      <input type="text" value="${esc(k.ikon)}" data-ki="${i}" data-field="ikon" style="width:60px" placeholder="Ikon">
      <input type="text" value="${esc(k.label)}" data-ki="${i}" data-field="label" placeholder="Label">
      <select data-ki="${i}" data-field="type">
        ${['booking','tlf','sms','maps'].map(t=>`<option ${k.type===t?'selected':''}>${t}</option>`).join('')}
      </select>
    </div>`).join('');
}
function collectForside() {
  D.meta=D.meta||{};
  D.meta.salonNavn=sanitize(getVal('f-salon-navn'));
  D.meta.tagline  =sanitize(getVal('f-tagline'));
  D.hero=D.hero||{};
  D.hero.overskrift=sanitize(getVal('f-hero-overskrift'));
  D.hero.undertitel=sanitize(getVal('f-hero-undertitel'));
  D.hero.eyebrow   =sanitize(getVal('f-hero-eyebrow'));
  D.hero.baggrund  =getVal('f-hero-baggrund');
  document.querySelectorAll('.knap-row [data-ki]').forEach(el=>{
    const i=+el.dataset.ki; const f=el.dataset.field;
    if(D.hero.knapper[i]) D.hero.knapper[i][f]=el.tagName==='SELECT'?el.value:sanitize(el.value);
  });
}

/* ══════════════════════════════════════
   INDHOLDSKORT
══════════════════════════════════════ */
function renderIndholdskort() {
  const list=document.getElementById('indholdskort-list');
  if(!list)return;
  list.innerHTML='';
  (D.indholdskort||[]).forEach((k,i)=>{
    list.appendChild(makeItemCard({
      title:k.titel, badge:k.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Ikon',key:'ikon',val:k.ikon,type:'text',hint:'Emoji'},
        {label:'Titel',key:'titel',val:k.titel,type:'text'},
        {label:'Brødtekst',key:'tekst',val:k.tekst,type:'textarea'},
        {label:'Billede URL (HTTPS)',key:'billede',val:k.billede,type:'url'},
        {label:'Sortering',key:'sortering',val:k.sortering,type:'number'},
        {label:'Synlig',key:'synlig',val:k.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{Object.assign(D.indholdskort[i],v);saveData();renderIndholdskort();},
      onDelete:()=>{D.indholdskort.splice(i,1);saveData();renderIndholdskort();}
    }));
  });
  rebind('add-ikort',()=>{
    D.indholdskort.push({id:'ik'+Date.now(),titel:'Nyt kort',ikon:'✂️',tekst:'',billede:'',synlig:true,sortering:99});
    saveData();renderIndholdskort();
  });
}

/* ══════════════════════════════════════
   BEHANDLINGER
══════════════════════════════════════ */
function renderBehandlinger() {
  const list=document.getElementById('behandlinger-list');
  if(!list)return;
  list.innerHTML='';
  (D.behandlinger||[]).forEach((b,i)=>{
    list.appendChild(makeItemCard({
      title:b.navn, badge:b.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Ikon',key:'ikon',val:b.ikon,type:'text',hint:'Emoji'},
        {label:'Navn',key:'navn',val:b.navn,type:'text'},
        {label:'Beskrivelse',key:'beskrivelse',val:b.beskrivelse,type:'textarea'},
        {label:'Synlig',key:'synlig',val:b.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{Object.assign(D.behandlinger[i],v);saveData();renderBehandlinger();},
      onDelete:()=>{D.behandlinger.splice(i,1);saveData();renderBehandlinger();}
    }));
  });
  rebind('add-behandling',()=>{
    D.behandlinger.push({id:'beh'+Date.now(),navn:'Ny behandling',beskrivelse:'',ikon:'✂️',synlig:true});
    saveData();renderBehandlinger();
  });
}

/* ══════════════════════════════════════
   PRISER
══════════════════════════════════════ */
function renderPriser() {
  const kl=document.getElementById('price-kats-list');
  if(kl){
    kl.innerHTML=(D.priser.kategorier||[]).map((k,i)=>
      `<span class="kat-tag">${esc(k)} <button class="kat-del-btn" data-ki="${i}">✕</button></span>`
    ).join('');
    kl.querySelectorAll('.kat-del-btn').forEach(b=>b.addEventListener('click',()=>{
      D.priser.kategorier.splice(+b.dataset.ki,1);saveData();renderPriser();
    }));
  }
  rebind('add-price-kat',()=>{
    const n=prompt('Ny kategori:'); if(n){D.priser.kategorier.push(sanitize(n.trim()));saveData();renderPriser();}
  });
  const list=document.getElementById('priser-list');
  if(!list)return;
  list.innerHTML='';
  (D.priser.liste||[]).forEach((p,i)=>{
    list.appendChild(makeItemCard({
      title:`${p.kategori} – ${p.navn}`, badge:p.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Kategori',key:'kategori',val:p.kategori,type:'select',options:D.priser.kategorier},
        {label:'Navn',key:'navn',val:p.navn,type:'text'},
        {label:'Beskrivelse',key:'beskrivelse',val:p.beskrivelse,type:'text'},
        {label:'Pris',key:'pris',val:p.pris,type:'text',hint:'Fx 395'},
        {label:'Enhed',key:'enhed',val:p.enhed,type:'text',hint:'kr. eller efter aftale'},
        {label:'Synlig',key:'synlig',val:p.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{Object.assign(D.priser.liste[i],v);saveData();renderPriser();},
      onDelete:()=>{D.priser.liste.splice(i,1);saveData();renderPriser();}
    }));
  });
  rebind('add-price',()=>{
    D.priser.liste.push({id:'p'+Date.now(),kategori:D.priser.kategorier[0]||'Damer',navn:'Ny ydelse',beskrivelse:'',pris:'',enhed:'kr.',synlig:true,sortering:99});
    saveData();renderPriser();
  });
}

/* ══════════════════════════════════════
   PRODUKTBRANDS
══════════════════════════════════════ */
function renderProduktbrands() {
  const list=document.getElementById('produktbrands-list');
  if(!list)return;
  list.innerHTML='';
  (D.produktbrands||[]).forEach((p,i)=>{
    // Build billeder as textarea (one URL per line)
    const billedeTekst=(p.billeder||[]).join('\n');
    list.appendChild(makeItemCard({
      title:p.brand, badge:p.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Brand-navn',key:'brand',val:p.brand,type:'text'},
        {label:'Beskrivelse',key:'tekst',val:p.tekst,type:'textarea'},
        {label:'Produktbilleder (én URL per linje, HTTPS)',key:'_billeder',val:billedeTekst,type:'textarea',hint:'Op til 4 billeder'},
        {label:'Sortering',key:'sortering',val:p.sortering,type:'number'},
        {label:'Synlig',key:'synlig',val:p.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{
        const billederRaw=v._billeder||'';
        delete v._billeder;
        v.billeder=billederRaw.split('\n').map(s=>s.trim()).filter(s=>s.startsWith('https://'));
        Object.assign(D.produktbrands[i],v);
        saveData();renderProduktbrands();
      },
      onDelete:()=>{D.produktbrands.splice(i,1);saveData();renderProduktbrands();}
    }));
  });
  rebind('add-pbrand',()=>{
    D.produktbrands.push({id:'pb'+Date.now(),brand:'Nyt brand',tekst:'',billeder:[],synlig:true,sortering:99});
    saveData();renderProduktbrands();
  });
}

/* ══════════════════════════════════════
   TEAM
══════════════════════════════════════ */
function renderTeam() {
  const list=document.getElementById('team-list');
  if(!list)return;
  list.innerHTML='';
  (D.team||[]).forEach((t,i)=>{
    list.appendChild(makeItemCard({
      title:`${t.navn} – ${t.titel}`, badge:t.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Navn',key:'navn',val:t.navn,type:'text'},
        {label:'Titel (fx Indehaver / 4. års elev)',key:'titel',val:t.titel,type:'text'},
        {label:'Bio',key:'bio',val:t.bio,type:'textarea'},
        {label:'Foto URL (HTTPS) – placeholder vises automatisk',key:'foto',val:t.foto,type:'url'},
        {label:'Booking-link (tomt = salonens)',key:'bookingLink',val:t.bookingLink,type:'url'},
        {label:'Direkte telefon (valgfri)',key:'tlf',val:t.tlf,type:'tel'},
        {label:'Sortering',key:'sortering',val:t.sortering,type:'number'},
        {label:'Synlig / Aktiv',key:'synlig',val:t.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{Object.assign(D.team[i],v);saveData();renderTeam();},
      onDelete:()=>{D.team.splice(i,1);saveData();renderTeam();}
    }));
  });
  rebind('add-team',()=>{
    D.team.push({id:'t'+Date.now(),navn:'Ny medarbejder',titel:'Frisør',bio:'',foto:'',bookingLink:'',tlf:'',synlig:true,sortering:99});
    saveData();renderTeam();
  });
}

/* ══════════════════════════════════════
   TILBUDSLISTE
══════════════════════════════════════ */
function renderTilbudsliste() {
  setVal('tilbud-intro-tekst', D.tilbudIntro||'');
  setChecked('tilbud-banner-aktiv', D.tilbud?.aktiv);
  setVal('tilbud-banner-tekst',  D.tilbud?.tekst);
  setVal('tilbud-banner-start',  D.tilbud?.startDato);
  setVal('tilbud-banner-slut',   D.tilbud?.slutDato);
  setVal('tilbud-banner-farve',  D.tilbud?.farve||'#C9A96E');

  const list=document.getElementById('tilbudsliste-list');
  if(!list)return;
  list.innerHTML='';
  (D.tilbudsliste||[]).forEach((t,i)=>{
    list.appendChild(makeItemCard({
      title:t.titel, badge:t.synlig!==false?'Synlig':'Skjult',
      fields:[
        {label:'Titel',key:'titel',val:t.titel,type:'text'},
        {label:'Beskrivelse',key:'tekst',val:t.tekst,type:'textarea'},
        {label:'Billede URL (HTTPS)',key:'billede',val:t.billede,type:'url'},
        {label:'Startdato (valgfri)',key:'startDato',val:t.startDato,type:'date'},
        {label:'Slutdato (valgfri)',key:'slutDato',val:t.slutDato,type:'date'},
        {label:'Sortering',key:'sortering',val:t.sortering,type:'number'},
        {label:'Synlig',key:'synlig',val:t.synlig!==false,type:'checkbox'}
      ],
      onSave:v=>{Object.assign(D.tilbudsliste[i],v);saveData();renderTilbudsliste();},
      onDelete:()=>{D.tilbudsliste.splice(i,1);saveData();renderTilbudsliste();}
    }));
  });
  rebind('add-tilbud',()=>{
    D.tilbudsliste.push({id:'tb'+Date.now(),titel:'Nyt tilbud',tekst:'',billede:'',startDato:'',slutDato:'',synlig:true,sortering:99});
    saveData();renderTilbudsliste();
  });
}
function collectTilbudsliste() {
  D.tilbudIntro=sanitize(getVal('tilbud-intro-tekst'));
  D.tilbud=D.tilbud||{};
  D.tilbud.aktiv    =document.getElementById('tilbud-banner-aktiv')?.checked||false;
  D.tilbud.tekst    =sanitize(getVal('tilbud-banner-tekst'));
  D.tilbud.startDato=getVal('tilbud-banner-start');
  D.tilbud.slutDato =getVal('tilbud-banner-slut');
  D.tilbud.farve    =getVal('tilbud-banner-farve');
}

/* ══════════════════════════════════════
   GALLERI
══════════════════════════════════════ */
function renderGalleri() {
  const grid=document.getElementById('galleri-list');
  if(!grid)return;
  grid.innerHTML=(D.galleri||[]).map((img,i)=>`
    <div class="galleri-admin-item">
      <img class="galleri-admin-img" src="${esc(img.url)}" alt="${esc(img.titel)}" loading="lazy"
        onerror="this.style.background='#e0e0e0';this.removeAttribute('src')">
      <div class="galleri-admin-overlay">
        <button class="galleri-admin-del" data-i="${i}">Slet</button>
      </div>
      <p class="galleri-admin-caption">${esc(img.titel||'')}</p>
    </div>`).join('');
  grid.querySelectorAll('.galleri-admin-del').forEach(btn=>btn.addEventListener('click',()=>{
    if(confirm('Slet?')){D.galleri.splice(+btn.dataset.i,1);saveData();renderGalleri();}
  }));
  rebind('add-galleri-url',()=>{
    const url=(document.getElementById('galleri-url-input')?.value||'').trim();
    const titel=(document.getElementById('galleri-titel-input')?.value||'').trim();
    if(!url)return;
    if(!url.startsWith('https://')){alert('Brug kun HTTPS-links');return;}
    D.galleri.push({id:'g'+Date.now(),url,titel:sanitize(titel),sortering:D.galleri.length+1});
    saveData();renderGalleri();
    const ui=document.getElementById('galleri-url-input');if(ui)ui.value='';
    const ti=document.getElementById('galleri-titel-input');if(ti)ti.value='';
  });
}

/* ══════════════════════════════════════
   ÅBNINGSTIDER
══════════════════════════════════════ */
function renderAabningstider() {
  const list=document.getElementById('hours-admin-list');
  if(list&&D.aabningstider) {
    list.innerHTML=D.aabningstider.map((h,i)=>`
      <div class="hours-admin-row${h.lukket?' lukket':''}">
        <span class="hours-admin-dag">${esc(h.dag)}</span>
        <input type="time" class="ah-aaben" data-i="${i}" value="${h.aaben}" ${h.lukket?'disabled':''}>
        <span style="font-size:.8rem;color:#999">–</span>
        <input type="time" class="ah-luk" data-i="${i}" value="${h.luk}" ${h.lukket?'disabled':''}>
        <label style="display:flex;align-items:center;gap:5px;font-size:.8rem;cursor:pointer;white-space:nowrap">
          <input type="checkbox" class="ah-lukket" data-i="${i}" ${h.lukket?'checked':''}> Lukket
        </label>
      </div>`).join('');
    list.querySelectorAll('.ah-lukket').forEach(cb=>cb.addEventListener('change',e=>{
      D.aabningstider[+e.target.dataset.i].lukket=e.target.checked;renderAabningstider();
    }));
  }
  setVal('ferie-tekst', D.meta?.ferieTekst||'');
  // Helligdage
  const hl=document.getElementById('helligdage-list');
  if(hl){
    hl.innerHTML=(D.helligdage||[]).map((h,i)=>`
      <div class="helligdag-row">
        <span class="helligdag-dato">${esc(h.dato)}</span>
        <span class="helligdag-navn">${esc(h.navn)}</span>
        <button class="helligdag-del" data-i="${i}">✕</button>
      </div>`).join('')||'<p style="color:#999;font-size:.8rem">Ingen helligdage tilføjet</p>';
    hl.querySelectorAll('.helligdag-del').forEach(btn=>btn.addEventListener('click',()=>{
      D.helligdage.splice(+btn.dataset.i,1);saveData();renderAabningstider();
    }));
  }
  rebind('add-helligdag',()=>{
    const dato=prompt('Dato (YYYY-MM-DD):');
    if(!dato||!/^\d{4}-\d{2}-\d{2}$/.test(dato)){alert('Ugyldig dato. Brug YYYY-MM-DD');return;}
    const navn=prompt('Beskrivelse:'); if(!navn)return;
    D.helligdage=D.helligdage||[];
    D.helligdage.push({dato,navn:sanitize(navn)});
    D.helligdage.sort((a,b)=>a.dato.localeCompare(b.dato));
    saveData();renderAabningstider();
  });
}
function collectAabningstider() {
  document.querySelectorAll('.ah-aaben').forEach(el=>{ D.aabningstider[+el.dataset.i].aaben=el.value; });
  document.querySelectorAll('.ah-luk').forEach(el=>{ D.aabningstider[+el.dataset.i].luk=el.value; });
  D.meta=D.meta||{};
  D.meta.ferieTekst=sanitize(getVal('ferie-tekst'));
}

/* ══════════════════════════════════════
   KONTAKT
══════════════════════════════════════ */
function renderKontakt() {
  const k=D.kontakt;
  setVal('k-tlf',      k.tlf);      setVal('k-sms',       k.sms);
  setVal('k-mail',     k.mail);     setVal('k-adresse',    k.adresse);
  setVal('k-by',       k.by);       setVal('k-maps',       k.mapsUrl);
  setVal('k-booking',  k.bookingUrl);setVal('k-instagram', k.instagram);
  setVal('k-facebook', k.facebook); setVal('k-siteurl',    D.meta?.siteUrl||'');
  setTestLink('test-tlf',`tel:+45${(k.tlf||'').replace(/\D/g,'')}`);
  setTestLink('test-mail',`mailto:${k.mail||''}`);
  setTestLink('test-maps',k.mapsUrl);
  setTestLink('test-booking',k.bookingUrl);
  setTestLink('test-instagram',k.instagram);
  setTestLink('test-facebook',k.facebook);
}
function collectKontakt() {
  const k=D.kontakt;
  k.tlf=getVal('k-tlf').replace(/\D/g,'');
  k.sms=getVal('k-sms').replace(/\D/g,'')||k.tlf;
  k.mail=getVal('k-mail');
  k.adresse=sanitize(getVal('k-adresse'));
  k.by=sanitize(getVal('k-by'));
  k.mapsUrl=getVal('k-maps');
  k.bookingUrl=getVal('k-booking');
  k.instagram=getVal('k-instagram');
  k.facebook=getVal('k-facebook');
  D.meta=D.meta||{};
  D.meta.siteUrl=getVal('k-siteurl');
}

/* ══════════════════════════════════════
   SEO
══════════════════════════════════════ */
function renderSEO() {
  const m=D.meta||{};
  setVal('seo-titel',      m.seoTitel);
  setVal('seo-beskrivelse',m.seoBeskrivelse);
  setVal('seo-og-billede', m.ogBillede);
  const up=()=>{
    setText('gp-title',document.getElementById('seo-titel')?.value||'');
    setText('gp-desc',(document.getElementById('seo-beskrivelse')?.value||'').slice(0,120));
  };
  ['seo-titel','seo-beskrivelse'].forEach(id=>document.getElementById(id)?.addEventListener('input',up));
  up();
}
function collectSEO() {
  D.meta=D.meta||{};
  D.meta.seoTitel      =sanitize(getVal('seo-titel'));
  D.meta.seoBeskrivelse=sanitize(getVal('seo-beskrivelse'));
  D.meta.ogBillede     =getVal('seo-og-billede');
}

/* ══════════════════════════════════════
   QR
══════════════════════════════════════ */
function renderQR() {
  const k=D.kontakt;
  const siteUrl=D.meta?.siteUrl||k?.bookingUrl||'https://salonwebb.dk';
  const grid=document.getElementById('qr-main-grid');
  if(!grid)return;
  const items=[
    {label:'Hjemmeside',  desc:'QR til forsiden',             url:siteUrl},
    {label:'Book tid',    desc:'QR til booking',              url:k?.bookingUrl||''},
    {label:'Instagram',   desc:'QR til Instagram',            url:k?.instagram||''},
    {label:'Facebook',    desc:'QR til Facebook',             url:k?.facebook||''},
    {label:'Google Maps', desc:'QR til rutevejledning',       url:k?.mapsUrl||''},
    {label:'Ring',        desc:'QR der starter opkald',       url:k?.tlf?`tel:+45${(k.tlf).replace(/\D/g,'')}`:''}
  ];
  grid.innerHTML=items.map(q=>{
    if(!q.url)return`<div class="qr-big-card"><h3>${esc(q.label)}</h3><p>${esc(q.desc)}</p><p style="font-size:.72rem;color:#999">Sæt URL under Kontakt</p></div>`;
    const qrUrl=`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(q.url)}&color=0E0E0E&bgcolor=F7F4EF`;
    return`<div class="qr-big-card"><h3>${esc(q.label)}</h3><p>${esc(q.desc)}</p>
      <img src="${esc(qrUrl)}" alt="QR ${esc(q.label)}" width="150" height="150" loading="lazy">
      <a href="${esc(qrUrl)}" download="qr-${q.label.toLowerCase().replace(/\s/g,'-')}.png" class="qr-download-btn">⬇ Download PNG</a>
    </div>`;
  }).join('');
}

/* ══════════════════════════════════════
   BACKUP
══════════════════════════════════════ */
function renderBackup() {
  const ov=document.getElementById('data-overview');
  if(ov)ov.innerHTML=`
    <div class="status-item"><span class="status-dot status-ok"></span>Team: ${(D.team||[]).length}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Priser: ${(D.priser?.liste||[]).length}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Produktbrands: ${(D.produktbrands||[]).length}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Tilbud: ${(D.tilbudsliste||[]).length}</div>
    <div class="status-item"><span class="status-dot status-ok"></span>Galleri: ${(D.galleri||[]).length}</div>`;
  const cl=document.getElementById('changelog-display');
  if(cl)cl.textContent=`Salon Webb CHANGELOG
v1.2.0 – 2026-06-24
  – Indholdskort (Frisører, Atmosfære, Produkter)
  – Rigtige teammedlemmer: Heidi, Djannie, Caroline
  – Korrekt kontakt: 76 13 14 13 · Bytoften 30
  – Produktbrands: Kemon Actyva + Evo
  – Tilbudsliste med kort og billeder
  – admin.html ved roden
  – Admin: alle panels til redigering

v1.1.0 – Mobilmenu med ikoner, QR, helligdage
v1.0.0 – Første produktion

Nordic Operations · nordicoperations.dk`;
  rebind('btn-export',exportData);
  rebind('btn-import',()=>document.getElementById('import-file')?.click());
  document.getElementById('import-file')?.addEventListener('change',importData);
  rebind('btn-reset',resetData);
}
function exportData() {
  const blob=new Blob([JSON.stringify(D,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;a.download=`salonwebb-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  localStorage.setItem(BACKUP_KEY,new Date().toISOString());
  showToast('✓ JSON downloadet');
}
function importData(e) {
  const file=e.target.files?.[0];if(!file)return;
  const reader=new FileReader();
  reader.onload=evt=>{
    try{
      const imp=JSON.parse(evt.target.result);
      if(!imp.meta)throw new Error('Ugyldigt format');
      if(!confirm('Erstat AL data?'))return;
      D=imp;saveData();showToast('✓ Importeret');navigateTo('dashboard');
    }catch{alert('Fejl: Ugyldig backup-fil.');}
  };
  reader.readAsText(file);e.target.value='';
}
function resetData() {
  if(!confirm('Nulstil AL data til standard? Kan ikke fortrydes.'))return;
  D=deepCopy(SW_DEFAULT_DATA);saveData();navigateTo('dashboard');
}

/* ══════════════════════════════════════
   TESTCENTER
══════════════════════════════════════ */
function renderTest() {
  const k=D.kontakt;
  const tests=[
    {n:'Telefon 76 13 14 13',         s:k?.tlf==='76131413'?'ok':(k?.tlf?'warn':'fail'), note:k?.tlf||'Mangler', href:k?.tlf?`tel:+45${k.tlf}`:null},
    {n:'SMS-link',                     s:k?.sms||k?.tlf?'ok':'fail', note:k?.sms||k?.tlf||'Mangler'},
    {n:'E-mail',                       s:k?.mail?'ok':'warn', note:k?.mail||'Ikke sat', href:k?.mail?`mailto:${k.mail}`:null},
    {n:'Adresse: Bytoften 30',        s:k?.adresse==='Bytoften 30'?'ok':(k?.adresse?'warn':'fail'),note:k?.adresse||'Mangler'},
    {n:'Booking URL',                  s:k?.bookingUrl?'ok':'warn', note:k?.bookingUrl||'Mangler', href:k?.bookingUrl},
    {n:'Google Maps',                  s:k?.mapsUrl?'ok':'warn', note:k?.mapsUrl||'Mangler', href:k?.mapsUrl},
    {n:'Instagram',                    s:k?.instagram?'ok':'warn', note:k?.instagram||'Mangler', href:k?.instagram},
    {n:'Facebook',                     s:k?.facebook?'ok':'warn', note:k?.facebook||'Mangler', href:k?.facebook},
    {n:'Indholdskort (3 kort)',        s:(D.indholdskort||[]).length>=3?'ok':'warn',note:`${(D.indholdskort||[]).length} kort`},
    {n:'Team (Heidi, Djannie, Caroline)',s:(D.team||[]).length>=3?'ok':'warn',note:`${(D.team||[]).length} medl.`},
    {n:'Produktbrands (Kemon, Evo)',  s:(D.produktbrands||[]).length>=2?'ok':'warn',note:`${(D.produktbrands||[]).length} brands`},
    {n:'Tilbud konfigureret',          s:(D.tilbudsliste||[]).length>0?'ok':'skip',note:`${(D.tilbudsliste||[]).length} tilbud`},
    {n:'Hero-billede',                 s:D.hero?.baggrund?'ok':'warn',note:D.hero?.baggrund?'OK':'Ikke sat'},
    {n:'admin.html tilgængelig',       s:'ok',note:'admin.html ved roden'},
    {n:'manifest.json',                s:'ok',note:'Fil til stede'},
    {n:'service-worker.js',            s:'ok',note:'Fil til stede'},
    {n:'Backup',                       s:localStorage.getItem(BACKUP_KEY)?'ok':'warn',note:localStorage.getItem(BACKUP_KEY)?'OK':'Ingen backup'}
  ];
  const results=document.getElementById('test-results');
  if(!results)return;
  results.innerHTML=tests.map(t=>{
    const cls={ok:'test-ok',warn:'test-warn',fail:'test-fail',skip:'test-skip'}[t.s]||'test-skip';
    const ico={ok:'✓',warn:'⚠',fail:'✕',skip:'–'}[t.s]||'–';
    return`<div class="test-item">
      <div class="test-status ${cls}">${ico}</div>
      <span class="test-name">${esc(t.n)}</span>
      <span class="test-note">${esc(t.note||'')}</span>
      ${t.href?`<a href="${esc(t.href)}" target="_blank" rel="noopener" class="test-link">Test ↗</a>`:''}
    </div>`;
  }).join('');
  rebind('run-all-tests',()=>{
    renderTest();
    const ok=tests.filter(t=>t.s==='ok').length;
    showToast(`${ok}/${tests.length} OK`);
  });
}

/* ══════════════════════════════════════
   INDSTILLINGER
══════════════════════════════════════ */
function renderIndstillinger() {
  setText('current-version',D.meta?.version||'1.2.0');
  setVal('new-version',D.meta?.version);
  const list=document.getElementById('brugere-list');
  if(list){
    list.innerHTML=(D.adminBrugere||[]).map((u,i)=>`
      <div class="bruger-row">
        <span class="bruger-navn">${esc(u.navn)} · ${esc(u.email)}</span>
        <span class="bruger-rolle">${esc(u.rolle)}</span>
        ${D.adminBrugere.length>1?`<button class="btn-danger del-bruger" data-i="${i}">Slet</button>`:''}
      </div>`).join('');
    list.querySelectorAll('.del-bruger').forEach(btn=>btn.addEventListener('click',()=>{
      if(confirm('Slet?')){D.adminBrugere.splice(+btn.dataset.i,1);saveData();renderIndstillinger();}
    }));
  }
  rebind('add-bruger',()=>{
    const email=prompt('E-mail:');if(!email)return;
    const navn=prompt('Navn:');
    const pwd=prompt('Adgangskode (min. 8 tegn):');
    if(!pwd||pwd.length<8){alert('Min. 8 tegn.');return;}
    D.adminBrugere.push({id:'u'+Date.now(),navn:sanitize(navn||email),email,password:pwd,rolle:'admin'});
    saveData();renderIndstillinger();
  });
  rebind('change-pwd-btn',()=>{
    const p1=document.getElementById('new-pwd')?.value;
    const p2=document.getElementById('new-pwd2')?.value;
    if(!p1||p1.length<8){alert('Min. 8 tegn.');return;}
    if(p1!==p2){alert('Matcher ikke.');return;}
    const idx=D.adminBrugere.findIndex(u=>u.id===currentUser?.id);
    if(idx>=0){D.adminBrugere[idx].password=p1;saveData();showToast('✓ Adgangskode opdateret');}
  });
  rebind('bump-version-btn',()=>{
    const v=getVal('new-version').trim();
    if(!v||!/^\d+\.\d+\.\d+$/.test(v)){alert('Brug format: 1.2.0');return;}
    D.meta.version=v;D.meta.buildDate=new Date().toISOString().slice(0,10);
    saveData();renderIndstillinger();showToast(`✓ Version ${v}`);
  });
}

/* ══════════════════════════════════════
   ITEM CARD
══════════════════════════════════════ */
function makeItemCard({title,badge,fields,onSave,onDelete}) {
  const card=document.createElement('div');
  card.className='item-card';
  const isOk=badge==='Synlig';
  card.innerHTML=`
    <div class="item-card-header">
      <span class="item-card-drag">⠿</span>
      <span class="item-card-title">${esc(title)}</span>
      <span class="item-card-badge ${isOk?'synlig':'skjult'}">${esc(badge)}</span>
      <span class="item-card-toggle">▼</span>
    </div>
    <div class="item-card-body">
      ${fields.map(f=>buildField(f)).join('')}
      <div class="item-actions">
        <button class="btn-secondary save-card-btn">Gem</button>
        <button class="btn-danger del-card-btn">Slet</button>
      </div>
    </div>`;
  card.querySelector('.item-card-header').addEventListener('click',e=>{
    if(e.target.closest('button'))return;
    card.querySelector('.item-card-body')?.classList.toggle('open');
    card.querySelector('.item-card-toggle')?.classList.toggle('open');
  });
  card.querySelector('.save-card-btn')?.addEventListener('click',()=>{
    const vals={};
    fields.forEach(f=>{
      const el=card.querySelector(`[data-key="${f.key}"]`);
      if(!el)return;
      if(f.type==='checkbox') vals[f.key]=el.checked;
      else if(f.type==='number') vals[f.key]=+el.value;
      else vals[f.key]=f.type==='url'||f.type==='tel'?el.value.trim():sanitize(el.value.trim());
    });
    onSave(vals);
  });
  card.querySelector('.del-card-btn')?.addEventListener('click',()=>{if(confirm('Slet?'))onDelete();});
  return card;
}
function buildField(f) {
  if(f.type==='textarea')return`<div class="field-group"><label>${esc(f.label)}</label><textarea data-key="${esc(f.key)}" rows="3">${esc(f.val||'')}</textarea>${f.hint?`<span class="field-hint">${esc(f.hint)}</span>`:''}</div>`;
  if(f.type==='checkbox')return`<div class="field-group toggle-group"><label>${esc(f.label)}</label><label class="toggle"><input type="checkbox" data-key="${esc(f.key)}" ${f.val?'checked':''}><span class="toggle-slider"></span></label></div>`;
  if(f.type==='select')return`<div class="field-group"><label>${esc(f.label)}</label><select data-key="${esc(f.key)}">${(f.options||[]).map(o=>`<option ${o===f.val?'selected':''}>${esc(o)}</option>`).join('')}</select></div>`;
  return`<div class="field-group"><label>${esc(f.label)}</label><input type="${f.type||'text'}" data-key="${esc(f.key)}" value="${esc(f.val||'')}">${f.hint?`<span class="field-hint">${esc(f.hint)}</span>`:''}</div>`;
}

/* ══════════════════════════════════════
   HELPERS
══════════════════════════════════════ */
function showToast(msg){
  const t=document.getElementById('save-toast');if(!t)return;
  t.textContent=msg;t.classList.remove('hidden');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.add('hidden'),2500);
}
function rebind(id,fn){
  const el=document.getElementById(id);
  if(!el)return;
  const fresh=el.cloneNode(true);
  el.parentNode.replaceChild(fresh,el);
  fresh.addEventListener('click',fn);
}
function getVal(id){return(document.getElementById(id)?.value||'').trim();}
function setVal(id,val){const el=document.getElementById(id);if(el)el.value=val??'';}
function setText(id,val){const el=document.getElementById(id);if(el)el.textContent=val??'';}
function setChecked(id,val){const el=document.getElementById(id);if(el)el.checked=!!val;}
function setTestLink(id,url){
  const el=document.getElementById(id);if(!el)return;
  el.href=url||'#';el.style.display=url?'inline':'none';
  if(url&&(url.startsWith('tel:')||url.startsWith('mailto:'))){el.removeAttribute('target');}
  else if(url){el.target='_blank';el.rel='noopener';}
}
function esc(s){
  if(s===null||s===undefined)return'';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function sanitize(s){
  if(!s)return'';
  return String(s).replace(/<[^>]*>/g,'').replace(/[<>]/g,'').trim();
}
