# Salon Webb – PWA v1.0.0
**Nordic Operations · nordicoperations.dk**

Komplet mobil-first Progressive Web App til Salon Webb, Esbjerg.

---

## Filstruktur

```
salonwebb/
├── index.html            Hoved-HTML (offentlig side)
├── styles.css            Al CSS
├── app.js                Frontend logik
├── data.js               AL KUNDEDATA (redigér her eller via Admin)
├── manifest.json         PWA manifest
├── service-worker.js     Offline & cache
├── offline.html          Offline-side
├── icons/
│   ├── icon-192.png      PWA ikon
│   └── icon-512.png      PWA ikon (stor)
├── admin/
│   ├── index.html        Admin panel
│   ├── admin.css         Admin styling
│   └── admin.js          Admin logik
├── README.md
└── CHANGELOG.md
```

---

## Hurtig opsætning (15 minutter)

### 1. Opdatér kontaktoplysninger i `data.js`

```js
kontakt: {
  tlf: '75000000',           // ← Salonens telefonnummer (kun cifre)
  sms: '75000000',           // ← SMS-nummer (kan være det samme)
  mail: 'info@salonwebb.dk', // ← E-mail
  adresse: 'Gaden 1',        // ← Adresse
  by: '6700 Esbjerg',
  mapsUrl: 'https://maps.google.com/?q=Salon+Webb+Esbjerg',
  bookingUrl: 'https://salonwebb.bestilling.nu',
  instagram: 'https://www.instagram.com/salonwebb',
  facebook: 'https://www.facebook.com/salonwebb'
}
```

### 2. Upload til GitHub Pages

1. Opret GitHub-repository (fx `salonwebb`)
2. Upload alle filer til `main`-branch
3. Settings → Pages → Source: `main` / `root`
4. Live på: `https://[brugernavn].github.io/salonwebb/`

### 3. Test sitet

Gå til Admin → Testcenter og klik "Kør alle tests"

---

## Admin Panel

**URL:** `[dit-site]/admin/`

**Standard login:**
- E-mail: `admin@salonwebb.dk`
- Adgangskode: `webb2026`

**Hvad du kan redigere:**

| Panel | Hvad |
|-------|------|
| Forside | Hero-billede, overskrift, knapper |
| Behandlinger | Tilføj/ret/slet ydelser |
| Priser | Kategorier, priser, sortering |
| Produkter | Brand, navn, billede, pris |
| Team | Frisører, foto, bio, booking-link |
| Galleri | Billeder, sortering |
| Åbningstider | Alle dage, ferie/lukket |
| Kontakt | Telefon, mail, adresse, sociale medier |
| Tilbud | Kampagne-banner med datoer |
| SEO | Titel, beskrivelse, Open Graph |
| Dokumenter | Links til PDF, Word, Excel |
| Backup | Eksport/import JSON |
| Testcenter | Automatisk test af alle funktioner |

---

## Cache-busting ved opdatering

Opdatér versionsnummeret tre steder:

1. `index.html`: `?v=1.0.0` → `?v=1.0.1`
2. `service-worker.js`: `const CACHE = 'salonwebb-v1.0.0'` → `v1.0.1`
3. Admin → Indstillinger → Versionsnummer

---

## PWA-installation

**iOS (Safari):**
Deleknap (□↑) → "Føj til hjemmeskærm"

**Android (Chrome):**
Tre prikker → "Tilføj til startskærm"
(Installationsbanner vises automatisk efter 3 sekunder)

---

## Billeder

Sitet bruger Unsplash-billeder som standard.
Udskift med salonens egne billeder ved at:

1. Upload billeder til GitHub i `/assets/`-mappen
2. Opdatér URL'er i `data.js` (hero, team-fotos) eller via Admin

---

## Testliste inden go-live

- [ ] Ring (📞) virker på iPhone og Android
- [ ] SMS (💬) virker
- [ ] E-mail (✉️) åbner
- [ ] Booking åbner korrekt side
- [ ] Google Maps åbner
- [ ] Instagram åbner
- [ ] Facebook åbner
- [ ] Alle billeder vises (ingen broken images)
- [ ] Mobilvisning OK (320px–428px)
- [ ] Tablet (768px) OK
- [ ] Desktop OK
- [ ] Admin login virker
- [ ] Admin: gem data og se ændring på sitet
- [ ] PWA: installationsbanner vises (Android/Chrome)
- [ ] Offline-siden vises uden internet
- [ ] Testcenter: alle grønne

---

## Kontakt

Bygget af **Nordic Operations**  
[nordicoperations.dk](https://nordicoperations.dk)
